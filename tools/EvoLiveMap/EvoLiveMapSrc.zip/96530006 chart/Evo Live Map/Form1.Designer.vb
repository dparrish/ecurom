<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.TabPage6 = New System.Windows.Forms.TabPage
        Me.selectactivecell = New System.Windows.Forms.CheckBox
        Me.Clrcolors = New System.Windows.Forms.Button
        Me.Knocktrace = New System.Windows.Forms.CheckBox
        Me.Ignitionrecolor = New System.Windows.Forms.Button
        Me.Removeignitionrowbutton = New System.Windows.Forms.Button
        Me.Addignitionrowbutton = New System.Windows.Forms.Button
        Me.Removeignitioncolumnbutton = New System.Windows.Forms.Button
        Me.Addignitioncolumnbutton = New System.Windows.Forms.Button
        Me.Loadignitionbutton = New System.Windows.Forms.Button
        Me.Saveignitionbutton = New System.Windows.Forms.Button
        Me.Pasteignitionbutton = New System.Windows.Forms.Button
        Me.Copyignitionbutton = New System.Windows.Forms.Button
        Me.Writeignitionbutton = New System.Windows.Forms.Button
        Me.Readignitionbutton = New System.Windows.Forms.Button
        Me.DataGridView2 = New System.Windows.Forms.DataGridView
        Me.BindingSource2 = New System.Windows.Forms.BindingSource(Me.components)
        Me.TabPage5 = New System.Windows.Forms.TabPage
        Me.Fuelrecolor = New System.Windows.Forms.Button
        Me.Removefuelrowbutton = New System.Windows.Forms.Button
        Me.Addfuelrowbutton = New System.Windows.Forms.Button
        Me.Removefuelcolumnbutton = New System.Windows.Forms.Button
        Me.Addfuelcolumnbutton = New System.Windows.Forms.Button
        Me.Loadfuelbutton = New System.Windows.Forms.Button
        Me.Savefuelbutton = New System.Windows.Forms.Button
        Me.Pastefuelbutton = New System.Windows.Forms.Button
        Me.Copyfuelbutton = New System.Windows.Forms.Button
        Me.Writefuelbutton = New System.Windows.Forms.Button
        Me.Readfuelbutton = New System.Windows.Forms.Button
        Me.DataGridView1 = New System.Windows.Forms.DataGridView
        Me.BindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.TabPage4 = New System.Windows.Forms.TabPage
        Me.Label3 = New System.Windows.Forms.Label
        Me.Knockcolorloadbutton = New System.Windows.Forms.Button
        Me.Knockcolorsavebutton = New System.Windows.Forms.Button
        Me.DataGridView5 = New System.Windows.Forms.DataGridView
        Me.BindingSource5 = New System.Windows.Forms.BindingSource(Me.components)
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.Addressloadbutton = New System.Windows.Forms.Button
        Me.Addresssavebutton = New System.Windows.Forms.Button
        Me.DataGridView4 = New System.Windows.Forms.DataGridView
        Me.BindingSource4 = New System.Windows.Forms.BindingSource(Me.components)
        Me.TabPage1 = New System.Windows.Forms.TabPage
        Me.Button3 = New System.Windows.Forms.Button
        Me.loggingdirectory = New System.Windows.Forms.TextBox
        Me.Label37 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Baud = New System.Windows.Forms.TextBox
        Me.Verify = New System.Windows.Forms.CheckBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.Success = New System.Windows.Forms.TextBox
        Me.Write = New System.Windows.Forms.Button
        Me.ROMfilename = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.Blockaddressloadbutton = New System.Windows.Forms.Button
        Me.Blockaddresssavebutton = New System.Windows.Forms.Button
        Me.DataGridView6 = New System.Windows.Forms.DataGridView
        Me.BindingSource6 = New System.Windows.Forms.BindingSource(Me.components)
        Me.Choose = New System.Windows.Forms.Button
        Me.Removeconfigrowbutton = New System.Windows.Forms.Button
        Me.Addconfigrowbutton = New System.Windows.Forms.Button
        Me.Configloadbutton = New System.Windows.Forms.Button
        Me.Configsavebutton = New System.Windows.Forms.Button
        Me.DataGridView3 = New System.Windows.Forms.DataGridView
        Me.BindingSource3 = New System.Windows.Forms.BindingSource(Me.components)
        Me.Startstopbutton = New System.Windows.Forms.Button
        Me.TabControl1 = New System.Windows.Forms.TabControl
        Me.TabPage3 = New System.Windows.Forms.TabPage
        Me.MAP = New System.Windows.Forms.TextBox
        Me.Label30 = New System.Windows.Forms.Label
        Me.RPM = New System.Windows.Forms.TextBox
        Me.Label31 = New System.Windows.Forms.Label
        Me.EngLoad = New System.Windows.Forms.TextBox
        Me.Label32 = New System.Windows.Forms.Label
        Me.TPS = New System.Windows.Forms.TextBox
        Me.Label33 = New System.Windows.Forms.Label
        Me.IPW = New System.Windows.Forms.TextBox
        Me.Label34 = New System.Windows.Forms.Label
        Me.Knock = New System.Windows.Forms.TextBox
        Me.Label35 = New System.Windows.Forms.Label
        Me.Ign = New System.Windows.Forms.TextBox
        Me.Label36 = New System.Windows.Forms.Label
        Me.O2 = New System.Windows.Forms.TextBox
        Me.Label38 = New System.Windows.Forms.Label
        Me.Air = New System.Windows.Forms.TextBox
        Me.Label26 = New System.Windows.Forms.Label
        Me.Coolant = New System.Windows.Forms.TextBox
        Me.Label27 = New System.Windows.Forms.Label
        Me.Batt = New System.Windows.Forms.TextBox
        Me.Label28 = New System.Windows.Forms.Label
        Me.Oct = New System.Windows.Forms.TextBox
        Me.Label29 = New System.Windows.Forms.Label
        Me.STFT = New System.Windows.Forms.TextBox
        Me.Label24 = New System.Windows.Forms.Label
        Me.FTHi = New System.Windows.Forms.TextBox
        Me.Label25 = New System.Windows.Forms.Label
        Me.FTMed = New System.Windows.Forms.TextBox
        Me.Label23 = New System.Windows.Forms.Label
        Me.FTLo = New System.Windows.Forms.TextBox
        Me.Label22 = New System.Windows.Forms.Label
        Me.Chartcheckbox = New System.Windows.Forms.CheckBox
        Me.ZedGraphControl1 = New ZedGraph.ZedGraphControl
        Me.TabPage2 = New System.Windows.Forms.TabPage
        Me.BindingSource8 = New System.Windows.Forms.BindingSource(Me.components)
        Me.BindingSource7 = New System.Windows.Forms.BindingSource(Me.components)
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog
        Me.TabPage6.SuspendLayout()
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BindingSource2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage5.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage4.SuspendLayout()
        CType(Me.DataGridView5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BindingSource5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BindingSource4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage1.SuspendLayout()
        CType(Me.DataGridView6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BindingSource6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BindingSource3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabControl1.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        CType(Me.BindingSource8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BindingSource7, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Timer1
        '
        Me.Timer1.Interval = 1
        '
        'TabPage6
        '
        Me.TabPage6.Controls.Add(Me.selectactivecell)
        Me.TabPage6.Controls.Add(Me.Clrcolors)
        Me.TabPage6.Controls.Add(Me.Knocktrace)
        Me.TabPage6.Controls.Add(Me.Ignitionrecolor)
        Me.TabPage6.Controls.Add(Me.Removeignitionrowbutton)
        Me.TabPage6.Controls.Add(Me.Addignitionrowbutton)
        Me.TabPage6.Controls.Add(Me.Removeignitioncolumnbutton)
        Me.TabPage6.Controls.Add(Me.Addignitioncolumnbutton)
        Me.TabPage6.Controls.Add(Me.Loadignitionbutton)
        Me.TabPage6.Controls.Add(Me.Saveignitionbutton)
        Me.TabPage6.Controls.Add(Me.Pasteignitionbutton)
        Me.TabPage6.Controls.Add(Me.Copyignitionbutton)
        Me.TabPage6.Controls.Add(Me.Writeignitionbutton)
        Me.TabPage6.Controls.Add(Me.Readignitionbutton)
        Me.TabPage6.Controls.Add(Me.DataGridView2)
        Me.TabPage6.Location = New System.Drawing.Point(4, 27)
        Me.TabPage6.Name = "TabPage6"
        Me.TabPage6.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage6.Size = New System.Drawing.Size(1184, 685)
        Me.TabPage6.TabIndex = 5
        Me.TabPage6.Text = "Ignition"
        Me.TabPage6.UseVisualStyleBackColor = True
        '
        'selectactivecell
        '
        Me.selectactivecell.AutoSize = True
        Me.selectactivecell.Checked = True
        Me.selectactivecell.CheckState = System.Windows.Forms.CheckState.Checked
        Me.selectactivecell.Location = New System.Drawing.Point(962, 250)
        Me.selectactivecell.Name = "selectactivecell"
        Me.selectactivecell.Size = New System.Drawing.Size(132, 22)
        Me.selectactivecell.TabIndex = 30
        Me.selectactivecell.Text = "Select active cell"
        Me.selectactivecell.UseVisualStyleBackColor = True
        '
        'Clrcolors
        '
        Me.Clrcolors.Location = New System.Drawing.Point(892, 4)
        Me.Clrcolors.Name = "Clrcolors"
        Me.Clrcolors.Size = New System.Drawing.Size(122, 28)
        Me.Clrcolors.TabIndex = 28
        Me.Clrcolors.Text = "Clear color"
        Me.Clrcolors.UseVisualStyleBackColor = True
        '
        'Knocktrace
        '
        Me.Knocktrace.AutoSize = True
        Me.Knocktrace.Checked = True
        Me.Knocktrace.CheckState = System.Windows.Forms.CheckState.Checked
        Me.Knocktrace.Location = New System.Drawing.Point(962, 222)
        Me.Knocktrace.Name = "Knocktrace"
        Me.Knocktrace.Size = New System.Drawing.Size(104, 22)
        Me.Knocktrace.TabIndex = 27
        Me.Knocktrace.Text = "Knock trace"
        Me.Knocktrace.UseVisualStyleBackColor = True
        '
        'Ignitionrecolor
        '
        Me.Ignitionrecolor.Location = New System.Drawing.Point(764, 4)
        Me.Ignitionrecolor.Name = "Ignitionrecolor"
        Me.Ignitionrecolor.Size = New System.Drawing.Size(122, 28)
        Me.Ignitionrecolor.TabIndex = 26
        Me.Ignitionrecolor.Text = "Recolor"
        Me.Ignitionrecolor.UseVisualStyleBackColor = True
        '
        'Removeignitionrowbutton
        '
        Me.Removeignitionrowbutton.Location = New System.Drawing.Point(962, 131)
        Me.Removeignitionrowbutton.Name = "Removeignitionrowbutton"
        Me.Removeignitionrowbutton.Size = New System.Drawing.Size(35, 25)
        Me.Removeignitionrowbutton.TabIndex = 25
        Me.Removeignitionrowbutton.Text = "y-"
        Me.Removeignitionrowbutton.UseVisualStyleBackColor = True
        '
        'Addignitionrowbutton
        '
        Me.Addignitionrowbutton.Location = New System.Drawing.Point(962, 100)
        Me.Addignitionrowbutton.Name = "Addignitionrowbutton"
        Me.Addignitionrowbutton.Size = New System.Drawing.Size(35, 25)
        Me.Addignitionrowbutton.TabIndex = 24
        Me.Addignitionrowbutton.Text = "y+"
        Me.Addignitionrowbutton.UseVisualStyleBackColor = True
        '
        'Removeignitioncolumnbutton
        '
        Me.Removeignitioncolumnbutton.Location = New System.Drawing.Point(962, 69)
        Me.Removeignitioncolumnbutton.Name = "Removeignitioncolumnbutton"
        Me.Removeignitioncolumnbutton.Size = New System.Drawing.Size(35, 25)
        Me.Removeignitioncolumnbutton.TabIndex = 23
        Me.Removeignitioncolumnbutton.Text = "x-"
        Me.Removeignitioncolumnbutton.UseVisualStyleBackColor = True
        '
        'Addignitioncolumnbutton
        '
        Me.Addignitioncolumnbutton.Location = New System.Drawing.Point(962, 38)
        Me.Addignitioncolumnbutton.Name = "Addignitioncolumnbutton"
        Me.Addignitioncolumnbutton.Size = New System.Drawing.Size(35, 25)
        Me.Addignitioncolumnbutton.TabIndex = 22
        Me.Addignitioncolumnbutton.Text = "x+"
        Me.Addignitioncolumnbutton.UseVisualStyleBackColor = True
        '
        'Loadignitionbutton
        '
        Me.Loadignitionbutton.Location = New System.Drawing.Point(637, 4)
        Me.Loadignitionbutton.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.Loadignitionbutton.Name = "Loadignitionbutton"
        Me.Loadignitionbutton.Size = New System.Drawing.Size(122, 28)
        Me.Loadignitionbutton.TabIndex = 17
        Me.Loadignitionbutton.Text = "Loadfromxml"
        Me.Loadignitionbutton.UseVisualStyleBackColor = True
        '
        'Saveignitionbutton
        '
        Me.Saveignitionbutton.Location = New System.Drawing.Point(511, 4)
        Me.Saveignitionbutton.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.Saveignitionbutton.Name = "Saveignitionbutton"
        Me.Saveignitionbutton.Size = New System.Drawing.Size(122, 28)
        Me.Saveignitionbutton.TabIndex = 16
        Me.Saveignitionbutton.Text = "Savetoxml"
        Me.Saveignitionbutton.UseVisualStyleBackColor = True
        '
        'Pasteignitionbutton
        '
        Me.Pasteignitionbutton.Location = New System.Drawing.Point(385, 4)
        Me.Pasteignitionbutton.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.Pasteignitionbutton.Name = "Pasteignitionbutton"
        Me.Pasteignitionbutton.Size = New System.Drawing.Size(122, 28)
        Me.Pasteignitionbutton.TabIndex = 11
        Me.Pasteignitionbutton.Text = "Paste"
        Me.Pasteignitionbutton.UseVisualStyleBackColor = True
        '
        'Copyignitionbutton
        '
        Me.Copyignitionbutton.Location = New System.Drawing.Point(259, 4)
        Me.Copyignitionbutton.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.Copyignitionbutton.Name = "Copyignitionbutton"
        Me.Copyignitionbutton.Size = New System.Drawing.Size(122, 28)
        Me.Copyignitionbutton.TabIndex = 9
        Me.Copyignitionbutton.Text = "Copy"
        Me.Copyignitionbutton.UseVisualStyleBackColor = True
        '
        'Writeignitionbutton
        '
        Me.Writeignitionbutton.Enabled = False
        Me.Writeignitionbutton.Location = New System.Drawing.Point(133, 4)
        Me.Writeignitionbutton.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.Writeignitionbutton.Name = "Writeignitionbutton"
        Me.Writeignitionbutton.Size = New System.Drawing.Size(122, 28)
        Me.Writeignitionbutton.TabIndex = 8
        Me.Writeignitionbutton.Text = "Write RAM ign map"
        Me.Writeignitionbutton.UseVisualStyleBackColor = True
        '
        'Readignitionbutton
        '
        Me.Readignitionbutton.Enabled = False
        Me.Readignitionbutton.Location = New System.Drawing.Point(7, 4)
        Me.Readignitionbutton.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.Readignitionbutton.Name = "Readignitionbutton"
        Me.Readignitionbutton.Size = New System.Drawing.Size(122, 28)
        Me.Readignitionbutton.TabIndex = 7
        Me.Readignitionbutton.Text = "Read RAM ign map"
        Me.Readignitionbutton.UseVisualStyleBackColor = True
        '
        'DataGridView2
        '
        Me.DataGridView2.AllowUserToAddRows = False
        Me.DataGridView2.AllowUserToDeleteRows = False
        Me.DataGridView2.AllowUserToResizeColumns = False
        Me.DataGridView2.AllowUserToResizeRows = False
        Me.DataGridView2.AutoGenerateColumns = False
        Me.DataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridView2.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText
        Me.DataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView2.ColumnHeadersVisible = False
        Me.DataGridView2.DataSource = Me.BindingSource2
        Me.DataGridView2.Location = New System.Drawing.Point(7, 38)
        Me.DataGridView2.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.DataGridView2.Name = "DataGridView2"
        Me.DataGridView2.RowHeadersVisible = False
        Me.DataGridView2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect
        Me.DataGridView2.Size = New System.Drawing.Size(950, 500)
        Me.DataGridView2.TabIndex = 6
        '
        'TabPage5
        '
        Me.TabPage5.Controls.Add(Me.Fuelrecolor)
        Me.TabPage5.Controls.Add(Me.Removefuelrowbutton)
        Me.TabPage5.Controls.Add(Me.Addfuelrowbutton)
        Me.TabPage5.Controls.Add(Me.Removefuelcolumnbutton)
        Me.TabPage5.Controls.Add(Me.Addfuelcolumnbutton)
        Me.TabPage5.Controls.Add(Me.Loadfuelbutton)
        Me.TabPage5.Controls.Add(Me.Savefuelbutton)
        Me.TabPage5.Controls.Add(Me.Pastefuelbutton)
        Me.TabPage5.Controls.Add(Me.Copyfuelbutton)
        Me.TabPage5.Controls.Add(Me.Writefuelbutton)
        Me.TabPage5.Controls.Add(Me.Readfuelbutton)
        Me.TabPage5.Controls.Add(Me.DataGridView1)
        Me.TabPage5.Location = New System.Drawing.Point(4, 27)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage5.Size = New System.Drawing.Size(1184, 685)
        Me.TabPage5.TabIndex = 4
        Me.TabPage5.Text = "Fuel"
        Me.TabPage5.UseVisualStyleBackColor = True
        '
        'Fuelrecolor
        '
        Me.Fuelrecolor.Location = New System.Drawing.Point(764, 4)
        Me.Fuelrecolor.Name = "Fuelrecolor"
        Me.Fuelrecolor.Size = New System.Drawing.Size(122, 28)
        Me.Fuelrecolor.TabIndex = 27
        Me.Fuelrecolor.Text = "Recolor"
        Me.Fuelrecolor.UseVisualStyleBackColor = True
        '
        'Removefuelrowbutton
        '
        Me.Removefuelrowbutton.Location = New System.Drawing.Point(962, 131)
        Me.Removefuelrowbutton.Name = "Removefuelrowbutton"
        Me.Removefuelrowbutton.Size = New System.Drawing.Size(35, 25)
        Me.Removefuelrowbutton.TabIndex = 21
        Me.Removefuelrowbutton.Text = "y-"
        Me.Removefuelrowbutton.UseVisualStyleBackColor = True
        '
        'Addfuelrowbutton
        '
        Me.Addfuelrowbutton.Location = New System.Drawing.Point(962, 100)
        Me.Addfuelrowbutton.Name = "Addfuelrowbutton"
        Me.Addfuelrowbutton.Size = New System.Drawing.Size(35, 25)
        Me.Addfuelrowbutton.TabIndex = 20
        Me.Addfuelrowbutton.Text = "y+"
        Me.Addfuelrowbutton.UseVisualStyleBackColor = True
        '
        'Removefuelcolumnbutton
        '
        Me.Removefuelcolumnbutton.Location = New System.Drawing.Point(962, 69)
        Me.Removefuelcolumnbutton.Name = "Removefuelcolumnbutton"
        Me.Removefuelcolumnbutton.Size = New System.Drawing.Size(35, 25)
        Me.Removefuelcolumnbutton.TabIndex = 19
        Me.Removefuelcolumnbutton.Text = "x-"
        Me.Removefuelcolumnbutton.UseVisualStyleBackColor = True
        '
        'Addfuelcolumnbutton
        '
        Me.Addfuelcolumnbutton.Location = New System.Drawing.Point(962, 38)
        Me.Addfuelcolumnbutton.Name = "Addfuelcolumnbutton"
        Me.Addfuelcolumnbutton.Size = New System.Drawing.Size(35, 25)
        Me.Addfuelcolumnbutton.TabIndex = 18
        Me.Addfuelcolumnbutton.Text = "x+"
        Me.Addfuelcolumnbutton.UseVisualStyleBackColor = True
        '
        'Loadfuelbutton
        '
        Me.Loadfuelbutton.Location = New System.Drawing.Point(637, 4)
        Me.Loadfuelbutton.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.Loadfuelbutton.Name = "Loadfuelbutton"
        Me.Loadfuelbutton.Size = New System.Drawing.Size(122, 28)
        Me.Loadfuelbutton.TabIndex = 15
        Me.Loadfuelbutton.Text = "Loadfromxml"
        Me.Loadfuelbutton.UseVisualStyleBackColor = True
        '
        'Savefuelbutton
        '
        Me.Savefuelbutton.Location = New System.Drawing.Point(511, 4)
        Me.Savefuelbutton.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.Savefuelbutton.Name = "Savefuelbutton"
        Me.Savefuelbutton.Size = New System.Drawing.Size(122, 28)
        Me.Savefuelbutton.TabIndex = 14
        Me.Savefuelbutton.Text = "Savetoxml"
        Me.Savefuelbutton.UseVisualStyleBackColor = True
        '
        'Pastefuelbutton
        '
        Me.Pastefuelbutton.Location = New System.Drawing.Point(385, 4)
        Me.Pastefuelbutton.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.Pastefuelbutton.Name = "Pastefuelbutton"
        Me.Pastefuelbutton.Size = New System.Drawing.Size(122, 28)
        Me.Pastefuelbutton.TabIndex = 13
        Me.Pastefuelbutton.Text = "Paste"
        Me.Pastefuelbutton.UseVisualStyleBackColor = True
        '
        'Copyfuelbutton
        '
        Me.Copyfuelbutton.Location = New System.Drawing.Point(259, 4)
        Me.Copyfuelbutton.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.Copyfuelbutton.Name = "Copyfuelbutton"
        Me.Copyfuelbutton.Size = New System.Drawing.Size(122, 28)
        Me.Copyfuelbutton.TabIndex = 12
        Me.Copyfuelbutton.Text = "Copy"
        Me.Copyfuelbutton.UseVisualStyleBackColor = True
        '
        'Writefuelbutton
        '
        Me.Writefuelbutton.Enabled = False
        Me.Writefuelbutton.Location = New System.Drawing.Point(133, 4)
        Me.Writefuelbutton.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.Writefuelbutton.Name = "Writefuelbutton"
        Me.Writefuelbutton.Size = New System.Drawing.Size(122, 28)
        Me.Writefuelbutton.TabIndex = 5
        Me.Writefuelbutton.Text = "Write RAM fuel map"
        Me.Writefuelbutton.UseVisualStyleBackColor = True
        '
        'Readfuelbutton
        '
        Me.Readfuelbutton.Enabled = False
        Me.Readfuelbutton.Location = New System.Drawing.Point(7, 4)
        Me.Readfuelbutton.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.Readfuelbutton.Name = "Readfuelbutton"
        Me.Readfuelbutton.Size = New System.Drawing.Size(122, 28)
        Me.Readfuelbutton.TabIndex = 4
        Me.Readfuelbutton.Text = "Read RAM fuel map"
        Me.Readfuelbutton.UseVisualStyleBackColor = True
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.AllowUserToResizeColumns = False
        Me.DataGridView1.AllowUserToResizeRows = False
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridView1.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.ColumnHeadersVisible = False
        Me.DataGridView1.DataSource = Me.BindingSource1
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle1.NullValue = Nothing
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridView1.DefaultCellStyle = DataGridViewCellStyle1
        Me.DataGridView1.Location = New System.Drawing.Point(7, 38)
        Me.DataGridView1.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowHeadersVisible = False
        Me.DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect
        Me.DataGridView1.Size = New System.Drawing.Size(950, 500)
        Me.DataGridView1.TabIndex = 3
        '
        'TabPage4
        '
        Me.TabPage4.Controls.Add(Me.Label3)
        Me.TabPage4.Controls.Add(Me.Knockcolorloadbutton)
        Me.TabPage4.Controls.Add(Me.Knockcolorsavebutton)
        Me.TabPage4.Controls.Add(Me.DataGridView5)
        Me.TabPage4.Controls.Add(Me.Label2)
        Me.TabPage4.Controls.Add(Me.Label1)
        Me.TabPage4.Controls.Add(Me.Addressloadbutton)
        Me.TabPage4.Controls.Add(Me.Addresssavebutton)
        Me.TabPage4.Controls.Add(Me.DataGridView4)
        Me.TabPage4.Location = New System.Drawing.Point(4, 27)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Size = New System.Drawing.Size(1184, 685)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "Setting"
        Me.TabPage4.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(402, 34)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(82, 18)
        Me.Label3.TabIndex = 126
        Me.Label3.Text = "Knock color"
        '
        'Knockcolorloadbutton
        '
        Me.Knockcolorloadbutton.Location = New System.Drawing.Point(619, 220)
        Me.Knockcolorloadbutton.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.Knockcolorloadbutton.Name = "Knockcolorloadbutton"
        Me.Knockcolorloadbutton.Size = New System.Drawing.Size(122, 28)
        Me.Knockcolorloadbutton.TabIndex = 125
        Me.Knockcolorloadbutton.Text = "Loadfromxml"
        Me.Knockcolorloadbutton.UseVisualStyleBackColor = True
        '
        'Knockcolorsavebutton
        '
        Me.Knockcolorsavebutton.Location = New System.Drawing.Point(493, 220)
        Me.Knockcolorsavebutton.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.Knockcolorsavebutton.Name = "Knockcolorsavebutton"
        Me.Knockcolorsavebutton.Size = New System.Drawing.Size(122, 28)
        Me.Knockcolorsavebutton.TabIndex = 124
        Me.Knockcolorsavebutton.Text = "Savetoxml"
        Me.Knockcolorsavebutton.UseVisualStyleBackColor = True
        '
        'DataGridView5
        '
        Me.DataGridView5.AllowUserToAddRows = False
        Me.DataGridView5.AllowUserToDeleteRows = False
        Me.DataGridView5.AllowUserToResizeColumns = False
        Me.DataGridView5.AllowUserToResizeRows = False
        Me.DataGridView5.AutoGenerateColumns = False
        Me.DataGridView5.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridView5.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText
        Me.DataGridView5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView5.DataSource = Me.BindingSource5
        Me.DataGridView5.Location = New System.Drawing.Point(493, 3)
        Me.DataGridView5.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.DataGridView5.Name = "DataGridView5"
        Me.DataGridView5.RowHeadersVisible = False
        Me.DataGridView5.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect
        Me.DataGridView5.Size = New System.Drawing.Size(248, 211)
        Me.DataGridView5.TabIndex = 123
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(7, 54)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(86, 18)
        Me.Label2.TabIndex = 119
        Me.Label2.Text = "RAM ignition"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(7, 33)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(66, 18)
        Me.Label1.TabIndex = 118
        Me.Label1.Text = "RAM fuel"
        '
        'Addressloadbutton
        '
        Me.Addressloadbutton.Location = New System.Drawing.Point(238, 220)
        Me.Addressloadbutton.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.Addressloadbutton.Name = "Addressloadbutton"
        Me.Addressloadbutton.Size = New System.Drawing.Size(122, 28)
        Me.Addressloadbutton.TabIndex = 117
        Me.Addressloadbutton.Text = "Loadfromxml"
        Me.Addressloadbutton.UseVisualStyleBackColor = True
        '
        'Addresssavebutton
        '
        Me.Addresssavebutton.Location = New System.Drawing.Point(112, 220)
        Me.Addresssavebutton.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.Addresssavebutton.Name = "Addresssavebutton"
        Me.Addresssavebutton.Size = New System.Drawing.Size(122, 28)
        Me.Addresssavebutton.TabIndex = 116
        Me.Addresssavebutton.Text = "Savetoxml"
        Me.Addresssavebutton.UseVisualStyleBackColor = True
        '
        'DataGridView4
        '
        Me.DataGridView4.AllowUserToAddRows = False
        Me.DataGridView4.AllowUserToDeleteRows = False
        Me.DataGridView4.AllowUserToResizeColumns = False
        Me.DataGridView4.AllowUserToResizeRows = False
        Me.DataGridView4.AutoGenerateColumns = False
        Me.DataGridView4.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridView4.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText
        Me.DataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView4.DataSource = Me.BindingSource4
        Me.DataGridView4.Location = New System.Drawing.Point(112, 3)
        Me.DataGridView4.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.DataGridView4.Name = "DataGridView4"
        Me.DataGridView4.RowHeadersVisible = False
        Me.DataGridView4.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect
        Me.DataGridView4.Size = New System.Drawing.Size(248, 211)
        Me.DataGridView4.TabIndex = 115
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.Button3)
        Me.TabPage1.Controls.Add(Me.loggingdirectory)
        Me.TabPage1.Controls.Add(Me.Label37)
        Me.TabPage1.Controls.Add(Me.Label4)
        Me.TabPage1.Controls.Add(Me.Baud)
        Me.TabPage1.Controls.Add(Me.Verify)
        Me.TabPage1.Controls.Add(Me.Label6)
        Me.TabPage1.Controls.Add(Me.Success)
        Me.TabPage1.Controls.Add(Me.Write)
        Me.TabPage1.Controls.Add(Me.ROMfilename)
        Me.TabPage1.Controls.Add(Me.Label5)
        Me.TabPage1.Controls.Add(Me.Label7)
        Me.TabPage1.Controls.Add(Me.Label8)
        Me.TabPage1.Controls.Add(Me.Blockaddressloadbutton)
        Me.TabPage1.Controls.Add(Me.Blockaddresssavebutton)
        Me.TabPage1.Controls.Add(Me.DataGridView6)
        Me.TabPage1.Controls.Add(Me.Choose)
        Me.TabPage1.Controls.Add(Me.Removeconfigrowbutton)
        Me.TabPage1.Controls.Add(Me.Addconfigrowbutton)
        Me.TabPage1.Controls.Add(Me.Configloadbutton)
        Me.TabPage1.Controls.Add(Me.Configsavebutton)
        Me.TabPage1.Controls.Add(Me.DataGridView3)
        Me.TabPage1.Controls.Add(Me.Startstopbutton)
        Me.TabPage1.Location = New System.Drawing.Point(4, 27)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Size = New System.Drawing.Size(1184, 685)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Data"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(930, 315)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(78, 57)
        Me.Button3.TabIndex = 182
        Me.Button3.Text = "Verify only"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'loggingdirectory
        '
        Me.loggingdirectory.Location = New System.Drawing.Point(811, 41)
        Me.loggingdirectory.Name = "loggingdirectory"
        Me.loggingdirectory.Size = New System.Drawing.Size(226, 26)
        Me.loggingdirectory.TabIndex = 171
        '
        'Label37
        '
        Me.Label37.Location = New System.Drawing.Point(811, 22)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(224, 26)
        Me.Label37.TabIndex = 172
        Me.Label37.Text = "Logging directory"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(811, 87)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(41, 18)
        Me.Label4.TabIndex = 170
        Me.Label4.Text = "Baud"
        '
        'Baud
        '
        Me.Baud.Location = New System.Drawing.Point(858, 84)
        Me.Baud.Name = "Baud"
        Me.Baud.Size = New System.Drawing.Size(57, 26)
        Me.Baud.TabIndex = 169
        Me.Baud.Text = "15625"
        '
        'Verify
        '
        Me.Verify.AutoSize = True
        Me.Verify.Checked = True
        Me.Verify.CheckState = System.Windows.Forms.CheckState.Checked
        Me.Verify.Location = New System.Drawing.Point(743, 332)
        Me.Verify.Name = "Verify"
        Me.Verify.Size = New System.Drawing.Size(64, 22)
        Me.Verify.TabIndex = 166
        Me.Verify.Text = "Verify"
        Me.Verify.UseVisualStyleBackColor = True
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(558, 252)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(113, 18)
        Me.Label6.TabIndex = 168
        Me.Label6.Text = "Logging address"
        '
        'Success
        '
        Me.Success.Location = New System.Drawing.Point(813, 330)
        Me.Success.Name = "Success"
        Me.Success.Size = New System.Drawing.Size(111, 26)
        Me.Success.TabIndex = 167
        '
        'Write
        '
        Me.Write.Location = New System.Drawing.Point(653, 315)
        Me.Write.Name = "Write"
        Me.Write.Size = New System.Drawing.Size(84, 41)
        Me.Write.TabIndex = 165
        Me.Write.Text = "Write"
        Me.Write.UseVisualStyleBackColor = True
        '
        'ROMfilename
        '
        Me.ROMfilename.Location = New System.Drawing.Point(561, 362)
        Me.ROMfilename.Multiline = True
        Me.ROMfilename.Name = "ROMfilename"
        Me.ROMfilename.Size = New System.Drawing.Size(363, 68)
        Me.ROMfilename.TabIndex = 158
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(557, 230)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(99, 18)
        Me.Label5.TabIndex = 164
        Me.Label5.Text = "Bytes to copy"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(557, 209)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(94, 18)
        Me.Label7.TabIndex = 163
        Me.Label7.Text = "RAM address"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(557, 189)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(96, 18)
        Me.Label8.TabIndex = 162
        Me.Label8.Text = "ROM address"
        '
        'Blockaddressloadbutton
        '
        Me.Blockaddressloadbutton.Location = New System.Drawing.Point(802, 284)
        Me.Blockaddressloadbutton.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.Blockaddressloadbutton.Name = "Blockaddressloadbutton"
        Me.Blockaddressloadbutton.Size = New System.Drawing.Size(122, 28)
        Me.Blockaddressloadbutton.TabIndex = 161
        Me.Blockaddressloadbutton.Text = "Loadfromxml"
        Me.Blockaddressloadbutton.UseVisualStyleBackColor = True
        '
        'Blockaddresssavebutton
        '
        Me.Blockaddresssavebutton.Location = New System.Drawing.Point(676, 284)
        Me.Blockaddresssavebutton.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.Blockaddresssavebutton.Name = "Blockaddresssavebutton"
        Me.Blockaddresssavebutton.Size = New System.Drawing.Size(122, 28)
        Me.Blockaddresssavebutton.TabIndex = 160
        Me.Blockaddresssavebutton.Text = "Savetoxml"
        Me.Blockaddresssavebutton.UseVisualStyleBackColor = True
        '
        'DataGridView6
        '
        Me.DataGridView6.AllowUserToAddRows = False
        Me.DataGridView6.AllowUserToDeleteRows = False
        Me.DataGridView6.AllowUserToResizeColumns = False
        Me.DataGridView6.AllowUserToResizeRows = False
        Me.DataGridView6.AutoGenerateColumns = False
        Me.DataGridView6.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridView6.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText
        Me.DataGridView6.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView6.DataSource = Me.BindingSource6
        Me.DataGridView6.Location = New System.Drawing.Point(676, 156)
        Me.DataGridView6.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.DataGridView6.Name = "DataGridView6"
        Me.DataGridView6.RowHeadersVisible = False
        Me.DataGridView6.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect
        Me.DataGridView6.Size = New System.Drawing.Size(248, 122)
        Me.DataGridView6.TabIndex = 159
        '
        'Choose
        '
        Me.Choose.Location = New System.Drawing.Point(561, 284)
        Me.Choose.Name = "Choose"
        Me.Choose.Size = New System.Drawing.Size(86, 72)
        Me.Choose.TabIndex = 157
        Me.Choose.Text = "Choose ECU ROM file"
        Me.Choose.UseVisualStyleBackColor = True
        '
        'Removeconfigrowbutton
        '
        Me.Removeconfigrowbutton.Location = New System.Drawing.Point(557, 147)
        Me.Removeconfigrowbutton.Name = "Removeconfigrowbutton"
        Me.Removeconfigrowbutton.Size = New System.Drawing.Size(35, 25)
        Me.Removeconfigrowbutton.TabIndex = 117
        Me.Removeconfigrowbutton.Text = "y-"
        Me.Removeconfigrowbutton.UseVisualStyleBackColor = True
        '
        'Addconfigrowbutton
        '
        Me.Addconfigrowbutton.Location = New System.Drawing.Point(557, 116)
        Me.Addconfigrowbutton.Name = "Addconfigrowbutton"
        Me.Addconfigrowbutton.Size = New System.Drawing.Size(35, 25)
        Me.Addconfigrowbutton.TabIndex = 116
        Me.Addconfigrowbutton.Text = "y+"
        Me.Addconfigrowbutton.UseVisualStyleBackColor = True
        '
        'Configloadbutton
        '
        Me.Configloadbutton.Location = New System.Drawing.Point(683, 82)
        Me.Configloadbutton.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.Configloadbutton.Name = "Configloadbutton"
        Me.Configloadbutton.Size = New System.Drawing.Size(122, 28)
        Me.Configloadbutton.TabIndex = 115
        Me.Configloadbutton.Text = "Loadfromxml"
        Me.Configloadbutton.UseVisualStyleBackColor = True
        '
        'Configsavebutton
        '
        Me.Configsavebutton.Location = New System.Drawing.Point(557, 82)
        Me.Configsavebutton.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.Configsavebutton.Name = "Configsavebutton"
        Me.Configsavebutton.Size = New System.Drawing.Size(122, 28)
        Me.Configsavebutton.TabIndex = 114
        Me.Configsavebutton.Text = "Savetoxml"
        Me.Configsavebutton.UseVisualStyleBackColor = True
        '
        'DataGridView3
        '
        Me.DataGridView3.AllowUserToAddRows = False
        Me.DataGridView3.AllowUserToDeleteRows = False
        Me.DataGridView3.AllowUserToResizeColumns = False
        Me.DataGridView3.AllowUserToResizeRows = False
        Me.DataGridView3.AutoGenerateColumns = False
        Me.DataGridView3.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridView3.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText
        Me.DataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView3.DataSource = Me.BindingSource3
        Me.DataGridView3.Location = New System.Drawing.Point(2, 22)
        Me.DataGridView3.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.DataGridView3.Name = "DataGridView3"
        Me.DataGridView3.RowHeadersVisible = False
        Me.DataGridView3.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect
        Me.DataGridView3.Size = New System.Drawing.Size(550, 500)
        Me.DataGridView3.TabIndex = 113
        '
        'Startstopbutton
        '
        Me.Startstopbutton.Font = New System.Drawing.Font("Tahoma", 10.0!, System.Drawing.FontStyle.Bold)
        Me.Startstopbutton.Location = New System.Drawing.Point(557, 22)
        Me.Startstopbutton.Name = "Startstopbutton"
        Me.Startstopbutton.Size = New System.Drawing.Size(248, 54)
        Me.Startstopbutton.TabIndex = 72
        Me.Startstopbutton.Text = "Start"
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage4)
        Me.TabControl1.Controls.Add(Me.TabPage5)
        Me.TabControl1.Controls.Add(Me.TabPage6)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl1.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabControl1.Location = New System.Drawing.Point(0, 0)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(1192, 716)
        Me.TabControl1.TabIndex = 73
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.MAP)
        Me.TabPage3.Controls.Add(Me.Label30)
        Me.TabPage3.Controls.Add(Me.RPM)
        Me.TabPage3.Controls.Add(Me.Label31)
        Me.TabPage3.Controls.Add(Me.EngLoad)
        Me.TabPage3.Controls.Add(Me.Label32)
        Me.TabPage3.Controls.Add(Me.TPS)
        Me.TabPage3.Controls.Add(Me.Label33)
        Me.TabPage3.Controls.Add(Me.IPW)
        Me.TabPage3.Controls.Add(Me.Label34)
        Me.TabPage3.Controls.Add(Me.Knock)
        Me.TabPage3.Controls.Add(Me.Label35)
        Me.TabPage3.Controls.Add(Me.Ign)
        Me.TabPage3.Controls.Add(Me.Label36)
        Me.TabPage3.Controls.Add(Me.O2)
        Me.TabPage3.Controls.Add(Me.Label38)
        Me.TabPage3.Controls.Add(Me.Air)
        Me.TabPage3.Controls.Add(Me.Label26)
        Me.TabPage3.Controls.Add(Me.Coolant)
        Me.TabPage3.Controls.Add(Me.Label27)
        Me.TabPage3.Controls.Add(Me.Batt)
        Me.TabPage3.Controls.Add(Me.Label28)
        Me.TabPage3.Controls.Add(Me.Oct)
        Me.TabPage3.Controls.Add(Me.Label29)
        Me.TabPage3.Controls.Add(Me.STFT)
        Me.TabPage3.Controls.Add(Me.Label24)
        Me.TabPage3.Controls.Add(Me.FTHi)
        Me.TabPage3.Controls.Add(Me.Label25)
        Me.TabPage3.Controls.Add(Me.FTMed)
        Me.TabPage3.Controls.Add(Me.Label23)
        Me.TabPage3.Controls.Add(Me.FTLo)
        Me.TabPage3.Controls.Add(Me.Label22)
        Me.TabPage3.Controls.Add(Me.Chartcheckbox)
        Me.TabPage3.Controls.Add(Me.ZedGraphControl1)
        Me.TabPage3.Location = New System.Drawing.Point(4, 27)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(1184, 685)
        Me.TabPage3.TabIndex = 7
        Me.TabPage3.Text = "Chart"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'MAP
        '
        Me.MAP.Location = New System.Drawing.Point(685, 540)
        Me.MAP.Name = "MAP"
        Me.MAP.Size = New System.Drawing.Size(79, 26)
        Me.MAP.TabIndex = 37
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(608, 543)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(37, 18)
        Me.Label30.TabIndex = 36
        Me.Label30.Text = "MAP"
        '
        'RPM
        '
        Me.RPM.Location = New System.Drawing.Point(685, 506)
        Me.RPM.Name = "RPM"
        Me.RPM.Size = New System.Drawing.Size(79, 26)
        Me.RPM.TabIndex = 35
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Location = New System.Drawing.Point(608, 509)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(37, 18)
        Me.Label31.TabIndex = 34
        Me.Label31.Text = "RPM"
        '
        'EngLoad
        '
        Me.EngLoad.Location = New System.Drawing.Point(685, 473)
        Me.EngLoad.Name = "EngLoad"
        Me.EngLoad.Size = New System.Drawing.Size(79, 26)
        Me.EngLoad.TabIndex = 33
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Location = New System.Drawing.Point(608, 476)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(39, 18)
        Me.Label32.TabIndex = 32
        Me.Label32.Text = "Load"
        '
        'TPS
        '
        Me.TPS.Location = New System.Drawing.Point(685, 439)
        Me.TPS.Name = "TPS"
        Me.TPS.Size = New System.Drawing.Size(79, 26)
        Me.TPS.TabIndex = 31
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Location = New System.Drawing.Point(608, 442)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(34, 18)
        Me.Label33.TabIndex = 30
        Me.Label33.Text = "TPS"
        '
        'IPW
        '
        Me.IPW.Location = New System.Drawing.Point(685, 405)
        Me.IPW.Name = "IPW"
        Me.IPW.Size = New System.Drawing.Size(79, 26)
        Me.IPW.TabIndex = 29
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Location = New System.Drawing.Point(608, 408)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(36, 18)
        Me.Label34.TabIndex = 28
        Me.Label34.Text = "IPW"
        '
        'Knock
        '
        Me.Knock.Location = New System.Drawing.Point(685, 371)
        Me.Knock.Name = "Knock"
        Me.Knock.Size = New System.Drawing.Size(79, 26)
        Me.Knock.TabIndex = 27
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Location = New System.Drawing.Point(608, 374)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(47, 18)
        Me.Label35.TabIndex = 26
        Me.Label35.Text = "Knock"
        '
        'Ign
        '
        Me.Ign.Location = New System.Drawing.Point(685, 338)
        Me.Ign.Name = "Ign"
        Me.Ign.Size = New System.Drawing.Size(79, 26)
        Me.Ign.TabIndex = 25
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Location = New System.Drawing.Point(608, 341)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(55, 18)
        Me.Label36.TabIndex = 24
        Me.Label36.Text = "Ignition"
        '
        'O2
        '
        Me.O2.Location = New System.Drawing.Point(685, 304)
        Me.O2.Name = "O2"
        Me.O2.Size = New System.Drawing.Size(79, 26)
        Me.O2.TabIndex = 23
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Location = New System.Drawing.Point(608, 307)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(27, 18)
        Me.Label38.TabIndex = 22
        Me.Label38.Text = "O2"
        '
        'Air
        '
        Me.Air.Location = New System.Drawing.Point(685, 268)
        Me.Air.Name = "Air"
        Me.Air.Size = New System.Drawing.Size(79, 26)
        Me.Air.TabIndex = 21
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(608, 271)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(63, 18)
        Me.Label26.TabIndex = 20
        Me.Label26.Text = "Air temp"
        '
        'Coolant
        '
        Me.Coolant.Location = New System.Drawing.Point(685, 234)
        Me.Coolant.Name = "Coolant"
        Me.Coolant.Size = New System.Drawing.Size(79, 26)
        Me.Coolant.TabIndex = 19
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(608, 237)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(56, 18)
        Me.Label27.TabIndex = 18
        Me.Label27.Text = "Coolant"
        '
        'Batt
        '
        Me.Batt.Location = New System.Drawing.Point(685, 201)
        Me.Batt.Name = "Batt"
        Me.Batt.Size = New System.Drawing.Size(79, 26)
        Me.Batt.TabIndex = 17
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(608, 204)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(56, 18)
        Me.Label28.TabIndex = 16
        Me.Label28.Text = "Battery"
        '
        'Oct
        '
        Me.Oct.Location = New System.Drawing.Point(685, 167)
        Me.Oct.Name = "Oct"
        Me.Oct.Size = New System.Drawing.Size(79, 26)
        Me.Oct.TabIndex = 15
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(608, 170)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(55, 18)
        Me.Label29.TabIndex = 14
        Me.Label29.Text = "Octane"
        '
        'STFT
        '
        Me.STFT.Location = New System.Drawing.Point(685, 133)
        Me.STFT.Name = "STFT"
        Me.STFT.Size = New System.Drawing.Size(79, 26)
        Me.STFT.TabIndex = 13
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(608, 136)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(44, 18)
        Me.Label24.TabIndex = 12
        Me.Label24.Text = "STFT"
        '
        'FTHi
        '
        Me.FTHi.Location = New System.Drawing.Point(685, 99)
        Me.FTHi.Name = "FTHi"
        Me.FTHi.Size = New System.Drawing.Size(79, 26)
        Me.FTHi.TabIndex = 11
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(608, 102)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(43, 18)
        Me.Label25.TabIndex = 10
        Me.Label25.Text = "FT Hi"
        '
        'FTMed
        '
        Me.FTMed.Location = New System.Drawing.Point(685, 66)
        Me.FTMed.Name = "FTMed"
        Me.FTMed.Size = New System.Drawing.Size(79, 26)
        Me.FTMed.TabIndex = 9
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(608, 69)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(59, 18)
        Me.Label23.TabIndex = 8
        Me.Label23.Text = "FT Med"
        '
        'FTLo
        '
        Me.FTLo.Location = New System.Drawing.Point(685, 32)
        Me.FTLo.Name = "FTLo"
        Me.FTLo.Size = New System.Drawing.Size(79, 26)
        Me.FTLo.TabIndex = 7
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(608, 35)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(46, 18)
        Me.Label22.TabIndex = 6
        Me.Label22.Text = "FT Lo"
        '
        'Chartcheckbox
        '
        Me.Chartcheckbox.AutoSize = True
        Me.Chartcheckbox.Checked = True
        Me.Chartcheckbox.CheckState = System.Windows.Forms.CheckState.Checked
        Me.Chartcheckbox.Location = New System.Drawing.Point(0, 6)
        Me.Chartcheckbox.Name = "Chartcheckbox"
        Me.Chartcheckbox.Size = New System.Drawing.Size(62, 22)
        Me.Chartcheckbox.TabIndex = 1
        Me.Chartcheckbox.Text = "Chart"
        Me.Chartcheckbox.UseVisualStyleBackColor = True
        '
        'ZedGraphControl1
        '
        Me.ZedGraphControl1.Location = New System.Drawing.Point(0, 32)
        Me.ZedGraphControl1.Margin = New System.Windows.Forms.Padding(4)
        Me.ZedGraphControl1.Name = "ZedGraphControl1"
        Me.ZedGraphControl1.ScrollGrace = 0
        Me.ZedGraphControl1.ScrollMaxX = 0
        Me.ZedGraphControl1.ScrollMaxY = 0
        Me.ZedGraphControl1.ScrollMaxY2 = 0
        Me.ZedGraphControl1.ScrollMinX = 0
        Me.ZedGraphControl1.ScrollMinY = 0
        Me.ZedGraphControl1.ScrollMinY2 = 0
        Me.ZedGraphControl1.Size = New System.Drawing.Size(563, 538)
        Me.ZedGraphControl1.TabIndex = 5
        '
        'TabPage2
        '
        Me.TabPage2.Location = New System.Drawing.Point(4, 27)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(1184, 685)
        Me.TabPage2.TabIndex = 8
        Me.TabPage2.Text = "Speed Density"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.Filter = "Hex|*.hex|Bin|*.bin|All|*.*"
        Me.OpenFileDialog1.InitialDirectory = "Desktop"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1192, 716)
        Me.Controls.Add(Me.TabControl1)
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Evo Live Map"
        Me.TabPage6.ResumeLayout(False)
        Me.TabPage6.PerformLayout()
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BindingSource2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage5.ResumeLayout(False)
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage4.ResumeLayout(False)
        Me.TabPage4.PerformLayout()
        CType(Me.DataGridView5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BindingSource5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BindingSource4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        CType(Me.DataGridView6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BindingSource6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BindingSource3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage3.PerformLayout()
        CType(Me.BindingSource8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BindingSource7, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents TabPage6 As System.Windows.Forms.TabPage
    Friend WithEvents Writeignitionbutton As System.Windows.Forms.Button
    Friend WithEvents Readignitionbutton As System.Windows.Forms.Button
    Friend WithEvents DataGridView2 As System.Windows.Forms.DataGridView
    Friend WithEvents TabPage5 As System.Windows.Forms.TabPage
    Friend WithEvents Writefuelbutton As System.Windows.Forms.Button
    Friend WithEvents Readfuelbutton As System.Windows.Forms.Button
    Public WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents Startstopbutton As System.Windows.Forms.Button
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents BindingSource2 As System.Windows.Forms.BindingSource
    Friend WithEvents BindingSource1 As System.Windows.Forms.BindingSource
    Friend WithEvents Copyignitionbutton As System.Windows.Forms.Button
    Friend WithEvents Pasteignitionbutton As System.Windows.Forms.Button
    Friend WithEvents Pastefuelbutton As System.Windows.Forms.Button
    Friend WithEvents Copyfuelbutton As System.Windows.Forms.Button
    Friend WithEvents Savefuelbutton As System.Windows.Forms.Button
    Friend WithEvents Loadfuelbutton As System.Windows.Forms.Button
    Friend WithEvents Loadignitionbutton As System.Windows.Forms.Button
    Friend WithEvents Saveignitionbutton As System.Windows.Forms.Button
    Friend WithEvents BindingSource3 As System.Windows.Forms.BindingSource
    Public WithEvents DataGridView3 As System.Windows.Forms.DataGridView
    Friend WithEvents Configloadbutton As System.Windows.Forms.Button
    Friend WithEvents Configsavebutton As System.Windows.Forms.Button
    Friend WithEvents Removefuelrowbutton As System.Windows.Forms.Button
    Friend WithEvents Addfuelrowbutton As System.Windows.Forms.Button
    Friend WithEvents Removefuelcolumnbutton As System.Windows.Forms.Button
    Friend WithEvents Addfuelcolumnbutton As System.Windows.Forms.Button
    Friend WithEvents Removeignitionrowbutton As System.Windows.Forms.Button
    Friend WithEvents Addignitionrowbutton As System.Windows.Forms.Button
    Friend WithEvents Removeignitioncolumnbutton As System.Windows.Forms.Button
    Friend WithEvents Addignitioncolumnbutton As System.Windows.Forms.Button
    Public WithEvents DataGridView4 As System.Windows.Forms.DataGridView
    Friend WithEvents BindingSource4 As System.Windows.Forms.BindingSource
    Friend WithEvents Addressloadbutton As System.Windows.Forms.Button
    Friend WithEvents Addresssavebutton As System.Windows.Forms.Button
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Removeconfigrowbutton As System.Windows.Forms.Button
    Friend WithEvents Addconfigrowbutton As System.Windows.Forms.Button
    Friend WithEvents Ignitionrecolor As System.Windows.Forms.Button
    Friend WithEvents Fuelrecolor As System.Windows.Forms.Button
    Friend WithEvents Knockcolorloadbutton As System.Windows.Forms.Button
    Friend WithEvents Knockcolorsavebutton As System.Windows.Forms.Button
    Public WithEvents DataGridView5 As System.Windows.Forms.DataGridView
    Friend WithEvents BindingSource5 As System.Windows.Forms.BindingSource
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents Verify As System.Windows.Forms.CheckBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Success As System.Windows.Forms.TextBox
    Friend WithEvents Write As System.Windows.Forms.Button
    Friend WithEvents ROMfilename As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Blockaddressloadbutton As System.Windows.Forms.Button
    Friend WithEvents Blockaddresssavebutton As System.Windows.Forms.Button
    Public WithEvents DataGridView6 As System.Windows.Forms.DataGridView
    Friend WithEvents Choose As System.Windows.Forms.Button
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Baud As System.Windows.Forms.TextBox
    Friend WithEvents loggingdirectory As System.Windows.Forms.TextBox
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents BindingSource6 As System.Windows.Forms.BindingSource
    Friend WithEvents Clrcolors As System.Windows.Forms.Button
    Friend WithEvents Knocktrace As System.Windows.Forms.CheckBox
    Friend WithEvents selectactivecell As System.Windows.Forms.CheckBox
    Friend WithEvents BindingSource7 As System.Windows.Forms.BindingSource
    Friend WithEvents BindingSource8 As System.Windows.Forms.BindingSource
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents Chartcheckbox As System.Windows.Forms.CheckBox
    Friend WithEvents ZedGraphControl1 As ZedGraph.ZedGraphControl
    Friend WithEvents FTLo As System.Windows.Forms.TextBox
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Air As System.Windows.Forms.TextBox
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Coolant As System.Windows.Forms.TextBox
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Batt As System.Windows.Forms.TextBox
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Oct As System.Windows.Forms.TextBox
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents STFT As System.Windows.Forms.TextBox
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents FTHi As System.Windows.Forms.TextBox
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents FTMed As System.Windows.Forms.TextBox
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents MAP As System.Windows.Forms.TextBox
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents RPM As System.Windows.Forms.TextBox
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents EngLoad As System.Windows.Forms.TextBox
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents TPS As System.Windows.Forms.TextBox
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents IPW As System.Windows.Forms.TextBox
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents Knock As System.Windows.Forms.TextBox
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents Ign As System.Windows.Forms.TextBox
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents O2 As System.Windows.Forms.TextBox
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage

End Class
