Imports ZedGraph

Public Class Form1

#Region "Global variables"
    Dim i As Single
    Dim a, b, x, y, logging As Integer
    Dim Logger As System.IO.TextWriter
    Dim config As New DataTable("config")
    Dim address As New DataTable("address")
    Dim blockaddress As New DataTable("blockaddress")
    Dim fuel As New DataTable("fuel")
    Dim ignition As New DataTable("ignition")
    Dim knockcolor As New DataTable("knockcolor")
    Dim RPMVE As New DataTable("RPMVE")
    Dim MAPVE As New DataTable("MAPVE")
    Dim random As New Random()
    Dim pointIndex As Integer = 1
    Dim reset As Integer = 0
#End Region

#Region "Form load, setup tables"
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Me.SetStyle(ControlStyles.DoubleBuffer Or ControlStyles.UserPaint Or ControlStyles.AllPaintingInWmPaint, True)
        'Me.UpdateStyles()

        Loadfuelbutton_Click(0, System.EventArgs.Empty)
        Loadignitionbutton_Click(0, System.EventArgs.Empty)
        Configloadbutton_Click(0, System.EventArgs.Empty)
        Addressloadbutton_Click(0, System.EventArgs.Empty)
        Blockaddressloadbutton_Click(0, System.EventArgs.Empty)
        Knockcolorloadbutton_Click(0, System.EventArgs.Empty)

        Dim myPane As GraphPane = ZedGraphControl1.GraphPane
        myPane.Title.IsVisible = False
        myPane.XAxis.Title.IsVisible = False
        myPane.YAxis.Title.IsVisible = False

        ' Save 1200 points.  At 50 ms sample rate, this is one minute
        ' The RollingPointPairList is an efficient storage class that always
        ' keeps a rolling set of point data without needing to shift any data values
        Dim list1 As New RollingPointPairList(1200)
        Dim list2 As New RollingPointPairList(1200)
        Dim list3 As New RollingPointPairList(1200)
        Dim list4 As New RollingPointPairList(1200)
        Dim list5 As New RollingPointPairList(1200)
        Dim list6 As New RollingPointPairList(1200)
        Dim list7 As New RollingPointPairList(1200)
        Dim list8 As New RollingPointPairList(1200)

        ' Initially, a curve is added with no data points (list is empty)
        Dim curve1 As LineItem = myPane.AddCurve("O2", list1, Color.Blue, SymbolType.None)
        Dim curve2 As LineItem = myPane.AddCurve("Ignition", list2, Color.Red, SymbolType.None)
        Dim curve3 As LineItem = myPane.AddCurve("Knock", list3, Color.Green, SymbolType.None)
        Dim curve4 As LineItem = myPane.AddCurve("IPW", list4, Color.Yellow, SymbolType.None)
        Dim curve5 As LineItem = myPane.AddCurve("TPS", list5, Color.Violet, SymbolType.None)
        Dim curve6 As LineItem = myPane.AddCurve("Load", list6, Color.Cyan, SymbolType.None)
        Dim curve7 As LineItem = myPane.AddCurve("RPM", list7, Color.Chocolate, SymbolType.None)
        Dim curve8 As LineItem = myPane.AddCurve("MAP", list8, Color.Orange, SymbolType.None)

        ' Just manually control the X axis range so it scrolls continuously
        ' instead of discrete step-sized jumps
        myPane.XAxis.Scale.Min = 0
        myPane.XAxis.Scale.Max = 200
        myPane.XAxis.Scale.MinorStep = 10
        myPane.XAxis.Scale.MajorStep = 50

        ' Scale the axes
        ZedGraphControl1.AxisChange()


    End Sub
#End Region

#Region "Start/stop logging button - setup port, break on/off, init"
    Private Sub Startstopbutton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Startstopbutton.Click
        If Startstopbutton.Text = "Start" Then
            FT_Status = FT_OpenByIndex(0, FT_Handle)
            If FT_Status <> FT_OK Then
                MsgBox("Unable to open port")
                Exit Sub
            End If
            Startstopbutton.Text = "Stop"
            FT_Status = FT_ResetDevice(FT_Handle)
            FT_Status = FT_Purge(FT_Handle, FT_PURGE_RX Or FT_PURGE_TX)
            FT_Status = FT_SetTimeouts(FT_Handle, 500, 500)
            FT_Status = FT_SetLatencyTimer(FT_Handle, 1)
            FT_Status = FT_SetBaudRate(FT_Handle, Val(Baud.Text))
            FT_Status = FT_SetBreakOn(FT_Handle)
            Sleep(1800)
            FT_Status = FT_SetBreakOff(FT_Handle)
            Sleep(400)

            'Get bytes waiting to be read
            FT_Status = FT_GetQueueStatus(FT_Handle, FT_RxQ_Bytes)
            Read_Data_Bytes(FT_RxQ_Bytes)
            If FT_Status <> FT_OK Or FT_RxQ_Bytes < 1 Then
                MsgBox("Init failed")
                Startstopbutton.Text = "Start"
                Close_USB_Device()
                Exit Sub
            End If

            logging = True
            StartLogger()
            Timer1.Enabled = True
        ElseIf Startstopbutton.Text = "Stop" Then
            Startstopbutton.Text = "Start"
            Close_USB_Device()
            logging = False
            Closelog()
        End If
    End Sub
#End Region

#Region "Main logging loop on Timer"
    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Timer1.Enabled = False
        Dim outp As New System.Text.StringBuilder
        outp.Capacity = 300
        outp.Append(Strings.Right("00" & DateTime.Now.Hour, 2) & ":" _
               & Strings.Right("00" & DateTime.Now.Minute, 2) & ":" _
              & Strings.Right("00" & DateTime.Now.Second, 2) & "." _
              & Strings.Right("000" & DateTime.Now.Millisecond, 3) & ",")

        If sendDMA(config.Rows.Count) = 1 Then
            For x = 0 To config.Rows.Count - 1
                y = config.Rows(x).Item("Round")
                i = FT_In_Buffer(x)
                i = i * config.Rows(x).Item("Mult") + config.Rows(x).Item("Add")
                i = Math.Round(i, y)
                outp.Append(i.ToString + ",")
            Next
        End If

        If Knocktrace.Checked = True Then knockplot()
        If Chartcheckbox.Checked = True Then chart()
        If logging = True Then
            Logger.WriteLine(outp)
            Timer1.Enabled = True
        End If
    End Sub
#End Region

#Region "Knock plot"

    Private Sub knockplot()

        Dim rpm, load As Single
        Dim finalrpmrow, finalloadcolumn As Integer
        Dim finaldifference, thisdifference As Single
        Dim knock As Integer
        Dim i As Integer
        Dim j As String
        load = 1.2 * FT_In_Buffer(&H0)
        rpm = 31.25 * FT_In_Buffer(&HB)
        knock = FT_In_Buffer(&HC)
        If knock > knockcolor.Rows.Count - 1 Then knock = knockcolor.Rows.Count - 1

        finaldifference = 9999
        For x = 1 To ignition.Columns.Count - 1
            thisdifference = Math.Abs(load - ignition.Rows(0).Item(x))
            If thisdifference <= finaldifference Then
                finaldifference = thisdifference
                finalloadcolumn = x
            End If
        Next

        finaldifference = 9999
        For y = 1 To ignition.Rows.Count - 1
            thisdifference = Math.Abs(rpm - ignition.Rows(y).Item(0))
            If thisdifference <= finaldifference Then
                finaldifference = thisdifference
                finalrpmrow = y
            End If
        Next

        j = DataGridView2.Item(finalloadcolumn, finalrpmrow).ToolTipText
        If j <> "" Then
            i = Val(j)
        Else
            i = -1
        End If
        If knock > i Then
            DataGridView2.Item(finalloadcolumn, finalrpmrow).Style.BackColor = _
            Color.FromArgb(knockcolor.Rows(knock).Item(0), knockcolor.Rows(knock).Item(1), knockcolor.Rows(knock).Item(2))
            DataGridView2.Item(finalloadcolumn, finalrpmrow).ToolTipText = knock.ToString
        End If

        If selectactivecell.Checked = True Then
            DataGridView2.ClearSelection()
            'DataGridView2.Item(finalloadcolumn, finalrpmrow).Selected = True
            DataGridView2.Item(0, finalrpmrow).Selected = True
            DataGridView2.Item(finalloadcolumn, 0).Selected = True
        End If
    End Sub

#End Region

#Region "'Send' (comms) Functions"
    Private Function sendDMA(ByVal number As Byte)
        Dim Read_Result As Integer
        If logging = True Then
            FT_Out_Buffer(0) = &HE0
            Write_Data_Bytes(1)
            Read_Data_Bytes(1)
            Sleep(10) 'Min 1 for 15625,2 for 38400
            FT_Out_Buffer(0) = Val("&H" + blockaddress.Rows(3).Item(0).ToString)
            FT_Out_Buffer(1) = Val("&H" + blockaddress.Rows(3).Item(1).ToString)
            FT_Out_Buffer(2) = Val("&H" + blockaddress.Rows(3).Item(2).ToString)
            FT_Out_Buffer(3) = Val("&H" + blockaddress.Rows(3).Item(3).ToString)
            FT_Out_Buffer(4) = 0
            FT_Out_Buffer(5) = number
            Write_Data_Bytes(6)
            ' Make sure the Y axis is rescaled to accommodate actual data
            'If pointIndex Mod 4 = 0 Then
            ZedGraphControl1.AxisChange()
            ' Force a redraw
            ZedGraphControl1.Invalidate()
            'End If
            Read_Data_Bytes(6)
            FT_Status = FT_Read_Bytes(FT_Handle, FT_In_Buffer(0), number, Read_Result)
            If FT_Status <> FT_OK Or Read_Result <> number Then
                MsgBox("Read_Result " + Read_Result.ToString)
                Startstopbutton.Text = "Start"
                Close_USB_Device()
                logging = False
                Closelog()
                Return 0
                Exit Function
            End If
        Else
            Return 0
            Exit Function
        End If
        Return 1
    End Function
    Private Function sendbyte(ByVal request As Byte)
        Dim j As Integer
        If logging = True Then
            FT_Out_Buffer(0) = request
            Write_Data_Bytes(1)
            Read_Data_Bytes(2)
            If FT_Status <> FT_OK Then
                Startstopbutton.Text = "Start"
                Close_USB_Device()
                logging = False
                Closelog()
                Return 0
                Exit Function
            End If
            j = FT_In_Buffer(1)
        Else
            j = 0
        End If
        Return j
    End Function
#End Region

#Region "Log file open/close"
    Private Sub OpenLog(ByVal fName As String)
        Readfuelbutton.Enabled = True
        Writefuelbutton.Enabled = True
        Readignitionbutton.Enabled = True
        Writeignitionbutton.Enabled = True
        Logger = New System.IO.StreamWriter(fName)
        Writelogfirstline()
    End Sub
    Private Sub Writelogfirstline()
        Dim outp As New System.Text.StringBuilder
        outp.Capacity = 1000
        outp.Append(Baud.Text + "baud,")
        For x = 0 To config.Rows.Count - 1
            outp.Append(config.Rows(x).Item("Ref") + "(" + config.Rows(x).Item("Unit") + "),")
        Next
        Logger.WriteLine(outp)
    End Sub
    Private Sub Closelog()
        Readfuelbutton.Enabled = False
        Writefuelbutton.Enabled = False
        Readignitionbutton.Enabled = False
        Writeignitionbutton.Enabled = False
        Logger.Close()
    End Sub
    Private Sub StartLogger()
        OpenLog(loggingdirectory.Text _
                & DateTime.Now.Year & "-" _
                & Strings.Right("00" & DateTime.Now.Month, 2) & "-" _
                & Strings.Right("00" & DateTime.Now.Day, 2) & "-" _
                & Strings.Right("00" & DateTime.Now.Hour, 2) _
                & Strings.Right("00" & DateTime.Now.Minute, 2) _
                & Strings.Right("00" & DateTime.Now.Second, 2) & ".csv")
    End Sub
#End Region

#Region "Buttons"
#Region "Buttons for config loadxml/savexml"
    Private Sub Configsavebutton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Configsavebutton.Click
        Dim xmlout As System.IO.StreamWriter
        xmlout = New System.IO.StreamWriter("config.xml")
        config.WriteXml(xmlout, System.Data.XmlWriteMode.WriteSchema, False)
        xmlout.Close()
    End Sub
    Private Sub Configloadbutton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Configloadbutton.Click
        Dim xmlin As System.IO.StreamReader
        DataGridView3.AutoGenerateColumns = True
        BindingSource3.DataSource = config
        config.Clear()
        config.Columns.Clear()
        xmlin = New System.IO.StreamReader("config.xml")
        config.ReadXml(xmlin)
        xmlin.Close()
        'config.Columns("Result").Expression = "Value * Mult + Add"
        DataGridView3.Refresh()
    End Sub
#End Region
#Region "Buttons for config rows add/remove"
    Private Sub Addconfigrowbutton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Addconfigrowbutton.Click
        config.Rows.Add()
    End Sub

    Private Sub Removeconfigrowbutton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Removeconfigrowbutton.Click
        config.Rows.RemoveAt(config.Rows.Count - 1)
    End Sub
#End Region

#Region "Buttons for address loadxml/savexml"
    Private Sub Addresssavebutton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Addresssavebutton.Click
        Dim xmlout As System.IO.StreamWriter
        xmlout = New System.IO.StreamWriter("address.xml")
        address.WriteXml(xmlout, System.Data.XmlWriteMode.WriteSchema, False)
        xmlout.Close()
    End Sub
    Private Sub Addressloadbutton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Addressloadbutton.Click
        Dim xmlin As System.IO.StreamReader
        DataGridView4.AutoGenerateColumns = True
        BindingSource4.DataSource = address
        address.Clear()
        address.Columns.Clear()
        xmlin = New System.IO.StreamReader("address.xml")
        address.ReadXml(xmlin)
        xmlin.Close()
    End Sub
#End Region
#Region "Block Address table loadxml/savexml"
    Private Sub Blockaddresssavebutton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Blockaddresssavebutton.Click
        Dim xmlout As System.IO.StreamWriter
        xmlout = New System.IO.StreamWriter("blockaddress.xml")
        blockaddress.WriteXml(xmlout, System.Data.XmlWriteMode.WriteSchema, False)
        xmlout.Close()
    End Sub
    Private Sub Blockaddressloadbutton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Blockaddressloadbutton.Click
        Dim xmlin As System.IO.StreamReader
        DataGridView6.AutoGenerateColumns = True
        BindingSource6.DataSource = blockaddress
        blockaddress.Clear()
        blockaddress.Columns.Clear()
        xmlin = New System.IO.StreamReader("blockaddress.xml")
        blockaddress.ReadXml(xmlin)
        xmlin.Close()
    End Sub
#End Region

#Region "Buttons for fuel and ignition columns/rows add/remove"
    Private Sub Addfuelcolumnbutton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Addfuelcolumnbutton.Click
        fuel.Columns.Add(fuel.Columns.Count, System.Type.GetType("System.Single"))
    End Sub
    Private Sub Addfuelrowbutton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Addfuelrowbutton.Click
        fuel.Rows.Add()
    End Sub
    Private Sub Removefuelcolumnbutton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Removefuelcolumnbutton.Click
        fuel.Columns.Remove(fuel.Columns.Count - 1)
    End Sub
    Private Sub Removefuelrowbutton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Removefuelrowbutton.Click
        fuel.Rows.RemoveAt(fuel.Rows.Count - 1)
    End Sub
    Private Sub Addignitioncolumnbutton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Addignitioncolumnbutton.Click
        ignition.Columns.Add(ignition.Columns.Count, System.Type.GetType("System.Int16"))
    End Sub
    Private Sub Addignitionrowbutton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Addignitionrowbutton.Click
        ignition.Rows.Add()
    End Sub
    Private Sub Removeignitioncolumnbutton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Removeignitioncolumnbutton.Click
        ignition.Columns.Remove(ignition.Columns.Count - 1)
    End Sub
    Private Sub Removeignitionrowbutton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Removeignitionrowbutton.Click
        ignition.Rows.RemoveAt(ignition.Rows.Count - 1)
    End Sub
#End Region
#Region "Buttons for fuel and ignition read/write ECU RAM"
    Private Sub Readfuelbutton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Readfuelbutton.Click
        Dim c As Integer = 0
        Dim d As Integer
        Dim i As Single

        FT_Out_Buffer(0) = &HE1
        Write_Data_Bytes(1)
        Read_Data_Bytes(1)
        Sleep(10)
        d = (fuel.Columns.Count - 1) * (fuel.Rows.Count - 1)
        FT_Out_Buffer(0) = &HFF
        FT_Out_Buffer(1) = &HFF
        FT_Out_Buffer(2) = Val("&H" + address.Rows(0).Item(0).ToString)
        FT_Out_Buffer(3) = Val("&H" + address.Rows(0).Item(1).ToString)
        FT_Out_Buffer(4) = d \ 256
        FT_Out_Buffer(5) = d Mod 256
        Write_Data_Bytes(6)
        Read_Data_Bytes(6)
        Read_Data_Bytes(d)
        For x = 1 To fuel.Columns.Count - 1
            For y = 1 To fuel.Rows.Count - 1
                i = FT_In_Buffer(c)
                i = 14.7 * 128 / i ' convert to afr
                i = System.Math.Round(i, 1) 'round to 1 dec pl
                fuel.Rows(y).Item(x) = i
                c = c + 1
            Next
        Next
        DataGridView1.Refresh()
    End Sub
    Private Sub Writefuelbutton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Writefuelbutton.Click
        Dim c As Integer = 0
        Dim d As Integer
        Dim i As Single
        FT_Out_Buffer(0) = &HE2
        Write_Data_Bytes(1)
        Read_Data_Bytes(1)
        Sleep(10)
        d = (fuel.Columns.Count - 1) * (fuel.Rows.Count - 1)
        FT_Out_Buffer(0) = &HFF
        FT_Out_Buffer(1) = &HFF
        FT_Out_Buffer(2) = Val("&H" + address.Rows(0).Item(0).ToString)
        FT_Out_Buffer(3) = Val("&H" + address.Rows(0).Item(1).ToString)
        FT_Out_Buffer(4) = d \ 256
        FT_Out_Buffer(5) = d Mod 256
        Write_Data_Bytes(6)
        For x = 1 To fuel.Columns.Count - 1
            For y = 1 To fuel.Rows.Count - 1
                i = fuel.Rows(y).Item(x)
                'If i < 0 Then i = i + 256
                i = 128 * 14.7 / i ' convert to dec
                i = System.Math.Round(i, 0) 'round to 0 dec pl
                i = Int(i)
                FT_Out_Buffer(c) = i
                c = c + 1
            Next
        Next
        Write_Data_Bytes(d)
        Read_Data_Bytes(d + 6)
    End Sub
    Private Sub Readignitionbutton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Readignitionbutton.Click
        Dim c As Integer = 0
        Dim d As Integer
        Dim i As Integer

        FT_Out_Buffer(0) = &HE1
        Write_Data_Bytes(1)
        Read_Data_Bytes(1)
        Sleep(10)
        d = (ignition.Columns.Count - 1) * (ignition.Rows.Count - 1)
        FT_Out_Buffer(0) = &HFF
        FT_Out_Buffer(1) = &HFF
        FT_Out_Buffer(2) = Val("&H" + address.Rows(1).Item(0).ToString)
        FT_Out_Buffer(3) = Val("&H" + address.Rows(1).Item(1).ToString)
        FT_Out_Buffer(4) = d \ 256
        FT_Out_Buffer(5) = d Mod 256
        Write_Data_Bytes(6)
        Read_Data_Bytes(6)
        Read_Data_Bytes(d)
        For x = 1 To ignition.Columns.Count - 1
            For y = 1 To ignition.Rows.Count - 1
                i = FT_In_Buffer(c)
                If i >= 128 Then i = i - 256
                ignition.Rows(y).Item(x) = i
                c = c + 1
            Next
        Next
        DataGridView2.Refresh()
    End Sub
    Private Sub Writeignitionbutton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Writeignitionbutton.Click
        Dim c As Integer = 0
        Dim d As Integer
        Dim i As Integer
        FT_Out_Buffer(0) = &HE2
        Write_Data_Bytes(1)
        Read_Data_Bytes(1)
        Sleep(10)
        d = (ignition.Columns.Count - 1) * (ignition.Rows.Count - 1)
        FT_Out_Buffer(0) = &HFF
        FT_Out_Buffer(1) = &HFF
        FT_Out_Buffer(2) = Val("&H" + address.Rows(1).Item(0).ToString)
        FT_Out_Buffer(3) = Val("&H" + address.Rows(1).Item(1).ToString)
        FT_Out_Buffer(4) = d \ 256
        FT_Out_Buffer(5) = d Mod 256
        Write_Data_Bytes(6)
        For x = 1 To ignition.Columns.Count - 1
            For y = 1 To ignition.Rows.Count - 1
                i = ignition.Rows(y).Item(x)
                If i < 0 Then i = i + 256
                FT_Out_Buffer(c) = i
                c = c + 1
            Next
        Next
        Write_Data_Bytes(d)
        Read_Data_Bytes(d + 6)
    End Sub
#End Region
#Region "Buttons for fuel and ignition copy/paste clipboard"
    Private Sub Copyignitionbutton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Copyignitionbutton.Click
        If DataGridView2.GetCellCount(DataGridViewElementStates.Selected) > 0 Then
            Clipboard.SetDataObject(DataGridView2.GetClipboardContent())
        End If
    End Sub
    Private Sub Pasteignitionbutton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Pasteignitionbutton.Click
        Dim pos As Integer
        Dim s As String = Clipboard.GetText()
        Dim lines() As String = s.Split(vbCr)
        Dim row As Integer = DataGridView2.CurrentCell.RowIndex
        Dim col As Integer = DataGridView2.CurrentCell.ColumnIndex
        Dim line As String
        For Each line In lines
            If row < DataGridView2.RowCount And line.Length > 0 Then
                Dim cells() As String = line.Split(vbTab)
                For pos = 0 To cells.GetLength(0) - 1
                    If (col + pos < DataGridView2.ColumnCount) Then
                        DataGridView2(col + pos, row).Value = Convert.ChangeType(cells(pos), DataGridView2(col + pos, row).ValueType)
                    End If
                Next
            End If
            row = row + 1
        Next
    End Sub
    Private Sub Copyfuelbutton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Copyfuelbutton.Click
        If DataGridView1.GetCellCount(DataGridViewElementStates.Selected) > 0 Then
            Clipboard.SetDataObject(DataGridView1.GetClipboardContent())
        End If
    End Sub
    Private Sub Pastefuelbutton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Pastefuelbutton.Click
        Dim pos As Integer
        Dim s As String = Clipboard.GetText()
        Dim lines() As String = s.Split(vbCr)
        Dim row As Integer = DataGridView1.CurrentCell.RowIndex
        Dim col As Integer = DataGridView1.CurrentCell.ColumnIndex
        Dim line As String
        For Each line In lines
            If row < DataGridView1.RowCount And line.Length > 0 Then
                Dim cells() As String = line.Split(vbTab)
                For pos = 0 To cells.GetLength(0) - 1
                    If (col + pos < DataGridView2.ColumnCount) Then
                        DataGridView1(col + pos, row).Value = System.Math.Round(Convert.ChangeType(cells(pos), DataGridView1(col + pos, row).ValueType), 1)
                    End If
                Next
            End If
            row = row + 1
        Next
    End Sub
#End Region
#Region "Buttons for fuel and ignition loadxml/savexml"
    Private Sub Savefuelbutton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Savefuelbutton.Click
        Dim xmlout As System.IO.StreamWriter
        xmlout = New System.IO.StreamWriter("fuel.xml")
        fuel.WriteXml(xmlout, System.Data.XmlWriteMode.WriteSchema, False)
        xmlout.Close()
    End Sub
    Private Sub Loadfuelbutton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Loadfuelbutton.Click
        DataGridView1.AutoGenerateColumns = True
        BindingSource1.DataSource = fuel
        fuel.Clear()
        fuel.Columns.Clear()
        Dim xmlin As System.IO.StreamReader
        xmlin = New System.IO.StreamReader("fuel.xml")
        fuel.ReadXml(xmlin)
        xmlin.Close()
    End Sub
    Private Sub Saveignitionbutton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Saveignitionbutton.Click
        Dim xmlout As System.IO.StreamWriter
        xmlout = New System.IO.StreamWriter("ignition.xml")
        ignition.WriteXml(xmlout, System.Data.XmlWriteMode.WriteSchema, False)
        xmlout.Close()
    End Sub
    Private Sub Loadignitionbutton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Loadignitionbutton.Click
        DataGridView2.AutoGenerateColumns = True
        BindingSource2.DataSource = ignition
        ignition.Clear()
        ignition.Columns.Clear()
        Dim xmlin As System.IO.StreamReader
        xmlin = New System.IO.StreamReader("ignition.xml")
        ignition.ReadXml(xmlin)
        xmlin.Close()
    End Sub
#End Region
#Region "Buttons for fuel and ignition color"
    Private Sub Ignitionrecolorbutton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Ignitionrecolor.Click
        Dim z As Integer
        For x = 1 To DataGridView2.ColumnCount - 1
            For y = 1 To DataGridView2.RowCount - 1
                If Not (IsDBNull(DataGridView2.Item(x, y).Value)) Then
                    With DataGridView2.Item(x, y)
                        z = .Value
                        .Style.BackColor = Color.FromArgb((205 - z * 5) And 255, 0, (50 + z * 5) And 255)
                    End With
                End If
            Next
        Next
    End Sub

    Private Sub Fuelrecolorbutton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Fuelrecolor.Click
        Dim z As Single
        For x = 1 To DataGridView1.ColumnCount - 1
            For y = 1 To DataGridView1.RowCount - 1
                If Not (IsDBNull(DataGridView1.Item(x, y).Value)) Then
                    With DataGridView1.Item(x, y)
                        z = .Value
                        .Style.BackColor = Color.FromArgb((255 - (z - 9) * 40) And 255, 0, ((z - 9) * 40) And 255)
                    End With
                End If
            Next
        Next
    End Sub

    Private Sub Clrcolors_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Clrcolors.Click
        For x = 1 To DataGridView2.ColumnCount - 1
            For y = 1 To DataGridView2.RowCount - 1
                DataGridView2.Item(x, y).Style.BackColor = Color.FromArgb(255, 255, 255)
                DataGridView2.Item(x, y).ToolTipText = ""
            Next
        Next
    End Sub
#End Region
#Region "Buttons for knock color load/save"
    Private Sub Knockcolorloadbutton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Knockcolorloadbutton.Click
        Dim xmlin As System.IO.StreamReader
        DataGridView5.AutoGenerateColumns = True
        BindingSource5.DataSource = knockcolor
        knockcolor.Clear()
        knockcolor.Columns.Clear()
        xmlin = New System.IO.StreamReader("knockcolor.xml")
        knockcolor.ReadXml(xmlin)
        xmlin.Close()
        DataGridView5.Refresh()
    End Sub
    Private Sub Knockcolorsavebutton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Knockcolorsavebutton.Click
        Dim xmlout As System.IO.StreamWriter
        xmlout = New System.IO.StreamWriter("knockcolor.xml")
        knockcolor.WriteXml(xmlout, System.Data.XmlWriteMode.WriteSchema, False)
        xmlout.Close()
    End Sub
#End Region
#End Region


#Region "Choose ROM file"
    Private Sub Choose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Choose.Click
        OpenFileDialog1.ShowDialog()
        ROMfilename.Text = OpenFileDialog1.FileName
    End Sub
#End Region

#Region "Write/verify ECU RAM"

    Private Sub Write_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Write.Click
        FT_Status = FT_SetTimeouts(FT_Handle, 5000, 5000)
        Dim fileContents As Byte()
        fileContents = My.Computer.FileSystem.ReadAllBytes(ROMfilename.Text)
        Success.Text = fileContents.Length.ToString + " total bytes"
        Dim c, d, start As Integer
        FT_Out_Buffer(0) = &HE2
        Write_Data_Bytes(1)
        Read_Data_Bytes(1)
        Sleep(10)
        start = Val("&H" + blockaddress.Rows(0).Item(0).ToString) << 24
        start = start + (Val("&H" + blockaddress.Rows(0).Item(1).ToString) << 16)
        start = start + (Val("&H" + blockaddress.Rows(0).Item(2).ToString) << 8)
        start = start + Val("&H" + blockaddress.Rows(0).Item(3).ToString)

        d = 256 * Val("&H" + blockaddress.Rows(2).Item(2).ToString) + Val("&H" + blockaddress.Rows(2).Item(3).ToString)
        FT_Out_Buffer(0) = &HFF
        FT_Out_Buffer(1) = &HFF
        FT_Out_Buffer(2) = Val("&H" + blockaddress.Rows(1).Item(2).ToString)
        FT_Out_Buffer(3) = Val("&H" + blockaddress.Rows(1).Item(3).ToString)
        FT_Out_Buffer(4) = Val("&H" + blockaddress.Rows(2).Item(2).ToString)
        FT_Out_Buffer(5) = Val("&H" + blockaddress.Rows(2).Item(3).ToString)
        Write_Data_Bytes(6)
        For c = 0 To d - 1
            FT_Out_Buffer(c) = fileContents(c + start)
        Next
        Write_Data_Bytes(d)
        Read_Data_Bytes(d + 6)
        Success.Text = d.ToString + " bytes written"
        If Verify.Checked = True Then
            FT_Out_Buffer(0) = &HE1
            Write_Data_Bytes(1)
            Read_Data_Bytes(1)
            Sleep(10)
            start = Val("&H" + blockaddress.Rows(0).Item(0).ToString) << 24
            start = start + (Val("&H" + blockaddress.Rows(0).Item(1).ToString) << 16)
            start = start + (Val("&H" + blockaddress.Rows(0).Item(2).ToString) << 8)
            start = start + Val("&H" + blockaddress.Rows(0).Item(3).ToString)

            d = 256 * Val("&H" + blockaddress.Rows(2).Item(2).ToString) + Val("&H" + blockaddress.Rows(2).Item(3).ToString)
            FT_Out_Buffer(0) = &HFF
            FT_Out_Buffer(1) = &HFF
            FT_Out_Buffer(2) = Val("&H" + blockaddress.Rows(1).Item(2).ToString)
            FT_Out_Buffer(3) = Val("&H" + blockaddress.Rows(1).Item(3).ToString)
            FT_Out_Buffer(4) = Val("&H" + blockaddress.Rows(2).Item(2).ToString)
            FT_Out_Buffer(5) = Val("&H" + blockaddress.Rows(2).Item(3).ToString)
            Write_Data_Bytes(6)
            Read_Data_Bytes(6)
            Read_Data_Bytes(d)
            For c = 0 To d - 1
                If FT_In_Buffer(c) <> fileContents(c + start) Then MsgBox("FAILED! MAP CONTENTS INVALID") : Exit For
            Next
            If c >= d - 1 Then
                Success.Text = d.ToString + " bytes verified"
            Else
                Success.Text = "FAILED at " + c.ToString + " bytes"
            End If

        End If
        FT_Status = FT_SetTimeouts(FT_Handle, 500, 500)
    End Sub
#End Region

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        FT_Status = FT_SetTimeouts(FT_Handle, 5000, 5000)
        Dim fileContents As Byte()
        fileContents = My.Computer.FileSystem.ReadAllBytes(ROMfilename.Text)
        Success.Text = fileContents.Length.ToString + " total bytes"
        Dim c, d, start As Integer
        'If Verify.Checked = True Then
        FT_Out_Buffer(0) = &HE1
        Write_Data_Bytes(1)
        Read_Data_Bytes(1)
        Sleep(10)
        start = Val("&H" + blockaddress.Rows(0).Item(0).ToString) << 24
        start = start + (Val("&H" + blockaddress.Rows(0).Item(1).ToString) << 16)
        start = start + (Val("&H" + blockaddress.Rows(0).Item(2).ToString) << 8)
        start = start + Val("&H" + blockaddress.Rows(0).Item(3).ToString)

        d = 256 * Val("&H" + blockaddress.Rows(2).Item(2).ToString) + Val("&H" + blockaddress.Rows(2).Item(3).ToString)
        FT_Out_Buffer(0) = &HFF
        FT_Out_Buffer(1) = &HFF
        FT_Out_Buffer(2) = Val("&H" + blockaddress.Rows(1).Item(2).ToString)
        FT_Out_Buffer(3) = Val("&H" + blockaddress.Rows(1).Item(3).ToString)
        FT_Out_Buffer(4) = Val("&H" + blockaddress.Rows(2).Item(2).ToString)
        FT_Out_Buffer(5) = Val("&H" + blockaddress.Rows(2).Item(3).ToString)
        Write_Data_Bytes(6)
        Read_Data_Bytes(6)
        Read_Data_Bytes(d)
        For c = 0 To d - 1
            If FT_In_Buffer(c) <> fileContents(c + start) Then MsgBox("FAILED! MAP CONTENTS INVALID") : Exit For
        Next
        If c >= d - 1 Then
            Success.Text = d.ToString + " bytes verified"
        Else
            Success.Text = "FAILED at " + c.ToString + " bytes"
        End If

        'End If
        FT_Status = FT_SetTimeouts(FT_Handle, 500, 500)
    End Sub

    Private Sub chart()
        Dim curve1 As LineItem = ZedGraphControl1.GraphPane.CurveList(0)
        Dim curve2 As LineItem = ZedGraphControl1.GraphPane.CurveList(1)
        Dim curve3 As LineItem = ZedGraphControl1.GraphPane.CurveList(2)
        Dim curve4 As LineItem = ZedGraphControl1.GraphPane.CurveList(3)
        Dim curve5 As LineItem = ZedGraphControl1.GraphPane.CurveList(4)
        Dim curve6 As LineItem = ZedGraphControl1.GraphPane.CurveList(5)
        Dim curve7 As LineItem = ZedGraphControl1.GraphPane.CurveList(6)
        Dim curve8 As LineItem = ZedGraphControl1.GraphPane.CurveList(7)
        Dim list1 As IPointListEdit = curve1.Points
        Dim list2 As IPointListEdit = curve2.Points
        Dim list3 As IPointListEdit = curve3.Points
        Dim list4 As IPointListEdit = curve4.Points
        Dim list5 As IPointListEdit = curve5.Points
        Dim list6 As IPointListEdit = curve6.Points
        Dim list7 As IPointListEdit = curve7.Points
        Dim list8 As IPointListEdit = curve8.Points


        list1.Add(pointIndex, FT_In_Buffer(&H8) * 0.2) 'O2
        list2.Add(pointIndex, FT_In_Buffer(&H1) - 20) 'ign
        list3.Add(pointIndex, FT_In_Buffer(&HC) * 10) 'knock
        list4.Add(pointIndex, FT_In_Buffer(&HE) * 0.256) 'ipw
        list5.Add(pointIndex, FT_In_Buffer(&HA) * 0.392) 'tps
        list6.Add(pointIndex, FT_In_Buffer(&H0) * 1.2) 'load
        list7.Add(pointIndex, FT_In_Buffer(&HB) * 0.3125) 'rpm
        list8.Add(pointIndex, FT_In_Buffer(&H11) * 1.334) 'map

        ' Keep the X scale at a rolling 30 second interval, with one
        ' major step between the max X value and the end of the axis
        Dim xScale As Scale = ZedGraphControl1.GraphPane.XAxis.Scale
        If pointIndex > xScale.Max - xScale.MinorStep Then
            xScale.Max = pointIndex + xScale.MinorStep
            xScale.Min = xScale.Max - 200
        End If

     
        pointIndex += 1

        'If pointIndex Mod 4 = 0 Then
        FTLo.Text = Math.Round((FT_In_Buffer(&H2) * 0.1953 - 25), 1) 'lo
        FTMed.Text = Math.Round((FT_In_Buffer(&H3) * 0.1953 - 25), 1) 'med
        FTHi.Text = Math.Round((FT_In_Buffer(&H4) * 0.1953 - 25), 1) 'hi
        STFT.Text = Math.Round((FT_In_Buffer(&H5) * 0.1953 - 25), 1) 'stft
        Oct.Text = Math.Round((FT_In_Buffer(&HD) * 0.39216), 1) 'oct
        Batt.Text = Math.Round((FT_In_Buffer(&H9) * 0.0733), 1) 'batt
        Coolant.Text = Math.Round((FT_In_Buffer(&H6) - 40), 1) 'coolant
        Air.Text = Math.Round((FT_In_Buffer(&H7) - 40), 1) 'air

        O2.Text = Math.Round((FT_In_Buffer(&H8) * 0.02), 2) 'O2
        Ign.Text = Math.Round((FT_In_Buffer(&H1) - 20), 0) 'ign
        Knock.Text = Math.Round((FT_In_Buffer(&HC)), 0) 'knock
        IPW.Text = Math.Round((FT_In_Buffer(&HE) * 0.256), 1) 'ipw
        TPS.Text = Math.Round((FT_In_Buffer(&HA) * 0.392), 1) 'tps
        EngLoad.Text = Math.Round((FT_In_Buffer(&H0) * 1.2), 1) 'load
        RPM.Text = Math.Round((FT_In_Buffer(&HB) * 31.25), 0) 'rpm
        MAP.Text = Math.Round((FT_In_Buffer(&H11) * 1.334), 0) 'map

        'End If

    End Sub


End Class