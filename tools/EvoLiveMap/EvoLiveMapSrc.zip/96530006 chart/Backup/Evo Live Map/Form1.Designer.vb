<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim ChartArea2 As Dundas.Charting.WinControl.ChartArea = New Dundas.Charting.WinControl.ChartArea
        Dim Legend2 As Dundas.Charting.WinControl.Legend = New Dundas.Charting.WinControl.Legend
        Dim Series9 As Dundas.Charting.WinControl.Series = New Dundas.Charting.WinControl.Series
        Dim Series10 As Dundas.Charting.WinControl.Series = New Dundas.Charting.WinControl.Series
        Dim Series11 As Dundas.Charting.WinControl.Series = New Dundas.Charting.WinControl.Series
        Dim Series12 As Dundas.Charting.WinControl.Series = New Dundas.Charting.WinControl.Series
        Dim Series13 As Dundas.Charting.WinControl.Series = New Dundas.Charting.WinControl.Series
        Dim Series14 As Dundas.Charting.WinControl.Series = New Dundas.Charting.WinControl.Series
        Dim Series15 As Dundas.Charting.WinControl.Series = New Dundas.Charting.WinControl.Series
        Dim Series16 As Dundas.Charting.WinControl.Series = New Dundas.Charting.WinControl.Series
        Dim Title2 As Dundas.Charting.WinControl.Title = New Dundas.Charting.WinControl.Title
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.TabPage6 = New System.Windows.Forms.TabPage
        Me.selectactivecell = New System.Windows.Forms.CheckBox
        Me.Clrcolors = New System.Windows.Forms.Button
        Me.Knocktrace = New System.Windows.Forms.CheckBox
        Me.Ignitionrecolor = New System.Windows.Forms.Button
        Me.Removeignitionrowbutton = New System.Windows.Forms.Button
        Me.Addignitionrowbutton = New System.Windows.Forms.Button
        Me.Removeignitioncolumnbutton = New System.Windows.Forms.Button
        Me.Addignitioncolumnbutton = New System.Windows.Forms.Button
        Me.Loadignitionbutton = New System.Windows.Forms.Button
        Me.Saveignitionbutton = New System.Windows.Forms.Button
        Me.Pasteignitionbutton = New System.Windows.Forms.Button
        Me.Copyignitionbutton = New System.Windows.Forms.Button
        Me.Writeignitionbutton = New System.Windows.Forms.Button
        Me.Readignitionbutton = New System.Windows.Forms.Button
        Me.DataGridView2 = New System.Windows.Forms.DataGridView
        Me.BindingSource2 = New System.Windows.Forms.BindingSource(Me.components)
        Me.TabPage5 = New System.Windows.Forms.TabPage
        Me.Fuelrecolor = New System.Windows.Forms.Button
        Me.Removefuelrowbutton = New System.Windows.Forms.Button
        Me.Addfuelrowbutton = New System.Windows.Forms.Button
        Me.Removefuelcolumnbutton = New System.Windows.Forms.Button
        Me.Addfuelcolumnbutton = New System.Windows.Forms.Button
        Me.Loadfuelbutton = New System.Windows.Forms.Button
        Me.Savefuelbutton = New System.Windows.Forms.Button
        Me.Pastefuelbutton = New System.Windows.Forms.Button
        Me.Copyfuelbutton = New System.Windows.Forms.Button
        Me.Writefuelbutton = New System.Windows.Forms.Button
        Me.Readfuelbutton = New System.Windows.Forms.Button
        Me.DataGridView1 = New System.Windows.Forms.DataGridView
        Me.BindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.TabPage4 = New System.Windows.Forms.TabPage
        Me.Label21 = New System.Windows.Forms.Label
        Me.Label19 = New System.Windows.Forms.Label
        Me.Label17 = New System.Windows.Forms.Label
        Me.Label18 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Knockcolorloadbutton = New System.Windows.Forms.Button
        Me.Knockcolorsavebutton = New System.Windows.Forms.Button
        Me.DataGridView5 = New System.Windows.Forms.DataGridView
        Me.BindingSource5 = New System.Windows.Forms.BindingSource(Me.components)
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.Addressloadbutton = New System.Windows.Forms.Button
        Me.Addresssavebutton = New System.Windows.Forms.Button
        Me.DataGridView4 = New System.Windows.Forms.DataGridView
        Me.BindingSource4 = New System.Windows.Forms.BindingSource(Me.components)
        Me.TabPage1 = New System.Windows.Forms.TabPage
        Me.Button3 = New System.Windows.Forms.Button
        Me.Label11 = New System.Windows.Forms.Label
        Me.TextBox3 = New System.Windows.Forms.TextBox
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.Button2 = New System.Windows.Forms.Button
        Me.TextBox2 = New System.Windows.Forms.TextBox
        Me.TextBox1 = New System.Windows.Forms.TextBox
        Me.Button1 = New System.Windows.Forms.Button
        Me.loggingdirectory = New System.Windows.Forms.TextBox
        Me.Label37 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Baud = New System.Windows.Forms.TextBox
        Me.Verify = New System.Windows.Forms.CheckBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.Success = New System.Windows.Forms.TextBox
        Me.Write = New System.Windows.Forms.Button
        Me.ROMfilename = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.Blockaddressloadbutton = New System.Windows.Forms.Button
        Me.Blockaddresssavebutton = New System.Windows.Forms.Button
        Me.DataGridView6 = New System.Windows.Forms.DataGridView
        Me.BindingSource6 = New System.Windows.Forms.BindingSource(Me.components)
        Me.Choose = New System.Windows.Forms.Button
        Me.Removeconfigrowbutton = New System.Windows.Forms.Button
        Me.Addconfigrowbutton = New System.Windows.Forms.Button
        Me.Configloadbutton = New System.Windows.Forms.Button
        Me.Configsavebutton = New System.Windows.Forms.Button
        Me.DataGridView3 = New System.Windows.Forms.DataGridView
        Me.BindingSource3 = New System.Windows.Forms.BindingSource(Me.components)
        Me.Startstopbutton = New System.Windows.Forms.Button
        Me.TabControl1 = New System.Windows.Forms.TabControl
        Me.TabPage2 = New System.Windows.Forms.TabPage
        Me.Writeinjsize = New System.Windows.Forms.Button
        Me.Readinjsize = New System.Windows.Forms.Button
        Me.Label20 = New System.Windows.Forms.Label
        Me.Injsize = New System.Windows.Forms.TextBox
        Me.Label15 = New System.Windows.Forms.Label
        Me.Label16 = New System.Windows.Forms.Label
        Me.Label14 = New System.Windows.Forms.Label
        Me.Label13 = New System.Windows.Forms.Label
        Me.Label12 = New System.Windows.Forms.Label
        Me.WriteMAPVEbutton = New System.Windows.Forms.Button
        Me.ReadMAPVEbutton = New System.Windows.Forms.Button
        Me.WriteRPMVEbutton = New System.Windows.Forms.Button
        Me.ReadRPMVEbutton = New System.Windows.Forms.Button
        Me.MAPVEloadbutton = New System.Windows.Forms.Button
        Me.MAPVEsavebutton = New System.Windows.Forms.Button
        Me.RPMVEloadbutton = New System.Windows.Forms.Button
        Me.RPMVEsavebutton = New System.Windows.Forms.Button
        Me.MAPVEcalib = New System.Windows.Forms.TextBox
        Me.DataGridView8 = New System.Windows.Forms.DataGridView
        Me.BindingSource8 = New System.Windows.Forms.BindingSource(Me.components)
        Me.DataGridView7 = New System.Windows.Forms.DataGridView
        Me.BindingSource7 = New System.Windows.Forms.BindingSource(Me.components)
        Me.TabPage3 = New System.Windows.Forms.TabPage
        Me.Chart1 = New Dundas.Charting.WinControl.Chart
        Me.Chartcheckbox = New System.Windows.Forms.CheckBox
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog
        Me.Timer3 = New System.Windows.Forms.Timer(Me.components)
        Me.TabPage6.SuspendLayout()
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BindingSource2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage5.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage4.SuspendLayout()
        CType(Me.DataGridView5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BindingSource5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BindingSource4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage1.SuspendLayout()
        CType(Me.DataGridView6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BindingSource6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BindingSource3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabControl1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        CType(Me.DataGridView8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BindingSource8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BindingSource7, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage3.SuspendLayout()
        CType(Me.Chart1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Timer1
        '
        Me.Timer1.Interval = 1
        '
        'TabPage6
        '
        Me.TabPage6.Controls.Add(Me.selectactivecell)
        Me.TabPage6.Controls.Add(Me.Clrcolors)
        Me.TabPage6.Controls.Add(Me.Knocktrace)
        Me.TabPage6.Controls.Add(Me.Ignitionrecolor)
        Me.TabPage6.Controls.Add(Me.Removeignitionrowbutton)
        Me.TabPage6.Controls.Add(Me.Addignitionrowbutton)
        Me.TabPage6.Controls.Add(Me.Removeignitioncolumnbutton)
        Me.TabPage6.Controls.Add(Me.Addignitioncolumnbutton)
        Me.TabPage6.Controls.Add(Me.Loadignitionbutton)
        Me.TabPage6.Controls.Add(Me.Saveignitionbutton)
        Me.TabPage6.Controls.Add(Me.Pasteignitionbutton)
        Me.TabPage6.Controls.Add(Me.Copyignitionbutton)
        Me.TabPage6.Controls.Add(Me.Writeignitionbutton)
        Me.TabPage6.Controls.Add(Me.Readignitionbutton)
        Me.TabPage6.Controls.Add(Me.DataGridView2)
        Me.TabPage6.Location = New System.Drawing.Point(4, 27)
        Me.TabPage6.Name = "TabPage6"
        Me.TabPage6.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage6.Size = New System.Drawing.Size(1184, 685)
        Me.TabPage6.TabIndex = 5
        Me.TabPage6.Text = "Ignition"
        Me.TabPage6.UseVisualStyleBackColor = True
        '
        'selectactivecell
        '
        Me.selectactivecell.AutoSize = True
        Me.selectactivecell.Checked = True
        Me.selectactivecell.CheckState = System.Windows.Forms.CheckState.Checked
        Me.selectactivecell.Location = New System.Drawing.Point(962, 250)
        Me.selectactivecell.Name = "selectactivecell"
        Me.selectactivecell.Size = New System.Drawing.Size(132, 22)
        Me.selectactivecell.TabIndex = 30
        Me.selectactivecell.Text = "Select active cell"
        Me.selectactivecell.UseVisualStyleBackColor = True
        '
        'Clrcolors
        '
        Me.Clrcolors.Location = New System.Drawing.Point(892, 4)
        Me.Clrcolors.Name = "Clrcolors"
        Me.Clrcolors.Size = New System.Drawing.Size(122, 28)
        Me.Clrcolors.TabIndex = 28
        Me.Clrcolors.Text = "Clear color"
        Me.Clrcolors.UseVisualStyleBackColor = True
        '
        'Knocktrace
        '
        Me.Knocktrace.AutoSize = True
        Me.Knocktrace.Checked = True
        Me.Knocktrace.CheckState = System.Windows.Forms.CheckState.Checked
        Me.Knocktrace.Location = New System.Drawing.Point(962, 222)
        Me.Knocktrace.Name = "Knocktrace"
        Me.Knocktrace.Size = New System.Drawing.Size(104, 22)
        Me.Knocktrace.TabIndex = 27
        Me.Knocktrace.Text = "Knock trace"
        Me.Knocktrace.UseVisualStyleBackColor = True
        '
        'Ignitionrecolor
        '
        Me.Ignitionrecolor.Location = New System.Drawing.Point(764, 4)
        Me.Ignitionrecolor.Name = "Ignitionrecolor"
        Me.Ignitionrecolor.Size = New System.Drawing.Size(122, 28)
        Me.Ignitionrecolor.TabIndex = 26
        Me.Ignitionrecolor.Text = "Recolor"
        Me.Ignitionrecolor.UseVisualStyleBackColor = True
        '
        'Removeignitionrowbutton
        '
        Me.Removeignitionrowbutton.Location = New System.Drawing.Point(962, 131)
        Me.Removeignitionrowbutton.Name = "Removeignitionrowbutton"
        Me.Removeignitionrowbutton.Size = New System.Drawing.Size(35, 25)
        Me.Removeignitionrowbutton.TabIndex = 25
        Me.Removeignitionrowbutton.Text = "y-"
        Me.Removeignitionrowbutton.UseVisualStyleBackColor = True
        '
        'Addignitionrowbutton
        '
        Me.Addignitionrowbutton.Location = New System.Drawing.Point(962, 100)
        Me.Addignitionrowbutton.Name = "Addignitionrowbutton"
        Me.Addignitionrowbutton.Size = New System.Drawing.Size(35, 25)
        Me.Addignitionrowbutton.TabIndex = 24
        Me.Addignitionrowbutton.Text = "y+"
        Me.Addignitionrowbutton.UseVisualStyleBackColor = True
        '
        'Removeignitioncolumnbutton
        '
        Me.Removeignitioncolumnbutton.Location = New System.Drawing.Point(962, 69)
        Me.Removeignitioncolumnbutton.Name = "Removeignitioncolumnbutton"
        Me.Removeignitioncolumnbutton.Size = New System.Drawing.Size(35, 25)
        Me.Removeignitioncolumnbutton.TabIndex = 23
        Me.Removeignitioncolumnbutton.Text = "x-"
        Me.Removeignitioncolumnbutton.UseVisualStyleBackColor = True
        '
        'Addignitioncolumnbutton
        '
        Me.Addignitioncolumnbutton.Location = New System.Drawing.Point(962, 38)
        Me.Addignitioncolumnbutton.Name = "Addignitioncolumnbutton"
        Me.Addignitioncolumnbutton.Size = New System.Drawing.Size(35, 25)
        Me.Addignitioncolumnbutton.TabIndex = 22
        Me.Addignitioncolumnbutton.Text = "x+"
        Me.Addignitioncolumnbutton.UseVisualStyleBackColor = True
        '
        'Loadignitionbutton
        '
        Me.Loadignitionbutton.Location = New System.Drawing.Point(637, 4)
        Me.Loadignitionbutton.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.Loadignitionbutton.Name = "Loadignitionbutton"
        Me.Loadignitionbutton.Size = New System.Drawing.Size(122, 28)
        Me.Loadignitionbutton.TabIndex = 17
        Me.Loadignitionbutton.Text = "Loadfromxml"
        Me.Loadignitionbutton.UseVisualStyleBackColor = True
        '
        'Saveignitionbutton
        '
        Me.Saveignitionbutton.Location = New System.Drawing.Point(511, 4)
        Me.Saveignitionbutton.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.Saveignitionbutton.Name = "Saveignitionbutton"
        Me.Saveignitionbutton.Size = New System.Drawing.Size(122, 28)
        Me.Saveignitionbutton.TabIndex = 16
        Me.Saveignitionbutton.Text = "Savetoxml"
        Me.Saveignitionbutton.UseVisualStyleBackColor = True
        '
        'Pasteignitionbutton
        '
        Me.Pasteignitionbutton.Location = New System.Drawing.Point(385, 4)
        Me.Pasteignitionbutton.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.Pasteignitionbutton.Name = "Pasteignitionbutton"
        Me.Pasteignitionbutton.Size = New System.Drawing.Size(122, 28)
        Me.Pasteignitionbutton.TabIndex = 11
        Me.Pasteignitionbutton.Text = "Paste"
        Me.Pasteignitionbutton.UseVisualStyleBackColor = True
        '
        'Copyignitionbutton
        '
        Me.Copyignitionbutton.Location = New System.Drawing.Point(259, 4)
        Me.Copyignitionbutton.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.Copyignitionbutton.Name = "Copyignitionbutton"
        Me.Copyignitionbutton.Size = New System.Drawing.Size(122, 28)
        Me.Copyignitionbutton.TabIndex = 9
        Me.Copyignitionbutton.Text = "Copy"
        Me.Copyignitionbutton.UseVisualStyleBackColor = True
        '
        'Writeignitionbutton
        '
        Me.Writeignitionbutton.Enabled = False
        Me.Writeignitionbutton.Location = New System.Drawing.Point(133, 4)
        Me.Writeignitionbutton.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.Writeignitionbutton.Name = "Writeignitionbutton"
        Me.Writeignitionbutton.Size = New System.Drawing.Size(122, 28)
        Me.Writeignitionbutton.TabIndex = 8
        Me.Writeignitionbutton.Text = "Write RAM ign map"
        Me.Writeignitionbutton.UseVisualStyleBackColor = True
        '
        'Readignitionbutton
        '
        Me.Readignitionbutton.Enabled = False
        Me.Readignitionbutton.Location = New System.Drawing.Point(7, 4)
        Me.Readignitionbutton.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.Readignitionbutton.Name = "Readignitionbutton"
        Me.Readignitionbutton.Size = New System.Drawing.Size(122, 28)
        Me.Readignitionbutton.TabIndex = 7
        Me.Readignitionbutton.Text = "Read RAM ign map"
        Me.Readignitionbutton.UseVisualStyleBackColor = True
        '
        'DataGridView2
        '
        Me.DataGridView2.AllowUserToAddRows = False
        Me.DataGridView2.AllowUserToDeleteRows = False
        Me.DataGridView2.AllowUserToResizeColumns = False
        Me.DataGridView2.AllowUserToResizeRows = False
        Me.DataGridView2.AutoGenerateColumns = False
        Me.DataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridView2.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText
        Me.DataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView2.ColumnHeadersVisible = False
        Me.DataGridView2.DataSource = Me.BindingSource2
        Me.DataGridView2.Location = New System.Drawing.Point(7, 38)
        Me.DataGridView2.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.DataGridView2.Name = "DataGridView2"
        Me.DataGridView2.RowHeadersVisible = False
        Me.DataGridView2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect
        Me.DataGridView2.Size = New System.Drawing.Size(950, 500)
        Me.DataGridView2.TabIndex = 6
        '
        'TabPage5
        '
        Me.TabPage5.Controls.Add(Me.Fuelrecolor)
        Me.TabPage5.Controls.Add(Me.Removefuelrowbutton)
        Me.TabPage5.Controls.Add(Me.Addfuelrowbutton)
        Me.TabPage5.Controls.Add(Me.Removefuelcolumnbutton)
        Me.TabPage5.Controls.Add(Me.Addfuelcolumnbutton)
        Me.TabPage5.Controls.Add(Me.Loadfuelbutton)
        Me.TabPage5.Controls.Add(Me.Savefuelbutton)
        Me.TabPage5.Controls.Add(Me.Pastefuelbutton)
        Me.TabPage5.Controls.Add(Me.Copyfuelbutton)
        Me.TabPage5.Controls.Add(Me.Writefuelbutton)
        Me.TabPage5.Controls.Add(Me.Readfuelbutton)
        Me.TabPage5.Controls.Add(Me.DataGridView1)
        Me.TabPage5.Location = New System.Drawing.Point(4, 27)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage5.Size = New System.Drawing.Size(1184, 685)
        Me.TabPage5.TabIndex = 4
        Me.TabPage5.Text = "Fuel"
        Me.TabPage5.UseVisualStyleBackColor = True
        '
        'Fuelrecolor
        '
        Me.Fuelrecolor.Location = New System.Drawing.Point(764, 4)
        Me.Fuelrecolor.Name = "Fuelrecolor"
        Me.Fuelrecolor.Size = New System.Drawing.Size(122, 28)
        Me.Fuelrecolor.TabIndex = 27
        Me.Fuelrecolor.Text = "Recolor"
        Me.Fuelrecolor.UseVisualStyleBackColor = True
        '
        'Removefuelrowbutton
        '
        Me.Removefuelrowbutton.Location = New System.Drawing.Point(962, 131)
        Me.Removefuelrowbutton.Name = "Removefuelrowbutton"
        Me.Removefuelrowbutton.Size = New System.Drawing.Size(35, 25)
        Me.Removefuelrowbutton.TabIndex = 21
        Me.Removefuelrowbutton.Text = "y-"
        Me.Removefuelrowbutton.UseVisualStyleBackColor = True
        '
        'Addfuelrowbutton
        '
        Me.Addfuelrowbutton.Location = New System.Drawing.Point(962, 100)
        Me.Addfuelrowbutton.Name = "Addfuelrowbutton"
        Me.Addfuelrowbutton.Size = New System.Drawing.Size(35, 25)
        Me.Addfuelrowbutton.TabIndex = 20
        Me.Addfuelrowbutton.Text = "y+"
        Me.Addfuelrowbutton.UseVisualStyleBackColor = True
        '
        'Removefuelcolumnbutton
        '
        Me.Removefuelcolumnbutton.Location = New System.Drawing.Point(962, 69)
        Me.Removefuelcolumnbutton.Name = "Removefuelcolumnbutton"
        Me.Removefuelcolumnbutton.Size = New System.Drawing.Size(35, 25)
        Me.Removefuelcolumnbutton.TabIndex = 19
        Me.Removefuelcolumnbutton.Text = "x-"
        Me.Removefuelcolumnbutton.UseVisualStyleBackColor = True
        '
        'Addfuelcolumnbutton
        '
        Me.Addfuelcolumnbutton.Location = New System.Drawing.Point(962, 38)
        Me.Addfuelcolumnbutton.Name = "Addfuelcolumnbutton"
        Me.Addfuelcolumnbutton.Size = New System.Drawing.Size(35, 25)
        Me.Addfuelcolumnbutton.TabIndex = 18
        Me.Addfuelcolumnbutton.Text = "x+"
        Me.Addfuelcolumnbutton.UseVisualStyleBackColor = True
        '
        'Loadfuelbutton
        '
        Me.Loadfuelbutton.Location = New System.Drawing.Point(637, 4)
        Me.Loadfuelbutton.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.Loadfuelbutton.Name = "Loadfuelbutton"
        Me.Loadfuelbutton.Size = New System.Drawing.Size(122, 28)
        Me.Loadfuelbutton.TabIndex = 15
        Me.Loadfuelbutton.Text = "Loadfromxml"
        Me.Loadfuelbutton.UseVisualStyleBackColor = True
        '
        'Savefuelbutton
        '
        Me.Savefuelbutton.Location = New System.Drawing.Point(511, 4)
        Me.Savefuelbutton.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.Savefuelbutton.Name = "Savefuelbutton"
        Me.Savefuelbutton.Size = New System.Drawing.Size(122, 28)
        Me.Savefuelbutton.TabIndex = 14
        Me.Savefuelbutton.Text = "Savetoxml"
        Me.Savefuelbutton.UseVisualStyleBackColor = True
        '
        'Pastefuelbutton
        '
        Me.Pastefuelbutton.Location = New System.Drawing.Point(385, 4)
        Me.Pastefuelbutton.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.Pastefuelbutton.Name = "Pastefuelbutton"
        Me.Pastefuelbutton.Size = New System.Drawing.Size(122, 28)
        Me.Pastefuelbutton.TabIndex = 13
        Me.Pastefuelbutton.Text = "Paste"
        Me.Pastefuelbutton.UseVisualStyleBackColor = True
        '
        'Copyfuelbutton
        '
        Me.Copyfuelbutton.Location = New System.Drawing.Point(259, 4)
        Me.Copyfuelbutton.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.Copyfuelbutton.Name = "Copyfuelbutton"
        Me.Copyfuelbutton.Size = New System.Drawing.Size(122, 28)
        Me.Copyfuelbutton.TabIndex = 12
        Me.Copyfuelbutton.Text = "Copy"
        Me.Copyfuelbutton.UseVisualStyleBackColor = True
        '
        'Writefuelbutton
        '
        Me.Writefuelbutton.Enabled = False
        Me.Writefuelbutton.Location = New System.Drawing.Point(133, 4)
        Me.Writefuelbutton.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.Writefuelbutton.Name = "Writefuelbutton"
        Me.Writefuelbutton.Size = New System.Drawing.Size(122, 28)
        Me.Writefuelbutton.TabIndex = 5
        Me.Writefuelbutton.Text = "Write RAM fuel map"
        Me.Writefuelbutton.UseVisualStyleBackColor = True
        '
        'Readfuelbutton
        '
        Me.Readfuelbutton.Enabled = False
        Me.Readfuelbutton.Location = New System.Drawing.Point(7, 4)
        Me.Readfuelbutton.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.Readfuelbutton.Name = "Readfuelbutton"
        Me.Readfuelbutton.Size = New System.Drawing.Size(122, 28)
        Me.Readfuelbutton.TabIndex = 4
        Me.Readfuelbutton.Text = "Read RAM fuel map"
        Me.Readfuelbutton.UseVisualStyleBackColor = True
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.AllowUserToResizeColumns = False
        Me.DataGridView1.AllowUserToResizeRows = False
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridView1.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.ColumnHeadersVisible = False
        Me.DataGridView1.DataSource = Me.BindingSource1
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle2.NullValue = Nothing
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridView1.DefaultCellStyle = DataGridViewCellStyle2
        Me.DataGridView1.Location = New System.Drawing.Point(7, 38)
        Me.DataGridView1.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowHeadersVisible = False
        Me.DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect
        Me.DataGridView1.Size = New System.Drawing.Size(950, 500)
        Me.DataGridView1.TabIndex = 3
        '
        'TabPage4
        '
        Me.TabPage4.Controls.Add(Me.Label21)
        Me.TabPage4.Controls.Add(Me.Label19)
        Me.TabPage4.Controls.Add(Me.Label17)
        Me.TabPage4.Controls.Add(Me.Label18)
        Me.TabPage4.Controls.Add(Me.Label3)
        Me.TabPage4.Controls.Add(Me.Knockcolorloadbutton)
        Me.TabPage4.Controls.Add(Me.Knockcolorsavebutton)
        Me.TabPage4.Controls.Add(Me.DataGridView5)
        Me.TabPage4.Controls.Add(Me.Label2)
        Me.TabPage4.Controls.Add(Me.Label1)
        Me.TabPage4.Controls.Add(Me.Addressloadbutton)
        Me.TabPage4.Controls.Add(Me.Addresssavebutton)
        Me.TabPage4.Controls.Add(Me.DataGridView4)
        Me.TabPage4.Location = New System.Drawing.Point(4, 27)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Size = New System.Drawing.Size(1184, 685)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "Setting"
        Me.TabPage4.UseVisualStyleBackColor = True
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(8, 139)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(90, 18)
        Me.Label21.TabIndex = 130
        Me.Label21.Text = "RAM Inj size"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(7, 118)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(94, 18)
        Me.Label19.TabIndex = 129
        Me.Label19.Text = "RAM MAP VE"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(7, 97)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(100, 18)
        Me.Label17.TabIndex = 128
        Me.Label17.Text = "RAM MAP kPa"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(7, 75)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(94, 18)
        Me.Label18.TabIndex = 127
        Me.Label18.Text = "RAM RPM VE"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(402, 34)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(82, 18)
        Me.Label3.TabIndex = 126
        Me.Label3.Text = "Knock color"
        '
        'Knockcolorloadbutton
        '
        Me.Knockcolorloadbutton.Location = New System.Drawing.Point(619, 220)
        Me.Knockcolorloadbutton.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.Knockcolorloadbutton.Name = "Knockcolorloadbutton"
        Me.Knockcolorloadbutton.Size = New System.Drawing.Size(122, 28)
        Me.Knockcolorloadbutton.TabIndex = 125
        Me.Knockcolorloadbutton.Text = "Loadfromxml"
        Me.Knockcolorloadbutton.UseVisualStyleBackColor = True
        '
        'Knockcolorsavebutton
        '
        Me.Knockcolorsavebutton.Location = New System.Drawing.Point(493, 220)
        Me.Knockcolorsavebutton.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.Knockcolorsavebutton.Name = "Knockcolorsavebutton"
        Me.Knockcolorsavebutton.Size = New System.Drawing.Size(122, 28)
        Me.Knockcolorsavebutton.TabIndex = 124
        Me.Knockcolorsavebutton.Text = "Savetoxml"
        Me.Knockcolorsavebutton.UseVisualStyleBackColor = True
        '
        'DataGridView5
        '
        Me.DataGridView5.AllowUserToAddRows = False
        Me.DataGridView5.AllowUserToDeleteRows = False
        Me.DataGridView5.AllowUserToResizeColumns = False
        Me.DataGridView5.AllowUserToResizeRows = False
        Me.DataGridView5.AutoGenerateColumns = False
        Me.DataGridView5.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridView5.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText
        Me.DataGridView5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView5.DataSource = Me.BindingSource5
        Me.DataGridView5.Location = New System.Drawing.Point(493, 3)
        Me.DataGridView5.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.DataGridView5.Name = "DataGridView5"
        Me.DataGridView5.RowHeadersVisible = False
        Me.DataGridView5.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect
        Me.DataGridView5.Size = New System.Drawing.Size(248, 211)
        Me.DataGridView5.TabIndex = 123
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(7, 54)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(86, 18)
        Me.Label2.TabIndex = 119
        Me.Label2.Text = "RAM ignition"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(7, 33)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(66, 18)
        Me.Label1.TabIndex = 118
        Me.Label1.Text = "RAM fuel"
        '
        'Addressloadbutton
        '
        Me.Addressloadbutton.Location = New System.Drawing.Point(238, 220)
        Me.Addressloadbutton.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.Addressloadbutton.Name = "Addressloadbutton"
        Me.Addressloadbutton.Size = New System.Drawing.Size(122, 28)
        Me.Addressloadbutton.TabIndex = 117
        Me.Addressloadbutton.Text = "Loadfromxml"
        Me.Addressloadbutton.UseVisualStyleBackColor = True
        '
        'Addresssavebutton
        '
        Me.Addresssavebutton.Location = New System.Drawing.Point(112, 220)
        Me.Addresssavebutton.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.Addresssavebutton.Name = "Addresssavebutton"
        Me.Addresssavebutton.Size = New System.Drawing.Size(122, 28)
        Me.Addresssavebutton.TabIndex = 116
        Me.Addresssavebutton.Text = "Savetoxml"
        Me.Addresssavebutton.UseVisualStyleBackColor = True
        '
        'DataGridView4
        '
        Me.DataGridView4.AllowUserToAddRows = False
        Me.DataGridView4.AllowUserToDeleteRows = False
        Me.DataGridView4.AllowUserToResizeColumns = False
        Me.DataGridView4.AllowUserToResizeRows = False
        Me.DataGridView4.AutoGenerateColumns = False
        Me.DataGridView4.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridView4.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText
        Me.DataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView4.DataSource = Me.BindingSource4
        Me.DataGridView4.Location = New System.Drawing.Point(112, 3)
        Me.DataGridView4.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.DataGridView4.Name = "DataGridView4"
        Me.DataGridView4.RowHeadersVisible = False
        Me.DataGridView4.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect
        Me.DataGridView4.Size = New System.Drawing.Size(248, 211)
        Me.DataGridView4.TabIndex = 115
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.Button3)
        Me.TabPage1.Controls.Add(Me.Label11)
        Me.TabPage1.Controls.Add(Me.TextBox3)
        Me.TabPage1.Controls.Add(Me.Label10)
        Me.TabPage1.Controls.Add(Me.Label9)
        Me.TabPage1.Controls.Add(Me.Button2)
        Me.TabPage1.Controls.Add(Me.TextBox2)
        Me.TabPage1.Controls.Add(Me.TextBox1)
        Me.TabPage1.Controls.Add(Me.Button1)
        Me.TabPage1.Controls.Add(Me.loggingdirectory)
        Me.TabPage1.Controls.Add(Me.Label37)
        Me.TabPage1.Controls.Add(Me.Label4)
        Me.TabPage1.Controls.Add(Me.Baud)
        Me.TabPage1.Controls.Add(Me.Verify)
        Me.TabPage1.Controls.Add(Me.Label6)
        Me.TabPage1.Controls.Add(Me.Success)
        Me.TabPage1.Controls.Add(Me.Write)
        Me.TabPage1.Controls.Add(Me.ROMfilename)
        Me.TabPage1.Controls.Add(Me.Label5)
        Me.TabPage1.Controls.Add(Me.Label7)
        Me.TabPage1.Controls.Add(Me.Label8)
        Me.TabPage1.Controls.Add(Me.Blockaddressloadbutton)
        Me.TabPage1.Controls.Add(Me.Blockaddresssavebutton)
        Me.TabPage1.Controls.Add(Me.DataGridView6)
        Me.TabPage1.Controls.Add(Me.Choose)
        Me.TabPage1.Controls.Add(Me.Removeconfigrowbutton)
        Me.TabPage1.Controls.Add(Me.Addconfigrowbutton)
        Me.TabPage1.Controls.Add(Me.Configloadbutton)
        Me.TabPage1.Controls.Add(Me.Configsavebutton)
        Me.TabPage1.Controls.Add(Me.DataGridView3)
        Me.TabPage1.Controls.Add(Me.Startstopbutton)
        Me.TabPage1.Location = New System.Drawing.Point(4, 27)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Size = New System.Drawing.Size(1184, 685)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Data"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(930, 301)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(78, 57)
        Me.Button3.TabIndex = 181
        Me.Button3.Text = "Verify only"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(877, 469)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(104, 18)
        Me.Label11.TabIndex = 180
        Me.Label11.Text = "Data (decimal)"
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(880, 496)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(90, 26)
        Me.TextBox3.TabIndex = 179
        Me.TextBox3.Text = "0"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(782, 469)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(75, 18)
        Me.Label10.TabIndex = 178
        Me.Label10.Text = "Address lo"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(688, 471)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(75, 18)
        Me.Label9.TabIndex = 177
        Me.Label9.Text = "Address hi"
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(569, 496)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(114, 26)
        Me.Button2.TabIndex = 176
        Me.Button2.Text = "Write byte"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(785, 496)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(90, 26)
        Me.TextBox2.TabIndex = 175
        Me.TextBox2.Text = "1c"
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(689, 496)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(90, 26)
        Me.TextBox1.TabIndex = 174
        Me.TextBox1.Text = "84"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(569, 469)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(114, 26)
        Me.Button1.TabIndex = 173
        Me.Button1.Text = "Read byte"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'loggingdirectory
        '
        Me.loggingdirectory.Location = New System.Drawing.Point(811, 41)
        Me.loggingdirectory.Name = "loggingdirectory"
        Me.loggingdirectory.Size = New System.Drawing.Size(226, 26)
        Me.loggingdirectory.TabIndex = 171
        '
        'Label37
        '
        Me.Label37.Location = New System.Drawing.Point(811, 22)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(224, 26)
        Me.Label37.TabIndex = 172
        Me.Label37.Text = "Logging directory"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(811, 87)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(41, 18)
        Me.Label4.TabIndex = 170
        Me.Label4.Text = "Baud"
        '
        'Baud
        '
        Me.Baud.Location = New System.Drawing.Point(858, 84)
        Me.Baud.Name = "Baud"
        Me.Baud.Size = New System.Drawing.Size(57, 26)
        Me.Baud.TabIndex = 169
        Me.Baud.Text = "38400"
        '
        'Verify
        '
        Me.Verify.AutoSize = True
        Me.Verify.Checked = True
        Me.Verify.CheckState = System.Windows.Forms.CheckState.Checked
        Me.Verify.Location = New System.Drawing.Point(743, 332)
        Me.Verify.Name = "Verify"
        Me.Verify.Size = New System.Drawing.Size(64, 22)
        Me.Verify.TabIndex = 166
        Me.Verify.Text = "Verify"
        Me.Verify.UseVisualStyleBackColor = True
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(558, 252)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(113, 18)
        Me.Label6.TabIndex = 168
        Me.Label6.Text = "Logging address"
        '
        'Success
        '
        Me.Success.Location = New System.Drawing.Point(813, 330)
        Me.Success.Name = "Success"
        Me.Success.Size = New System.Drawing.Size(111, 26)
        Me.Success.TabIndex = 167
        '
        'Write
        '
        Me.Write.Location = New System.Drawing.Point(653, 315)
        Me.Write.Name = "Write"
        Me.Write.Size = New System.Drawing.Size(84, 41)
        Me.Write.TabIndex = 165
        Me.Write.Text = "Write"
        Me.Write.UseVisualStyleBackColor = True
        '
        'ROMfilename
        '
        Me.ROMfilename.Location = New System.Drawing.Point(561, 362)
        Me.ROMfilename.Multiline = True
        Me.ROMfilename.Name = "ROMfilename"
        Me.ROMfilename.Size = New System.Drawing.Size(363, 68)
        Me.ROMfilename.TabIndex = 158
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(557, 230)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(99, 18)
        Me.Label5.TabIndex = 164
        Me.Label5.Text = "Bytes to copy"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(557, 209)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(94, 18)
        Me.Label7.TabIndex = 163
        Me.Label7.Text = "RAM address"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(557, 189)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(96, 18)
        Me.Label8.TabIndex = 162
        Me.Label8.Text = "ROM address"
        '
        'Blockaddressloadbutton
        '
        Me.Blockaddressloadbutton.Location = New System.Drawing.Point(802, 284)
        Me.Blockaddressloadbutton.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.Blockaddressloadbutton.Name = "Blockaddressloadbutton"
        Me.Blockaddressloadbutton.Size = New System.Drawing.Size(122, 28)
        Me.Blockaddressloadbutton.TabIndex = 161
        Me.Blockaddressloadbutton.Text = "Loadfromxml"
        Me.Blockaddressloadbutton.UseVisualStyleBackColor = True
        '
        'Blockaddresssavebutton
        '
        Me.Blockaddresssavebutton.Location = New System.Drawing.Point(676, 284)
        Me.Blockaddresssavebutton.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.Blockaddresssavebutton.Name = "Blockaddresssavebutton"
        Me.Blockaddresssavebutton.Size = New System.Drawing.Size(122, 28)
        Me.Blockaddresssavebutton.TabIndex = 160
        Me.Blockaddresssavebutton.Text = "Savetoxml"
        Me.Blockaddresssavebutton.UseVisualStyleBackColor = True
        '
        'DataGridView6
        '
        Me.DataGridView6.AllowUserToAddRows = False
        Me.DataGridView6.AllowUserToDeleteRows = False
        Me.DataGridView6.AllowUserToResizeColumns = False
        Me.DataGridView6.AllowUserToResizeRows = False
        Me.DataGridView6.AutoGenerateColumns = False
        Me.DataGridView6.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridView6.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText
        Me.DataGridView6.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView6.DataSource = Me.BindingSource6
        Me.DataGridView6.Location = New System.Drawing.Point(676, 156)
        Me.DataGridView6.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.DataGridView6.Name = "DataGridView6"
        Me.DataGridView6.RowHeadersVisible = False
        Me.DataGridView6.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect
        Me.DataGridView6.Size = New System.Drawing.Size(248, 122)
        Me.DataGridView6.TabIndex = 159
        '
        'Choose
        '
        Me.Choose.Location = New System.Drawing.Point(561, 284)
        Me.Choose.Name = "Choose"
        Me.Choose.Size = New System.Drawing.Size(86, 72)
        Me.Choose.TabIndex = 157
        Me.Choose.Text = "Choose ECU ROM file"
        Me.Choose.UseVisualStyleBackColor = True
        '
        'Removeconfigrowbutton
        '
        Me.Removeconfigrowbutton.Location = New System.Drawing.Point(557, 147)
        Me.Removeconfigrowbutton.Name = "Removeconfigrowbutton"
        Me.Removeconfigrowbutton.Size = New System.Drawing.Size(35, 25)
        Me.Removeconfigrowbutton.TabIndex = 117
        Me.Removeconfigrowbutton.Text = "y-"
        Me.Removeconfigrowbutton.UseVisualStyleBackColor = True
        '
        'Addconfigrowbutton
        '
        Me.Addconfigrowbutton.Location = New System.Drawing.Point(557, 116)
        Me.Addconfigrowbutton.Name = "Addconfigrowbutton"
        Me.Addconfigrowbutton.Size = New System.Drawing.Size(35, 25)
        Me.Addconfigrowbutton.TabIndex = 116
        Me.Addconfigrowbutton.Text = "y+"
        Me.Addconfigrowbutton.UseVisualStyleBackColor = True
        '
        'Configloadbutton
        '
        Me.Configloadbutton.Location = New System.Drawing.Point(683, 82)
        Me.Configloadbutton.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.Configloadbutton.Name = "Configloadbutton"
        Me.Configloadbutton.Size = New System.Drawing.Size(122, 28)
        Me.Configloadbutton.TabIndex = 115
        Me.Configloadbutton.Text = "Loadfromxml"
        Me.Configloadbutton.UseVisualStyleBackColor = True
        '
        'Configsavebutton
        '
        Me.Configsavebutton.Location = New System.Drawing.Point(557, 82)
        Me.Configsavebutton.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.Configsavebutton.Name = "Configsavebutton"
        Me.Configsavebutton.Size = New System.Drawing.Size(122, 28)
        Me.Configsavebutton.TabIndex = 114
        Me.Configsavebutton.Text = "Savetoxml"
        Me.Configsavebutton.UseVisualStyleBackColor = True
        '
        'DataGridView3
        '
        Me.DataGridView3.AllowUserToAddRows = False
        Me.DataGridView3.AllowUserToDeleteRows = False
        Me.DataGridView3.AllowUserToResizeColumns = False
        Me.DataGridView3.AllowUserToResizeRows = False
        Me.DataGridView3.AutoGenerateColumns = False
        Me.DataGridView3.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridView3.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText
        Me.DataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView3.DataSource = Me.BindingSource3
        Me.DataGridView3.Location = New System.Drawing.Point(2, 22)
        Me.DataGridView3.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.DataGridView3.Name = "DataGridView3"
        Me.DataGridView3.RowHeadersVisible = False
        Me.DataGridView3.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect
        Me.DataGridView3.Size = New System.Drawing.Size(550, 500)
        Me.DataGridView3.TabIndex = 113
        '
        'Startstopbutton
        '
        Me.Startstopbutton.Font = New System.Drawing.Font("Tahoma", 10.0!, System.Drawing.FontStyle.Bold)
        Me.Startstopbutton.Location = New System.Drawing.Point(557, 22)
        Me.Startstopbutton.Name = "Startstopbutton"
        Me.Startstopbutton.Size = New System.Drawing.Size(248, 54)
        Me.Startstopbutton.TabIndex = 72
        Me.Startstopbutton.Text = "Start"
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage4)
        Me.TabControl1.Controls.Add(Me.TabPage5)
        Me.TabControl1.Controls.Add(Me.TabPage6)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl1.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabControl1.Location = New System.Drawing.Point(0, 0)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(1192, 716)
        Me.TabControl1.TabIndex = 73
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.Writeinjsize)
        Me.TabPage2.Controls.Add(Me.Readinjsize)
        Me.TabPage2.Controls.Add(Me.Label20)
        Me.TabPage2.Controls.Add(Me.Injsize)
        Me.TabPage2.Controls.Add(Me.Label15)
        Me.TabPage2.Controls.Add(Me.Label16)
        Me.TabPage2.Controls.Add(Me.Label14)
        Me.TabPage2.Controls.Add(Me.Label13)
        Me.TabPage2.Controls.Add(Me.Label12)
        Me.TabPage2.Controls.Add(Me.WriteMAPVEbutton)
        Me.TabPage2.Controls.Add(Me.ReadMAPVEbutton)
        Me.TabPage2.Controls.Add(Me.WriteRPMVEbutton)
        Me.TabPage2.Controls.Add(Me.ReadRPMVEbutton)
        Me.TabPage2.Controls.Add(Me.MAPVEloadbutton)
        Me.TabPage2.Controls.Add(Me.MAPVEsavebutton)
        Me.TabPage2.Controls.Add(Me.RPMVEloadbutton)
        Me.TabPage2.Controls.Add(Me.RPMVEsavebutton)
        Me.TabPage2.Controls.Add(Me.MAPVEcalib)
        Me.TabPage2.Controls.Add(Me.DataGridView8)
        Me.TabPage2.Controls.Add(Me.DataGridView7)
        Me.TabPage2.Location = New System.Drawing.Point(4, 27)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(1184, 685)
        Me.TabPage2.TabIndex = 6
        Me.TabPage2.Text = "VE/inj"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'Writeinjsize
        '
        Me.Writeinjsize.Location = New System.Drawing.Point(726, 137)
        Me.Writeinjsize.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.Writeinjsize.Name = "Writeinjsize"
        Me.Writeinjsize.Size = New System.Drawing.Size(122, 28)
        Me.Writeinjsize.TabIndex = 144
        Me.Writeinjsize.Text = "Write inj size"
        Me.Writeinjsize.UseVisualStyleBackColor = True
        '
        'Readinjsize
        '
        Me.Readinjsize.Location = New System.Drawing.Point(600, 137)
        Me.Readinjsize.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.Readinjsize.Name = "Readinjsize"
        Me.Readinjsize.Size = New System.Drawing.Size(122, 28)
        Me.Readinjsize.TabIndex = 143
        Me.Readinjsize.Text = "Read inj size"
        Me.Readinjsize.UseVisualStyleBackColor = True
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(597, 108)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(88, 18)
        Me.Label20.TabIndex = 142
        Me.Label20.Text = "Injector size"
        '
        'Injsize
        '
        Me.Injsize.Location = New System.Drawing.Point(689, 105)
        Me.Injsize.Name = "Injsize"
        Me.Injsize.Size = New System.Drawing.Size(92, 26)
        Me.Injsize.TabIndex = 141
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(437, 10)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(59, 18)
        Me.Label15.TabIndex = 140
        Me.Label15.Text = "MAP VE"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(311, 10)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(65, 18)
        Me.Label16.TabIndex = 139
        Me.Label16.Text = "MAP kPa"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(130, 10)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(59, 18)
        Me.Label14.TabIndex = 138
        Me.Label14.Text = "RPM VE"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(4, 10)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(37, 18)
        Me.Label13.TabIndex = 137
        Me.Label13.Text = "RPM"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(607, 14)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(78, 18)
        Me.Label12.TabIndex = 136
        Me.Label12.Text = "kPa=raw *"
        '
        'WriteMAPVEbutton
        '
        Me.WriteMAPVEbutton.Location = New System.Drawing.Point(440, 644)
        Me.WriteMAPVEbutton.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.WriteMAPVEbutton.Name = "WriteMAPVEbutton"
        Me.WriteMAPVEbutton.Size = New System.Drawing.Size(122, 28)
        Me.WriteMAPVEbutton.TabIndex = 135
        Me.WriteMAPVEbutton.Text = "Write MAP VE"
        Me.WriteMAPVEbutton.UseVisualStyleBackColor = True
        '
        'ReadMAPVEbutton
        '
        Me.ReadMAPVEbutton.Location = New System.Drawing.Point(314, 644)
        Me.ReadMAPVEbutton.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.ReadMAPVEbutton.Name = "ReadMAPVEbutton"
        Me.ReadMAPVEbutton.Size = New System.Drawing.Size(122, 28)
        Me.ReadMAPVEbutton.TabIndex = 134
        Me.ReadMAPVEbutton.Text = "Read MAP VE"
        Me.ReadMAPVEbutton.UseVisualStyleBackColor = True
        '
        'WriteRPMVEbutton
        '
        Me.WriteRPMVEbutton.Location = New System.Drawing.Point(133, 644)
        Me.WriteRPMVEbutton.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.WriteRPMVEbutton.Name = "WriteRPMVEbutton"
        Me.WriteRPMVEbutton.Size = New System.Drawing.Size(122, 28)
        Me.WriteRPMVEbutton.TabIndex = 133
        Me.WriteRPMVEbutton.Text = "Write RPM VE"
        Me.WriteRPMVEbutton.UseVisualStyleBackColor = True
        '
        'ReadRPMVEbutton
        '
        Me.ReadRPMVEbutton.Location = New System.Drawing.Point(7, 644)
        Me.ReadRPMVEbutton.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.ReadRPMVEbutton.Name = "ReadRPMVEbutton"
        Me.ReadRPMVEbutton.Size = New System.Drawing.Size(122, 28)
        Me.ReadRPMVEbutton.TabIndex = 132
        Me.ReadRPMVEbutton.Text = "Read RPM VE"
        Me.ReadRPMVEbutton.UseVisualStyleBackColor = True
        '
        'MAPVEloadbutton
        '
        Me.MAPVEloadbutton.Location = New System.Drawing.Point(440, 610)
        Me.MAPVEloadbutton.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.MAPVEloadbutton.Name = "MAPVEloadbutton"
        Me.MAPVEloadbutton.Size = New System.Drawing.Size(122, 28)
        Me.MAPVEloadbutton.TabIndex = 131
        Me.MAPVEloadbutton.Text = "Loadfromxml"
        Me.MAPVEloadbutton.UseVisualStyleBackColor = True
        '
        'MAPVEsavebutton
        '
        Me.MAPVEsavebutton.Location = New System.Drawing.Point(314, 610)
        Me.MAPVEsavebutton.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.MAPVEsavebutton.Name = "MAPVEsavebutton"
        Me.MAPVEsavebutton.Size = New System.Drawing.Size(122, 28)
        Me.MAPVEsavebutton.TabIndex = 130
        Me.MAPVEsavebutton.Text = "Savetoxml"
        Me.MAPVEsavebutton.UseVisualStyleBackColor = True
        '
        'RPMVEloadbutton
        '
        Me.RPMVEloadbutton.Location = New System.Drawing.Point(133, 610)
        Me.RPMVEloadbutton.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.RPMVEloadbutton.Name = "RPMVEloadbutton"
        Me.RPMVEloadbutton.Size = New System.Drawing.Size(122, 28)
        Me.RPMVEloadbutton.TabIndex = 129
        Me.RPMVEloadbutton.Text = "Loadfromxml"
        Me.RPMVEloadbutton.UseVisualStyleBackColor = True
        '
        'RPMVEsavebutton
        '
        Me.RPMVEsavebutton.Location = New System.Drawing.Point(7, 610)
        Me.RPMVEsavebutton.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.RPMVEsavebutton.Name = "RPMVEsavebutton"
        Me.RPMVEsavebutton.Size = New System.Drawing.Size(122, 28)
        Me.RPMVEsavebutton.TabIndex = 128
        Me.RPMVEsavebutton.Text = "Savetoxml"
        Me.RPMVEsavebutton.UseVisualStyleBackColor = True
        '
        'MAPVEcalib
        '
        Me.MAPVEcalib.Location = New System.Drawing.Point(686, 11)
        Me.MAPVEcalib.Name = "MAPVEcalib"
        Me.MAPVEcalib.Size = New System.Drawing.Size(96, 26)
        Me.MAPVEcalib.TabIndex = 127
        Me.MAPVEcalib.Text = "0.3333"
        '
        'DataGridView8
        '
        Me.DataGridView8.AllowUserToAddRows = False
        Me.DataGridView8.AllowUserToDeleteRows = False
        Me.DataGridView8.AllowUserToResizeColumns = False
        Me.DataGridView8.AllowUserToResizeRows = False
        Me.DataGridView8.AutoGenerateColumns = False
        Me.DataGridView8.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridView8.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText
        Me.DataGridView8.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView8.ColumnHeadersVisible = False
        Me.DataGridView8.DataSource = Me.BindingSource8
        Me.DataGridView8.Location = New System.Drawing.Point(314, 41)
        Me.DataGridView8.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.DataGridView8.Name = "DataGridView8"
        Me.DataGridView8.RowHeadersVisible = False
        Me.DataGridView8.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect
        Me.DataGridView8.Size = New System.Drawing.Size(248, 563)
        Me.DataGridView8.TabIndex = 120
        '
        'DataGridView7
        '
        Me.DataGridView7.AllowUserToAddRows = False
        Me.DataGridView7.AllowUserToDeleteRows = False
        Me.DataGridView7.AllowUserToResizeColumns = False
        Me.DataGridView7.AllowUserToResizeRows = False
        Me.DataGridView7.AutoGenerateColumns = False
        Me.DataGridView7.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridView7.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText
        Me.DataGridView7.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView7.ColumnHeadersVisible = False
        Me.DataGridView7.DataSource = Me.BindingSource7
        Me.DataGridView7.Location = New System.Drawing.Point(7, 41)
        Me.DataGridView7.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.DataGridView7.Name = "DataGridView7"
        Me.DataGridView7.RowHeadersVisible = False
        Me.DataGridView7.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect
        Me.DataGridView7.Size = New System.Drawing.Size(248, 563)
        Me.DataGridView7.TabIndex = 116
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.Chartcheckbox)
        Me.TabPage3.Controls.Add(Me.Chart1)
        Me.TabPage3.Location = New System.Drawing.Point(4, 27)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(1184, 685)
        Me.TabPage3.TabIndex = 7
        Me.TabPage3.Text = "Chart"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'Chart1
        '
        Me.Chart1.AlwaysRecreateHotregions = True
        Me.Chart1.BackGradientEndColor = System.Drawing.Color.Lavender
        Me.Chart1.BackGradientType = Dundas.Charting.WinControl.GradientType.DiagonalLeft
        Me.Chart1.BorderLineColor = System.Drawing.Color.LightSlateGray
        Me.Chart1.BorderLineStyle = Dundas.Charting.WinControl.ChartDashStyle.Solid
        Me.Chart1.BorderLineWidth = 0
        Me.Chart1.BorderSkin.FrameBackColor = System.Drawing.Color.SteelBlue
        Me.Chart1.BorderSkin.FrameBackGradientEndColor = System.Drawing.Color.LightBlue
        Me.Chart1.BorderSkin.FrameBorderColor = System.Drawing.Color.Transparent
        Me.Chart1.BorderSkin.PageColor = System.Drawing.Color.Transparent
        ChartArea2.Area3DStyle.WallWidth = 0
        ChartArea2.AxisX.MajorGrid.Enabled = False
        ChartArea2.AxisX.MajorGrid.LineColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        ChartArea2.AxisX.MinorGrid.LineColor = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        ChartArea2.AxisX.View.Position = 1
        ChartArea2.AxisX.View.Size = 200
        ChartArea2.AxisY.MajorGrid.Enabled = False
        ChartArea2.AxisY.MajorGrid.LineColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        ChartArea2.AxisY.MinorGrid.LineColor = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        ChartArea2.BackColor = System.Drawing.Color.White
        ChartArea2.BackGradientEndColor = System.Drawing.Color.White
        ChartArea2.BorderColor = System.Drawing.Color.LightSlateGray
        ChartArea2.BorderStyle = Dundas.Charting.WinControl.ChartDashStyle.Solid
        ChartArea2.CursorX.UserEnabled = True
        ChartArea2.CursorX.UserSelection = True
        ChartArea2.Name = "Default"
        Me.Chart1.ChartAreas.Add(ChartArea2)
        Me.Chart1.Dock = System.Windows.Forms.DockStyle.Fill
        Legend2.BackColor = System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Legend2.BorderColor = System.Drawing.Color.LightSlateGray
        Legend2.Name = "Default"
        Me.Chart1.Legends.Add(Legend2)
        Me.Chart1.Location = New System.Drawing.Point(3, 3)
        Me.Chart1.Name = "Chart1"
        Me.Chart1.Palette = Dundas.Charting.WinControl.ChartColorPalette.Kindergarten
        Series9.BackGradientEndColor = System.Drawing.Color.FromArgb(CType(CType(162, Byte), Integer), CType(CType(164, Byte), Integer), CType(CType(255, Byte), Integer))
        Series9.BackGradientType = Dundas.Charting.WinControl.GradientType.DiagonalLeft
        Series9.BorderColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Series9.ChartType = "FastLine"
        Series9.Name = "O2"
        Series9.PaletteCustomColors = New System.Drawing.Color(-1) {}
        Series10.BackGradientEndColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Series10.BackGradientType = Dundas.Charting.WinControl.GradientType.DiagonalLeft
        Series10.BorderColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Series10.ChartType = "FastLine"
        Series10.Name = "Ign"
        Series10.PaletteCustomColors = New System.Drawing.Color(-1) {}
        Series11.BackGradientEndColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(130, Byte), Integer))
        Series11.BackGradientType = Dundas.Charting.WinControl.GradientType.DiagonalLeft
        Series11.BorderColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Series11.ChartType = "FastLine"
        Series11.Name = "Knock"
        Series11.PaletteCustomColors = New System.Drawing.Color(-1) {}
        Series12.BackGradientEndColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(145, Byte), Integer), CType(CType(145, Byte), Integer))
        Series12.BackGradientType = Dundas.Charting.WinControl.GradientType.DiagonalLeft
        Series12.BorderColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Series12.ChartType = "FastLine"
        Series12.Name = "IPW"
        Series12.PaletteCustomColors = New System.Drawing.Color(-1) {}
        Series13.BackGradientEndColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(177, Byte), Integer), CType(CType(236, Byte), Integer))
        Series13.BackGradientType = Dundas.Charting.WinControl.GradientType.DiagonalLeft
        Series13.BorderColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Series13.ChartType = "FastLine"
        Series13.Name = "TPS"
        Series13.PaletteCustomColors = New System.Drawing.Color(-1) {}
        Series14.BackGradientEndColor = System.Drawing.Color.FromArgb(CType(CType(130, Byte), Integer), CType(CType(198, Byte), Integer), CType(CType(255, Byte), Integer))
        Series14.BackGradientType = Dundas.Charting.WinControl.GradientType.DiagonalLeft
        Series14.BorderColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Series14.ChartType = "FastLine"
        Series14.Name = "Load"
        Series14.PaletteCustomColors = New System.Drawing.Color(-1) {}
        Series15.BackGradientEndColor = System.Drawing.Color.FromArgb(CType(CType(216, Byte), Integer), CType(CType(164, Byte), Integer), CType(CType(255, Byte), Integer))
        Series15.BackGradientType = Dundas.Charting.WinControl.GradientType.DiagonalLeft
        Series15.BorderColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Series15.ChartType = "FastLine"
        Series15.Name = "RPM"
        Series15.PaletteCustomColors = New System.Drawing.Color(-1) {}
        Series16.BackGradientEndColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(218, Byte), Integer), CType(CType(164, Byte), Integer))
        Series16.BackGradientType = Dundas.Charting.WinControl.GradientType.DiagonalLeft
        Series16.BorderColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Series16.ChartType = "FastLine"
        Series16.Name = "MAP"
        Series16.PaletteCustomColors = New System.Drawing.Color(-1) {}
        Me.Chart1.Series.Add(Series9)
        Me.Chart1.Series.Add(Series10)
        Me.Chart1.Series.Add(Series11)
        Me.Chart1.Series.Add(Series12)
        Me.Chart1.Series.Add(Series13)
        Me.Chart1.Series.Add(Series14)
        Me.Chart1.Series.Add(Series15)
        Me.Chart1.Series.Add(Series16)
        Me.Chart1.Size = New System.Drawing.Size(1178, 679)
        Me.Chart1.TabIndex = 2
        Me.Chart1.Text = "Chart1"
        Title2.Name = "Title1"
        Me.Chart1.Titles.Add(Title2)
        Me.Chart1.UI.Toolbar.BackColor = System.Drawing.Color.White
        Me.Chart1.UI.Toolbar.BorderColor = System.Drawing.Color.LightSlateGray
        Me.Chart1.UI.Toolbar.BorderSkin.FrameBackColor = System.Drawing.Color.SteelBlue
        Me.Chart1.UI.Toolbar.BorderSkin.FrameBackGradientEndColor = System.Drawing.Color.LightBlue
        Me.Chart1.UI.Toolbar.BorderSkin.PageColor = System.Drawing.Color.Transparent
        Me.Chart1.UI.Toolbar.BorderSkin.SkinStyle = Dundas.Charting.WinControl.BorderSkinStyle.Raised
        '
        'Chartcheckbox
        '
        Me.Chartcheckbox.AutoSize = True
        Me.Chartcheckbox.Checked = True
        Me.Chartcheckbox.CheckState = System.Windows.Forms.CheckState.Checked
        Me.Chartcheckbox.Location = New System.Drawing.Point(6, 6)
        Me.Chartcheckbox.Name = "Chartcheckbox"
        Me.Chartcheckbox.Size = New System.Drawing.Size(62, 22)
        Me.Chartcheckbox.TabIndex = 1
        Me.Chartcheckbox.Text = "Chart"
        Me.Chartcheckbox.UseVisualStyleBackColor = True
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.Filter = "Hex|*.hex|Bin|*.bin|All|*.*"
        Me.OpenFileDialog1.InitialDirectory = "Desktop"
        '
        'Timer3
        '
        Me.Timer3.Enabled = True
        Me.Timer3.Interval = 333
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1192, 716)
        Me.Controls.Add(Me.TabControl1)
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Evo Live Map"
        Me.TabPage6.ResumeLayout(False)
        Me.TabPage6.PerformLayout()
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BindingSource2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage5.ResumeLayout(False)
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage4.ResumeLayout(False)
        Me.TabPage4.PerformLayout()
        CType(Me.DataGridView5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BindingSource5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BindingSource4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        CType(Me.DataGridView6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BindingSource6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BindingSource3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        CType(Me.DataGridView8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BindingSource8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BindingSource7, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage3.PerformLayout()
        CType(Me.Chart1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents TabPage6 As System.Windows.Forms.TabPage
    Friend WithEvents Writeignitionbutton As System.Windows.Forms.Button
    Friend WithEvents Readignitionbutton As System.Windows.Forms.Button
    Friend WithEvents DataGridView2 As System.Windows.Forms.DataGridView
    Friend WithEvents TabPage5 As System.Windows.Forms.TabPage
    Friend WithEvents Writefuelbutton As System.Windows.Forms.Button
    Friend WithEvents Readfuelbutton As System.Windows.Forms.Button
    Public WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents Startstopbutton As System.Windows.Forms.Button
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents BindingSource2 As System.Windows.Forms.BindingSource
    Friend WithEvents BindingSource1 As System.Windows.Forms.BindingSource
    Friend WithEvents Copyignitionbutton As System.Windows.Forms.Button
    Friend WithEvents Pasteignitionbutton As System.Windows.Forms.Button
    Friend WithEvents Pastefuelbutton As System.Windows.Forms.Button
    Friend WithEvents Copyfuelbutton As System.Windows.Forms.Button
    Friend WithEvents Savefuelbutton As System.Windows.Forms.Button
    Friend WithEvents Loadfuelbutton As System.Windows.Forms.Button
    Friend WithEvents Loadignitionbutton As System.Windows.Forms.Button
    Friend WithEvents Saveignitionbutton As System.Windows.Forms.Button
    Friend WithEvents BindingSource3 As System.Windows.Forms.BindingSource
    Public WithEvents DataGridView3 As System.Windows.Forms.DataGridView
    Friend WithEvents Configloadbutton As System.Windows.Forms.Button
    Friend WithEvents Configsavebutton As System.Windows.Forms.Button
    Friend WithEvents Removefuelrowbutton As System.Windows.Forms.Button
    Friend WithEvents Addfuelrowbutton As System.Windows.Forms.Button
    Friend WithEvents Removefuelcolumnbutton As System.Windows.Forms.Button
    Friend WithEvents Addfuelcolumnbutton As System.Windows.Forms.Button
    Friend WithEvents Removeignitionrowbutton As System.Windows.Forms.Button
    Friend WithEvents Addignitionrowbutton As System.Windows.Forms.Button
    Friend WithEvents Removeignitioncolumnbutton As System.Windows.Forms.Button
    Friend WithEvents Addignitioncolumnbutton As System.Windows.Forms.Button
    Public WithEvents DataGridView4 As System.Windows.Forms.DataGridView
    Friend WithEvents BindingSource4 As System.Windows.Forms.BindingSource
    Friend WithEvents Addressloadbutton As System.Windows.Forms.Button
    Friend WithEvents Addresssavebutton As System.Windows.Forms.Button
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Removeconfigrowbutton As System.Windows.Forms.Button
    Friend WithEvents Addconfigrowbutton As System.Windows.Forms.Button
    Friend WithEvents Ignitionrecolor As System.Windows.Forms.Button
    Friend WithEvents Fuelrecolor As System.Windows.Forms.Button
    Friend WithEvents Knockcolorloadbutton As System.Windows.Forms.Button
    Friend WithEvents Knockcolorsavebutton As System.Windows.Forms.Button
    Public WithEvents DataGridView5 As System.Windows.Forms.DataGridView
    Friend WithEvents BindingSource5 As System.Windows.Forms.BindingSource
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents Verify As System.Windows.Forms.CheckBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Success As System.Windows.Forms.TextBox
    Friend WithEvents Write As System.Windows.Forms.Button
    Friend WithEvents ROMfilename As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Blockaddressloadbutton As System.Windows.Forms.Button
    Friend WithEvents Blockaddresssavebutton As System.Windows.Forms.Button
    Public WithEvents DataGridView6 As System.Windows.Forms.DataGridView
    Friend WithEvents Choose As System.Windows.Forms.Button
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Baud As System.Windows.Forms.TextBox
    Friend WithEvents loggingdirectory As System.Windows.Forms.TextBox
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents BindingSource6 As System.Windows.Forms.BindingSource
    Friend WithEvents Clrcolors As System.Windows.Forms.Button
    Friend WithEvents Knocktrace As System.Windows.Forms.CheckBox
    Friend WithEvents selectactivecell As System.Windows.Forms.CheckBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Public WithEvents DataGridView7 As System.Windows.Forms.DataGridView
    Friend WithEvents BindingSource7 As System.Windows.Forms.BindingSource
    Public WithEvents DataGridView8 As System.Windows.Forms.DataGridView
    Friend WithEvents BindingSource8 As System.Windows.Forms.BindingSource
    Friend WithEvents MAPVEcalib As System.Windows.Forms.TextBox
    Friend WithEvents WriteMAPVEbutton As System.Windows.Forms.Button
    Friend WithEvents ReadMAPVEbutton As System.Windows.Forms.Button
    Friend WithEvents WriteRPMVEbutton As System.Windows.Forms.Button
    Friend WithEvents ReadRPMVEbutton As System.Windows.Forms.Button
    Friend WithEvents MAPVEloadbutton As System.Windows.Forms.Button
    Friend WithEvents MAPVEsavebutton As System.Windows.Forms.Button
    Friend WithEvents RPMVEloadbutton As System.Windows.Forms.Button
    Friend WithEvents RPMVEsavebutton As System.Windows.Forms.Button
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Writeinjsize As System.Windows.Forms.Button
    Friend WithEvents Readinjsize As System.Windows.Forms.Button
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Injsize As System.Windows.Forms.TextBox
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents Chartcheckbox As System.Windows.Forms.CheckBox
    Friend WithEvents Timer3 As System.Windows.Forms.Timer
    Friend WithEvents Chart1 As Dundas.Charting.WinControl.Chart

End Class
