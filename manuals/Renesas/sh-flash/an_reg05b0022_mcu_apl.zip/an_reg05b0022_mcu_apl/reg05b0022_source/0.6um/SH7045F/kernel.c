// kernel.c
// 
// Programming kernel for SH7045F
//
// Clock speed = 29.488MHz

#include "iodefine.h"				// IO header file

// change following define depending on target
#define SH
//#define H8

#ifdef SH
typedef unsigned long read_datum; // unsigned long for SH
#define BLANK_VALUE					0xFFFFFFFF
#else
typedef unsigned short read_datum;  // unsigned short for H8S
#define BLANK_VALUE					0xFFFF
#endif

// to get round the problem of different 'iodefine.h' files using slightly
// different names for the flash registers and bits the following defines
// are used
#define FLASH_SWE					FLASH.FLMCR1.BIT.SWE
#define	FLASH_PSU2					FLASH.FLMCR2.BIT.PSU2
#define	FLASH_PSU1					FLASH.FLMCR1.BIT.PSU1
#define FLASH_P2					FLASH.FLMCR2.BIT.P2
#define FLASH_P1					FLASH.FLMCR1.BIT.P1
#define FLASH_PV2					FLASH.FLMCR2.BIT.PV2
#define FLASH_PV1					FLASH.FLMCR1.BIT.PV1
#define FLASH_EB0					FLASH.EBR1.BIT.EB0
#define FLASH_EB1					FLASH.EBR1.BIT.EB1
#define FLASH_EB2					FLASH.EBR1.BIT.EB2
#define FLASH_EB3					FLASH.EBR1.BIT.EB3
#define FLASH_EB4					FLASH.EBR2.BIT.EB4
#define FLASH_EB5					FLASH.EBR2.BIT.EB5
#define FLASH_EB6					FLASH.EBR2.BIT.EB6
#define FLASH_EB7					FLASH.EBR2.BIT.EB7
#define FLASH_EB8					FLASH.EBR2.BIT.EB8
#define FLASH_EB9					FLASH.EBR2.BIT.EB9
#define FLASH_EB10					FLASH.EBR2.BIT.EB10
#define FLASH_EB11					FLASH.EBR2.BIT.EB11
#define FLASH_ESU2					FLASH.FLMCR2.BIT.ESU2
#define FLASH_ESU1					FLASH.FLMCR1.BIT.ESU1
#define FLASH_E2					FLASH.FLMCR2.BIT.E2
#define FLASH_E1					FLASH.FLMCR1.BIT.E1
#define FLASH_EV2					FLASH.FLMCR2.BIT.EV2
#define FLASH_EV1					FLASH.FLMCR1.BIT.EV1
#define FLASH_EBR1					FLASH.EBR1.BYTE
#define FLASH_EBR2					FLASH.EBR2.BYTE

// SH704/5F specific
#define MAX_FLASH_ADDR				0x40000
#define FLASH_LINE_SIZE				32
#define NO_OF_FLASH_BLOCKS			12
#define XTAL						29488000L
#define MAX_PROG_COUNT				1000
#define MAX_ERASE_ATTEMPTS			60
#define MAX_FLMCR1_ADDRESS			0x1FFFFL
// array below should contain the start addresses of the flash memory blocks
// final array element should contain the end address of the flash memory (+1)
const unsigned long eb_block_addr [NO_OF_FLASH_BLOCKS + 1] =  {
	0x00000000L,
	0x00008000L,
	0x00010000L,
	0x00018000L,
	0x00020000L,
	0x00028000L,
	0x00030000L,
	0x00038000L,
	0x0003F000L,
	0x0003F400L,
	0x0003F800L,
	0x0003FC00L,
	0x00040000L		/* max flash address + 1 */
};


#define BLANK						1
#define NOT_BLANK					2
#define PROG_PASS					0x01
#define PROG_FAIL					0x02
#define ERASE_PASS					0x01
#define ERASE_FAIL					0x02

// delay values
// note this is xtal frequency specific
// these values are for the SH7045F CMT with a system clock divider of 8
#define TWO_USEC					((2L * XTAL) / 8000000L)
#define FOUR_USEC					((4L * XTAL) / 8000000L)
#define FIVE_USEC					((5L * XTAL) / 8000000L)
#define TEN_USEC					((1L * XTAL) / 800000L)
#define TWENTY_USEC					((2L * XTAL) / 800000L)
#define FIFTY_USEC					((5L * XTAL) / 800000L)
#define TWO_HUNDRED_USEC			((2L * XTAL) / 80000L)
#define FIVE_MSEC					((5L * XTAL) / 8000L)


// function prototypes
void main (void);
unsigned char prog_flash_line_32 (unsigned long t_address, union char_rd_datum_union *p_data);
void delay (unsigned short);
void init_delay_timer (void);
unsigned char erase_block_06_um (unsigned char block_num);

union char_rd_datum_union {
    unsigned char c[FLASH_LINE_SIZE];
    read_datum u[FLASH_LINE_SIZE / sizeof (read_datum)];
} prog_data;

// variables
volatile unsigned long delay_counter;

// Functions
unsigned char prog_flash_line_32 (unsigned long t_address, union char_rd_datum_union *p_data)
{
    unsigned short n_prog_count;	// loop counter for programming attempts (0->MAX_PROG_COUNT)
    unsigned short d;				// general variable used for various loop counts
    unsigned char m;				// flag to indicate if re-programming required 1=yes 0=no
    unsigned char *dest_address;	// pointer used for writing to the flash
    unsigned char *uc_v_write_address;	// pointer used for writing to the addr to be verified
    read_datum *ul_v_read_address;	// pointer used to read address being verified
    unsigned char ax;				// variable used as loop counter for incrementing the
    								// pointer to the byte being wriiten next in verify process
    union char_rd_datum_union reprog_data;	// storage (on stack) for the re-program data

    // enable flash writes
    FLASH_SWE = 1;

    // wait 10us
    delay (TEN_USEC);

    // copy data from program data area to reprogram data area
    for (d=0; d<FLASH_LINE_SIZE; d++)
    {
        reprog_data.c[d] = p_data->c[d];
    }

    // program the data in FLASH_LINE_SIZE byte chunks
    for (n_prog_count=0; n_prog_count<MAX_PROG_COUNT; n_prog_count++)
    {
        // clear reprogram required flag
        m = 0;

        // copy data from reprogram data area into the flash
        dest_address = (unsigned char *) t_address;
        for (d=0; d<FLASH_LINE_SIZE; d++)
        {
            *dest_address++ = reprog_data.c[d];
        }

        // enter program setup
        if ( t_address > MAX_FLMCR1_ADDRESS )
        {
            // FLMCR2
            FLASH_PSU2 = 1;
        }
        else
        {
            // FLMCR1
            FLASH_PSU1 = 1;
        }

        // wait 50us
        delay (FIFTY_USEC);

        // start programming pulse
        if ( t_address > MAX_FLMCR1_ADDRESS )
        {
            // FLMCR2
            FLASH_P2 = 1;
        }
        else
        {
            // FLMCR1
            FLASH_P1 = 1;
        }

        // wait 200us
        delay (TWO_HUNDRED_USEC);

        // stop programming pulse
        if ( t_address > MAX_FLMCR1_ADDRESS )
        {
            // FLMCR2
            FLASH_P2 = 0;
        }
        else
        {
            // FLMCR1
            FLASH_P1 = 0;
        }

        // wait 20us
        delay (TEN_USEC);

        // leave programming setup
        if ( t_address > MAX_FLMCR1_ADDRESS )
        {
            // FLMCR2
            FLASH_PSU2 = 0;
        }
        else
        {
            // FLMCR1
            FLASH_PSU1 = 0;
        }

        // wait 10us
        delay (TEN_USEC);

        // enter program verify mode
        if ( t_address > MAX_FLMCR1_ADDRESS )
        {
            // FLMCR2
            FLASH_PV2 = 1;
        }
        else
        {
            // FLMCR1
            FLASH_PV1 = 1;
        }

        // wait 4us
        delay (FOUR_USEC);

        // verify the data via read_datum size reads
        uc_v_write_address = (unsigned char *) t_address;
        ul_v_read_address = (read_datum *) t_address;

        // verify loop
        for (d=0; d<(FLASH_LINE_SIZE / sizeof(read_datum)); d++)
        {
            // dummy write of H'FF to verify address
            *uc_v_write_address = 0xff;

            // increment this address by sizeof(read_datum) to get to next verify address
            for(ax=0; ax<sizeof(read_datum); ax++)
            {
                uc_v_write_address++;
            }

            // wait 2us
            delay (TWO_USEC);

            // read verify data
            // check with the original data
            if (*ul_v_read_address != p_data->u[d])
            {
                // 1 or more bits failed to program
                //
                // set the reprogram required flag
                m = 1;
            }

            // calculate reprog data
            reprog_data.u[d] = p_data->u[d] | ~(p_data->u[d] | *ul_v_read_address);

            // increment the pointers
            ul_v_read_address++;
        } // end of verify loop

        // exit program verify mode
        if ( t_address > MAX_FLMCR1_ADDRESS )
        {
            // FLMCR2
            FLASH_PV2 = 0;
        }
        else
        {
            // FLMCR1
            FLASH_PV1 = 0;
        }

        // wait 4us
        delay (FOUR_USEC);

        // check if flash line has successfully been programmed
        if (m == 0)
        {
            // program verified ok
            //
            // disable flash writes
            FLASH_SWE = 0;

            // end of successful programming
            return (PROG_PASS);
        }

    }   // end of MAX_PROG_COUNT attempts to program

    // failed to program after MAX_PROG_COUNT attempts
    // disable flash writes
    FLASH_SWE = 0;

    // end of failed programming
    return (PROG_FAIL);
}

unsigned char erase_block_06_um (unsigned char block_num)
{
	unsigned char erase;		// flag showing erase status - either BLANK or NOT_BLANK
	unsigned long attempts;		// counter for erase attempts (0->MAX_ERASE_ATTEMPTS)
	read_datum *ul_v_read;		// pointer for reading erase/verify data
	unsigned char *uc_v_write;	// pointer for writing erase/verify dummy byte
	unsigned char inc_uc_v_write_count;	// loop counter for incrementing the uc_v_write variable

	// check that block is not already erased
	erase = BLANK;
	for (attempts=eb_block_addr[block_num]; attempts<eb_block_addr[block_num + 1]; attempts++)
	{
		if ( *(unsigned char *) attempts != 0xff)
			erase = NOT_BLANK;
	}

	if (erase == BLANK)
		return ERASE_PASS;
	else
	{
		// block needs erasing
		//
		// enable flash writes
		FLASH_SWE = 1;

		// wait 10us
		delay (TEN_USEC);

		// set the correct EB bit in correct EBR register
		FLASH_EBR1 = 0;
		FLASH_EBR2 = 0;
		switch (block_num)
		{
			case 0:
				FLASH_EB0 = 1;
			break;

			case 1:
				FLASH_EB1 = 1;
			break;

			case 2:
				FLASH_EB2 = 1;
			break;

			case 3:
				FLASH_EB3 = 1;
			break;

			case 4:
				FLASH_EB4 = 1;			// note the change to EBR2 here!
			break;

			case 5:
				FLASH_EB5 = 1;
			break;

			case 6:
				FLASH_EB6 = 1;
			break;

			case 7:
				FLASH_EB7 = 1;
			break;

			case 8:
				FLASH_EB8 = 1;
			break;

			case 9:
				FLASH_EB9 = 1;
			break;

			case 10:
				FLASH_EB10 = 1;
			break;

			case 11:
				FLASH_EB11 = 1;
			break;
		}

		// initialise the attempts counter
		// 0 as we check for less than MAX (not <= MAX)
		attempts = 0;
		erase = NOT_BLANK;
		while ( (attempts < MAX_ERASE_ATTEMPTS) && (erase == NOT_BLANK) )
		{
			// increment the attempts counter
			attempts++;

			// enter erase setup mode
			if ( eb_block_addr [block_num] > MAX_FLMCR1_ADDRESS )
			{
				// FLMCR2
				FLASH_ESU2 = 1;
			}
			else
			{
				// FLMCR1
				FLASH_ESU1 = 1;
			}

			// wait 200us
			delay (TWO_HUNDRED_USEC);

			// transition to erase mode
			if ( eb_block_addr [block_num] > MAX_FLMCR1_ADDRESS )
			{
				// FLMCR2
				FLASH_E2 = 1;
			}
			else
			{
				// FLMCR1
				FLASH_E1 = 1;
			}

			// wait 5ms
			delay (FIVE_MSEC);

			// exit erase mode
			if ( eb_block_addr [block_num] > MAX_FLMCR1_ADDRESS )
			{
				// FLMCR2
				FLASH_E2 = 0;
			}
			else
			{
				// FLMCR1
				FLASH_E1 = 0;
			}

			// wait 10us
			delay (TEN_USEC);

			// exit erase setup mode
			if ( eb_block_addr [block_num] > MAX_FLMCR1_ADDRESS )
			{
				// FLMCR2
				FLASH_ESU2 = 0;
			}
			else
			{
				// FLMCR1
				FLASH_ESU1 = 0;
			}

			// wait 10 us
			delay (TEN_USEC);

			// enter erase/verify mode
			if ( eb_block_addr [block_num] > MAX_FLMCR1_ADDRESS )
			{
				// FLMCR2
				FLASH_EV2 = 1;
			}
			else
			{
				// FLMCR1
				FLASH_EV1 = 1;
			}

			// wait 20 us
			delay (TWENTY_USEC);

			// verify flash has been erased
			// read all the addresses in the current erase block and check that they are
			// successfully erased
			// exit this loop if a non-erased address is detected
			ul_v_read = (read_datum *) eb_block_addr [block_num];
			uc_v_write = (unsigned char *) eb_block_addr [block_num];
			erase = BLANK;
			while ( (erase == BLANK) && ( ul_v_read < (read_datum *) eb_block_addr [block_num + 1] ) )
			{
				// dummy write
				*uc_v_write = 0xff;

				// wait 2 us
				delay (TWO_USEC);

				if (*ul_v_read != BLANK_VALUE)
				{
					// this address is not erased yet
					erase = NOT_BLANK;
				}
				else
				{
					// advance to next verify write address
					for (inc_uc_v_write_count=0; inc_uc_v_write_count<sizeof(read_datum); inc_uc_v_write_count++)
					{
						uc_v_write++;
					}

					// advance to next verify read address
					ul_v_read++;
				}
			}

			// exit erase/verify mode
			if ( eb_block_addr [block_num] > MAX_FLMCR1_ADDRESS )
			{
				// FLMCR2
				FLASH_EV2 = 0;
			}
			else
			{
				// FLMCR1
				FLASH_EV1 = 0;
			}

			// wait 5 us
			delay (FIVE_USEC);
		}	// end of outer while loop

		// end either of erase attempts or block has been erased ok
		//
		// disable flash writes
		FLASH_SWE = 0;

		// check if block has been erased ok
		if (erase == BLANK)
		{
			// successfully erased
			return ERASE_PASS;
		}
		else
		{
			// failed to erase this block
			return ERASE_FAIL;
		}
	}
}

void init_delay_timer (void)
{
	// initialises compare match timer (CMT) channel 0
	
	// enable in module stop register
	//MST.MSTCR2.BIT.MSTP12 = 0;
	
	// stop channel 0
	CMT.CMSTR.BIT.STR0 = 0;
	
	// channel 0 compare match interrupt disabled
	CMT0.CMCSR.BIT.CMIE = 0;
	
	// system clock / 8
	CMT0.CMCSR.BIT.CKS = 0;
	
	// start timer
	CMT.CMSTR.BIT.STR0 = 1;
}

void delay (unsigned short d)
{
	// load compare match value into the constant register
	CMT0.CMCOR = d;

	// clear counter
	CMT0.CMCNT = 0;
	
	// clear compare match flag
	CMT0.CMCSR.BIT.CMF = 0;	

	// loop until we have a compare match
	while (CMT0.CMCSR.BIT.CMF == 0);
}

void main (void)
{
}
