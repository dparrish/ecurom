// Renesas H8/3664F example flash programming and erasing routines
//
// kernel.c
//
// Clock speed = 7.3728MHz
// H8/3664F uses SCI0 for boot mode
// Kernel start address - 0xF780


#include "iodefine.h"				// IO header file	 
#include <machine.h>

// H8/3664F specific
#define FLASH_SWE	FLASH.FLMCR1.BIT.SWE
#define FLASH_PSU	FLASH.FLMCR1.BIT.PSU
#define FLASH_P 	FLASH.FLMCR1.BIT.P
#define FLASH_PV	FLASH.FLMCR1.BIT.PV
#define FLASH_EBR1	FLASH.EBR1.BYTE
#define FLASH_ESU	FLASH.FLMCR1.BIT.ESU
#define FLASH_E 	FLASH.FLMCR1.BIT.E
#define FLASH_EV	FLASH.FLMCR1.BIT.EV
#define	FLASH_FENR	FLASH.FENR.BIT.FLSHE

// H8/3664F specific
#define MAX_FLASH_ADDR				0x8000
#define FLASH_LINE_SIZE 			128
#define NO_OF_FLASH_BLOCKS			5
#define XTAL						7372800L
#define MAX_PROG_COUNT				1000
#define MAX_ERASE_ATTEMPTS			100
#define BLANK_VALUE 				0xFFFF		// 0xFFFFFFFF for SH, 0xFFFF for H8S/300H

// array below should contain the start addresses of the flash memory blocks
// final array element should contain the end address of the flash memory (+1)
const unsigned long eb_block_addr [NO_OF_FLASH_BLOCKS + 1] =  {
	0x00000000L,
	0x00000400L,
	0x00000800L,
	0x00000C00L,
	0x00001000L,
	0x00008000L 	/* max flash address + 1 */
};

#define BLANK						1
#define NOT_BLANK					2
#define PROG_PASS					0x01
#define PROG_FAIL					0x02
#define ERASE_PASS					0x01
#define ERASE_FAIL					0x02

// delay values
// note this is xtal frequency specific
// these values are for the H8/3664F Timer W with a clock divider of 8
#define ONE_USEC					((1L * XTAL) / 8000000L)
#define TWO_USEC					((2L * XTAL) / 8000000L)
#define FOUR_USEC					((4L * XTAL) / 8000000L)
#define FIVE_USEC					((5L * XTAL) / 8000000L)
#define TEN_USEC					((1L * XTAL) / 800000L)
#define TWENTY_USEC 				((2L * XTAL) / 800000L)
#define THIRTY_USEC 				((3L * XTAL) / 800000L)
#define FIFTY_USEC					((5L * XTAL) / 800000L)
#define ONE_HUNDRED_USEC			((1L * XTAL) / 80000L)
#define TWO_HUNDRED_USEC			((2L * XTAL) / 80000L)
#define TEN_MSEC					((1L * XTAL) / 800L)


// typedef for reading the flash memory
// should be the size of the data bus connection to the flash memory
typedef unsigned short read_datum;

// function prototypes
unsigned char prog_flash_line_128 (unsigned long t_address, union char_rd_datum_union *p_data);
void delay (unsigned short);
void init_delay_timer (void);
unsigned char erase_block (unsigned char block_num);
void apply_write_pulse(unsigned short prog_pulse);

// variables
volatile unsigned long delay_counter;
union char_rd_datum_union {
	unsigned char c[FLASH_LINE_SIZE];
	read_datum u[FLASH_LINE_SIZE / sizeof (read_datum)];
} prog_data;


// Functions
unsigned char prog_flash_line_128 (unsigned long t_address, union char_rd_datum_union *p_data)
{
	// Function to program one 128 byte flash line
	//
	// t_address is the start address for the flash line to be programmed and must be
	// on a flash line boundary e.g. multiple of 128 (this is not checked and so must
	// be ensured by the caller)
	//
	// data to be programmed should be passed to this function in the form of a
	// 'char_rd_datum_union' union pointer
	//
	// returns:
	// PROG_PASS if programming is successful
	// PROG_FAIL if programming is unsucessful
	//
	// data must be written to the flash in byte units
	//
	// Please note that for the H8/3664F during the dummy write, setting the PSU
	// and P bits no RTS intructions are permitted.  Therefore no functions calls
	// are allowed.
	// For this reason at these points in this function the code from the 'delay'
	// function has been inlined to eliminate any RTS instructions.
	// For further information on this see the Flash ROM section of the H8/3664F
	// hardware manual version 4 or later.
	// Note: This information has been omitted in hardware manuals prior to version 4.
	// Please always ensure that you are using the very latest hardware manual.
	// Hardware manuals can be downloaded from the Internet by following the 'products'
	// link at:-
	// http://www.eu.reneas.com
		 
	unsigned short n_prog_count;		// loop counter for programming attempts (0 -> MAX_PROG_COUNT)
	unsigned short d;					// variable used for various loop counts
	unsigned short ax;					// loop counter for incrementing 'uc_v_write_address'
										// pointer (an unsigned short produces more efficient code than unsigned char in this case)
	unsigned char m;					// flag to indicate if re-programming is required (1=yes, 0=no)
	unsigned char *dest_address;		// pointer for writing to flash
	unsigned char *uc_v_write_address;	// pointer for writing to address to be verified
	read_datum *ul_v_read_address;		// pointer for reading verify address
	union char_rd_datum_union additional_prog_data, re_program_data;
										// storage on stack for intermediate programming data

	// enable access to the flash registers
	FLASH_FENR = 1;
	
	// enable flash writes
	FLASH_SWE = 1;

	// wait tSSWE (1 us)
	delay(ONE_USEC);

	// copy data from program data area to reprogram data area
	for (d=0; d<FLASH_LINE_SIZE; d++)
	{
		re_program_data.c[d] = p_data->c[d];
	}

	// program the data in FLASH_LINE_SIZE (128) byte chunks
	for (n_prog_count=0; n_prog_count<MAX_PROG_COUNT; n_prog_count++)
	{
		// clear reprogram required flag
		m = 0;

		// copy data from reprogram data area into the flash with byte wide access
		dest_address = (unsigned char *) t_address;
		for (d=0; d<FLASH_LINE_SIZE; d++)
		{
			*dest_address++ = re_program_data.c[d];
		}

		// to minimise code space the code to apply a write pulse has been
		// placed into a separate function called 'apply_write_pulse'
		if (n_prog_count < 6)
		{
			apply_write_pulse(THIRTY_USEC);
		}
		else
		{
			apply_write_pulse(TWO_HUNDRED_USEC);
		}


		// verify the data via word wide reads
		uc_v_write_address = (unsigned char *) t_address;
		ul_v_read_address = (read_datum *) t_address;

		// enter program verify mode
		FLASH_PV = 1;

		// wait tSPV (4 us)
		delay (FOUR_USEC);

		// read data in read_datum size chunks
		// verify loop
		for (d=0; d<(FLASH_LINE_SIZE / sizeof(read_datum)); d++)
		{
			// dummy write of H'FF to verify address
			*uc_v_write_address = 0xff;

			// see note at beginning of function
			// no RTS allowed here so 'apply_write_pulse' function inlined
			TMRW.GRA = TWO_USEC;
			TMRW.TCNT = 0;
			TMRW.TSR.BIT.IMFA = 0;
			TMRW.TMR.BIT.CTS = 1;
			while (TMRW.TSR.BIT.IMFA == 0);
			TMRW.TMR.BIT.CTS = 0;

			// increment this pointer to get to next verify address
			for (ax=0; ax<sizeof(read_datum); ax++)
				uc_v_write_address++;

			// read verify data
			// check with the original data
			if (*ul_v_read_address != p_data->u[d])
			{
				// 1 or more bits failed to program
				//
				// set the reprogram required flag
				m = 1;
			}

			// check if we need to calculate additional programming data
			if (n_prog_count < 6)
			{
				// calculate additional programming data
				// simple ORing of the reprog and verify data
				additional_prog_data.u[d] = re_program_data.u[d] | *ul_v_read_address;
			}

			// calculate reprog data
			re_program_data.u[d] = p_data->u[d] | ~(p_data->u[d] | *ul_v_read_address);

			// increment the verify read pointer
			ul_v_read_address++;
		} // end of verify loop

		// exit program verify mode
		FLASH_PV = 0;

		// wait tCPV (2 us)
		delay (TWO_USEC);

		// check if additional programming is required
		if (n_prog_count < 6)
		{
			// perform additional programming
			//
			// copy data from additional programming area to flash memory
			dest_address = (unsigned char *) t_address;
			for (d=0; d<FLASH_LINE_SIZE; d++)
			{
				*dest_address++ = additional_prog_data.c[d];
			}

			apply_write_pulse(TEN_USEC);
		}

		// check if flash line has successfully been programmed
		if (m == 0)
		{
			// program verified ok
			//
			// disable flash writes
			FLASH_SWE = 0;

			// wait tCSWE (100 us)
			delay (ONE_HUNDRED_USEC);

			// end of successful programming
			// disable access to the flash registers
			FLASH_FENR = 0;
			
			return (PROG_PASS);
		}

	} 	// end of for loop (n<MAX_PROG_COUNT) at this point we have made MAX_PROG_COUNT programming attempts
		
	// failed to program after MAX_PROG_COUNT attempts
	// disable flash writes
	FLASH_SWE = 0;

	// wait tCSWE (100 us)
	delay (ONE_HUNDRED_USEC);

	// end of failed programming
	// disable access to the flash registers
	FLASH_FENR = 0;
	
	return (PROG_FAIL);
}

void apply_write_pulse(unsigned short prog_pulse)
{
	// this function applies the programming pulse to the flash memory
	//
	// 'prog_pulse' contains the value to be loaded into the timer general register
	// caller must ensure that this value will provide the correct length programming
	// pulse for the timer and its clock divider
	//
	// under programming can result in either a failure to program or a reduced
	// data retention period
	//
	// over programming can permanently damage the flash cells
	//
	// Please note that for the H8/3664F during the dummy write, setting the PSU
	// and P bits no RTS intructions are permitted.  Therefore no functions calls
	// are allowed.
	// For this reason at these points in this function the code from the 'delay'
	// function has been inlined to eliminate any RTS instructions.
	// For further information on this see the Flash ROM section of the H8/3664F
	// hardware manual version 4 or later.
	// Note: This information has been omitted in hardware manuals prior to version 4.
	// Please always ensure that you are using the very latest hardware manual.
	// Hardware manuals can be downloaded from the Internet by following the 'products'
	// link at:-
	// http://www.renesas.com
		
	// enter program setup mode
	FLASH_PSU = 1;

	// see note at beginning of function
	// no RTS allowed here so 'apply_write_pulse' function inlined
	TMRW.GRA = FIFTY_USEC;
	TMRW.TCNT = 0;
	TMRW.TSR.BIT.IMFA = 0;
	TMRW.TMR.BIT.CTS = 1;
	while (TMRW.TSR.BIT.IMFA == 0);
	TMRW.TMR.BIT.CTS = 0;

	// start programming pulse
	FLASH_P = 1;

	// see note at beginning of function
	// no RTS allowed here so 'apply_write_pulse' function inlined
	TMRW.GRA = prog_pulse;
	TMRW.TCNT = 0;
	TMRW.TSR.BIT.IMFA = 0;
	TMRW.TMR.BIT.CTS = 1;
	while (TMRW.TSR.BIT.IMFA == 0);
	TMRW.TMR.BIT.CTS = 0;

	// stop programming
	FLASH_P = 0;

	// wait tCP (5 us)
	delay (FIVE_USEC);

	// exit program setup mode
	FLASH_PSU = 0;

	// wait tCPSU (5 us)
	delay (FIVE_USEC);
}

unsigned char erase_block (unsigned char block_num)
{
	// This function attempts to erase the flash memory block specified by
	// 'block_num' (0 -> NO_OF_FLASH_BLOCKS)
	//
	// returns:
	// ERASE_PASS is attempt is successful
	// ERASE_FAIL is attempt fails
	//
	// Please note that for the H8/3664F during the dummy write, setting the PSU
	// and P bits no RTS intructions are permitted.  Therefore no functions calls
	// are allowed.
	// For this reason at these points in this function the code from the 'delay'
	// function has been inlined to eliminate any RTS instructions.
	// For further information on this see the Flash ROM section of the H8/3664F
	// hardware manual version 4 or later.
	// Note: This information has been omitted in hardware manuals prior to version 4.
	// Please always ensure that you are using the very latest hardware manual.
	// Hardware manuals can be downloaded from the Internet by following the 'products'
	// link at:-
	// http://www.renesas.com


	unsigned char erase, ax, x;
	unsigned long attempts;
	read_datum *ul_v_read;
	unsigned char *uc_v_write;

	// check that block is not already erased
	erase = BLANK;
	for (attempts=eb_block_addr[block_num]; attempts<eb_block_addr[block_num + 1]; attempts++)
	{
		if ( *(unsigned char *) attempts != 0xff)
			erase = NOT_BLANK;
	}

	if (erase == BLANK)
		return ERASE_PASS;
	else
	{
		// block needs erasing
		//
		// enable access to the flash registers
		FLASH_FENR = 1;
		
		// enable flash writes
		FLASH_SWE = 1;

		// wait tSSWE (1us)
		delay (ONE_USEC);

		// initialise the attempts counter
		// 0 as we check for less than MAX (not <= MAX)
		attempts = 0;

		// set the correct EB bit in correct EBR register
		FLASH_EBR1 = 1<<block_num;

		erase = 0;
		while ( (attempts < MAX_ERASE_ATTEMPTS) && (erase == 0) )
		{
			// increment the attempts counter
			attempts++;

			// enter erase setup mode
			FLASH_ESU = 1;

			// wait tSESU (100 us)
			delay (ONE_HUNDRED_USEC);

			// start erasing
			FLASH_E = 1;

			// wait tSE (10 ms)
			delay (TEN_MSEC);

			// stop erasing
			FLASH_E = 0;

			// wait tCE (10 us)
			delay (TEN_USEC);

			// exit erase setup mode
			FLASH_ESU = 0;

			// wait tCESU (10 us)
			delay (TEN_USEC);

			// enter erase verify mode
			FLASH_EV = 1;

			// wait tSEV (20 us)
			delay (TWENTY_USEC);

			// verify flash has been erased
			// setup the pointers for reading and writing the flash
			ul_v_read = (read_datum *) eb_block_addr [block_num];
			uc_v_write = (unsigned char *) eb_block_addr [block_num];

			erase = 1;
			while ( (erase == 1) && ( ul_v_read < (read_datum *) eb_block_addr [block_num + 1] ) )
			{
				// this loop will exit either when one word is not erased ('erase' becomes 0)
				// or all addresses have been read as erased ('erase' stays as 1)
				// if 'erase' stays as 1 the outer while loop will exit as the block has been erased
				//
				// dummy write
				*uc_v_write = 0xff;

				// see note at beginning of function
				// no RTS allowed here so 'apply_write_pulse' function inlined
				TMRW.GRA = TWO_USEC;
				TMRW.TCNT = 0;
				TMRW.TSR.BIT.IMFA = 0;
				TMRW.TMR.BIT.CTS = 1;
				while (TMRW.TSR.BIT.IMFA == 0);
				TMRW.TMR.BIT.CTS = 0;

				if (*ul_v_read != BLANK_VALUE)
				{
					// this word is not erased yet
					erase = 0;
				}
				else
				{
					// advance to the next byte write address
					for (ax=0; ax<sizeof(read_datum); ax++)
						uc_v_write++;

					// advance to the next verify read address
					ul_v_read++;
				}
			}

			// exit erase verify mode
			FLASH_EV = 0;

			// wait tCEV (4 us)
			delay (FOUR_USEC);
		}	// end of outer while loop

		// end either of erase attempts or block has been erased ok
		//
		// disable flash writes
		FLASH_SWE = 0;

		// wait tCSWE (100 us)
		delay (ONE_HUNDRED_USEC);

		// check if block has been erased ok
		if (erase == 1)
		{
			// successfully erased
			// disable access to the flash registers
			FLASH_FENR = 0;
			return ERASE_PASS;
		}
		else
		{
			// failed to erase this block
			// disable access to the flash registers
			FLASH_FENR = 0;
			return ERASE_FAIL;
		}
	}
}



void init_delay_timer (void)
{
	// Stop Timer Count
	TMRW.TMR.BIT.CTS = 0;

	// Compare match A interrupt disabled
	TMRW.TIER.BIT.IMIEA = 0;

	// System clock / 8
	TMRW.TCR.BIT.CKS = 3;
}

void delay (unsigned short d)
{
	// load compare match value into the constant register A
	TMRW.GRA = d;

	// Clear counter
	TMRW.TCNT = 0;

	// Clear compare match flag
	TMRW.TSR.BIT.IMFA = 0;

	// Start the timerW
	TMRW.TMR.BIT.CTS = 1;

	// Loop until we have a compare match
	while (TMRW.TSR.BIT.IMFA == 0);

	// Stop the TimerW
	TMRW.TMR.BIT.CTS = 0;
}

void main(void)
{
}
