// kernel.c
// 
//
// Clock speed = 44.236MHz


#include "io7047f_ws.h"				// IO header file

// change following define depending on target
#define SH
//#define H8

#ifdef SH
typedef unsigned long read_datum; // unsigned long for SH
#define BLANK_VALUE					0xFFFFFFFF
#else
typedef unsigned short read_datum;  // unsigned short for H8S
#define BLANK_VALUE					0xFFFF
#endif

#define FLASH_SWE	FLASH.FLMCR1.BIT.SWE
#define FLASH_PSU	FLASH.FLMCR1.BIT.PSU
#define FLASH_P		FLASH.FLMCR1.BIT.P
#define FLASH_PV	FLASH.FLMCR1.BIT.PV
#define FLASH_EBR1	FLASH.EBR1.BYTE
#define FLASH_EBR2	FLASH.EBR2.BYTE
#define FLASH_EB0	FLASH.EBR1.BIT.EB0
#define FLASH_EB1	FLASH.EBR1.BIT.EB1
#define FLASH_EB2	FLASH.EBR1.BIT.EB2
#define FLASH_EB3	FLASH.EBR1.BIT.EB3
#define FLASH_EB4	FLASH.EBR1.BIT.EB4
#define FLASH_EB5	FLASH.EBR1.BIT.EB5
#define FLASH_EB6	FLASH.EBR1.BIT.EB6
#define FLASH_EB7	FLASH.EBR1.BIT.EB7
#define FLASH_EB8	FLASH.EBR2.BIT.EB8
#define FLASH_EB9	FLASH.EBR2.BIT.EB9
#define FLASH_EB10	FLASH.EBR2.BIT.EB10
#define FLASH_EB11	FLASH.EBR2.BIT.EB11
#define FLASH_ESU	FLASH.FLMCR1.BIT.ESU
#define FLASH_E		FLASH.FLMCR1.BIT.E
#define FLASH_EV	FLASH.FLMCR1.BIT.EV

// SH7047F WS specific
#define MAX_FLASH_ADDR				0x40000
#define FLASH_LINE_SIZE				128
#define NO_OF_FLASH_BLOCKS			12
//#define XTAL						36864000L
#define XTAL						44236800L
#define MAX_PROG_COUNT				1000
//#define BAUD_115200					9
#define BAUD_115200					11
#define MAX_ERASE_ATTEMPTS			120
// array below should contain the start addresses of the flash memory blocks
// final array element should contain the end address of the flash memory (+1)
const unsigned long eb_block_addr [NO_OF_FLASH_BLOCKS + 1] =  {
	0x00000000L,
	0x00001000L,
	0x00002000L,
	0x00003000L,
	0x00004000L,
	0x00005000L,
	0x00006000L,
	0x00007000L,
	0x00008000L,
	0x00010000L,
	0x00020000L,
	0x00030000L,
	0x00040000L		/* max flash address + 1 */
};

#define BLANK						1
#define NOT_BLANK					2
#define PROG_PASS					0x01
#define PROG_FAIL					0x02
#define ERASE_PASS					0x01
#define ERASE_FAIL					0x02

// delay values
// note this is xtal frequency specific
// these values are for the SH7047F CMT with a system clock deivider of 8
#define ONE_USEC					((1L * XTAL) / 8000000L)
#define TWO_USEC					((2L * XTAL) / 8000000L)
#define FOUR_USEC					((4L * XTAL) / 8000000L)
#define FIVE_USEC					((5L * XTAL) / 8000000L)
#define TEN_USEC					((1L * XTAL) / 800000L)
#define TWENTY_USEC					((2L * XTAL) / 800000L)
#define THIRTY_USEC					((3L * XTAL) / 800000L)
#define FIFTY_USEC					((5L * XTAL) / 800000L)
#define ONE_HUNDRED_USEC			((1L * XTAL) / 80000L)
#define TWO_HUNDRED_USEC			((2L * XTAL) / 80000L)
#define TEN_MSEC					((1L * XTAL) / 800L)

// function prototypes
void main (void);
unsigned char prog_flash_line_128 (unsigned long t_address, union char_rd_datum_union *p_data);
void delay (unsigned short);
void init_delay_timer (void);
unsigned char erase_block_035_um (unsigned char block_num);

// variables
volatile unsigned long delay_counter;

union char_rd_datum_union {
	unsigned char c[FLASH_LINE_SIZE];
	read_datum u[FLASH_LINE_SIZE / sizeof (read_datum)];
} prog_data;


// Functions
unsigned char prog_flash_line_128 (unsigned long t_address, union char_rd_datum_union *p_data)
{
	// function to program one 128 byte flash line
	//
	// t_address is the start address for the flash line to be programmed
	//
	// data to be prgrammed should be passed to this function in the form of a 
	// 'char_rd_datum_union' union pointer
	//
	// data must be written to the flash in byte units	
	
	unsigned short n_prog_count; 	// loop counter for programming attempts (0->MAX_PROG_COUNT)
	unsigned short d;				// variable used for various loop counts
	unsigned char m;				// flag to indicate if re-programming required (1=yes 0=no)
	unsigned char ax;				// loop counter for incrementing 'uc_v_write_address' ptr
	unsigned char *dest_address;	// pointer for writing to flash
	unsigned char *uc_v_write_address;	// pointer for writing to address to be verified
	read_datum *ul_v_read_address;	// pointer for reading verify address
	union  char_rd_datum_union additional_prog_data, re_program_data;	// storage on stack
	
	// enable flash writes
	FLASH_SWE = 1;
	
	// wait tSSWE
	delay(ONE_USEC);
	
	// copy data from program data area to reprogram data area
	for (d=0; d<FLASH_LINE_SIZE; d++)
	{
		re_program_data.c[d] = p_data->c[d];
	}
	
	// program the data in FLASH_LINE_SIZE byte chunks
	for (n_prog_count=0; n_prog_count<MAX_PROG_COUNT; n_prog_count++)
	{
		// clear reprogram required flag
		m = 0;
		
		// copy data from reprogram data area into the flash with byte access
		dest_address = (unsigned char *) t_address;
		for (d=0; d<FLASH_LINE_SIZE; d++)
		{
			*dest_address++ = re_program_data.c[d];
		}
		
		// apply the write pulse
		// note that this is specified as a sub-routine call in the hw manual
		// flowchart but is part of this single function here
		//
		// if code size is a problem then placing this code in a sub-routine may be beneficial
		//
		// enter program setup
		FLASH_PSU = 1;
		
		// wait tSPSU
		delay (FIFTY_USEC);
		
		// start programming pulse
		FLASH_P = 1;
		
		if (n_prog_count < 6)
			delay (THIRTY_USEC);
		else
			delay (TWO_HUNDRED_USEC);
			
		// stop programming
		FLASH_P = 0;
		
		// wait tCP
		delay (FIVE_USEC);
		
		// exit program setup
		FLASH_PSU = 0;
		
		// wait tCPSU
		delay (FIVE_USEC);
		
		// verify the data via long word reads
		uc_v_write_address = (unsigned char *) t_address;
		ul_v_read_address = (read_datum *) t_address;
				
		// enter program verify mode
		FLASH_PV = 1;
		
		// wait tSPV
		delay (FOUR_USEC);
		
		// read data in read_datum size chunks
		// verify loop
		for (d=0; d<(FLASH_LINE_SIZE / sizeof(read_datum)); d++)
		{
			// dummy write of H'FF to verify address
			*uc_v_write_address = 0xff;
			
			// wait tSPVR
			delay (TWO_USEC);
			
			// increment this pointer to get to next verify address
			for (ax=0; ax<sizeof(read_datum); ax++)
				uc_v_write_address++;
			
			// read verify data
			// check with the original data
			if (*ul_v_read_address != p_data->u[d])
			{
				// 1 or more bits failed to program
				//
				// set the reprogram required flag
				m = 1;
			}
			
			// check if we need to calculate additional programming data
			if (n_prog_count < 6)
			{
				// calculate additional programming data
				// simple ORing of the reprog and verify data
				additional_prog_data.u[d] = re_program_data.u[d] | *ul_v_read_address;
			}
			
			// calculate reprog data
			re_program_data.u[d] = p_data->u[d] | ~(p_data->u[d] | *ul_v_read_address);
		
			// increment the verify read pointer
			ul_v_read_address++;
		} // end of verify loop
		
		// exit program verify mode
		FLASH_PV = 0;
		
		// wait tCPV
		delay (TWO_USEC);
		
		// check if additional programming is required
		if (n_prog_count < 6)
		{
			// perform additional programming
			//
			// copy data from additional programming area to flash memory
			dest_address = (unsigned char *) t_address;
			for (d=0; d<FLASH_LINE_SIZE; d++)
			{
				*dest_address++ = additional_prog_data.c[d];
			}
			
			// enter program setup
			FLASH_PSU = 1;
			
			// wait SPSU
			delay (FIFTY_USEC);
			
			// start programming pulse
			FLASH_P = 1;
			
			// wait tSP
			delay (TEN_USEC);
				
			// stop programming
			FLASH_P = 0;
			
			// wait
			delay (FIVE_USEC);
			
			// exit program setup
			FLASH_PSU = 0;
			
			// wait tCPSU
			delay (FIVE_USEC);
		}
		
		// check if flash line has successfully been programmed
		if (m == 0)
		{
			// program verified ok
			//
			// disable flash writes
			FLASH_SWE = 0;
			
			// wait tCSWE
			delay (ONE_HUNDRED_USEC);
			
			// end of successful programming
			return (PROG_PASS);
		}
				
	} // end of for loop (n<MAX_PROG_COUNT) at this point we have made MAX_PROG_COUNT prog attempts
	
	// failed to program after MAX_PROG_COUNT attempts
	// disable flash writes
	FLASH_SWE = 0;
			
	// wait tCSWE
	delay (ONE_HUNDRED_USEC);
			
	// end of failed programming
	return (PROG_FAIL);
}

unsigned char erase_block_035_um (unsigned char block_num)
{	
	unsigned char erase;		// flag showing erase status - BLANK or NOT_BLANK
	unsigned char ax;			// loop counter
	unsigned long attempts;		// loop counter for erase attempts (0->MAX_ERASE_ATTEMPTS)
	read_datum *ul_v_read;		// pointer for reading verify data
	unsigned char *uc_v_write;	// pointer for writing to verify data area
	
	// check that block is not already erased
	erase = BLANK;
	for (attempts=eb_block_addr[block_num]; attempts<eb_block_addr[block_num + 1]; attempts++)
	{
		if ( *(unsigned char *) attempts != 0xff)
			erase = NOT_BLANK;
	}
	
	if (erase == BLANK)
		return ERASE_PASS;
	else
	{
		// block needs erasing
		//
		// enable flash writes
		FLASH_SWE = 1;
		
		// wait tSSWE
		delay (ONE_USEC);
		
		// set the correct EB bit in correct EBR register
		// this is usually device specific
		FLASH_EBR1 = 0;
		FLASH_EBR2 = 0;
		switch (block_num)
		{
			case 0:
				FLASH_EB0 = 1;
			break;
			
			case 1:
				FLASH_EB1 = 1;
			break;
			
			case 2:
				FLASH_EB2 = 1;
			break;
			
			case 3:
				FLASH_EB3 = 1;
			break;
			
			case 4:
				FLASH_EB4 = 1;
			break;
			
			case 5:
				FLASH_EB5 = 1;
			break;
			
			case 6:
				FLASH_EB6 = 1;
			break;
			
			case 7:
				FLASH_EB7 = 1;
			break;
			
			case 8:
				FLASH_EB8 = 1;			// note the change to EBR2 here!
			break;
			
			case 9:
				FLASH_EB9 = 1;
			break;
			
			case 10:
				FLASH_EB10 = 1;
			break;
			
			case 11:
				FLASH_EB11 = 1;
			break;
		}
		
		// initialise the attempts counter
		attempts = 0;
		erase = NOT_BLANK;
		while ( (attempts < MAX_ERASE_ATTEMPTS) && (erase == NOT_BLANK) )
		{		
			// increment the attempts counter
			attempts++;
			
			// enter erase mode
			FLASH_ESU = 1;
			
			// wait tSESU (100 us)
			delay (ONE_HUNDRED_USEC);
			
			// start erasing
			FLASH_E = 1;
			
			// wait tSE
			delay (TEN_MSEC);
			
			// stop erasing
			FLASH_E = 0;
			
			// wait tCE
			delay (TEN_USEC);
			
			// exit erase mode
			FLASH_ESU = 0;
			
			// wait tCESU
			delay (TEN_USEC);
			
			// enter erase verify mode
			FLASH_EV = 1;
			
			// wait tSEV
			delay (TWENTY_USEC);
			
			// verify flash has been erased
			ul_v_read = (read_datum *) eb_block_addr [block_num];
			uc_v_write = (unsigned char *) eb_block_addr [block_num];
			
			erase = BLANK;
			while ( (erase == BLANK) && ( ul_v_read < (read_datum *) eb_block_addr [block_num + 1] ) )
			{
				// this loop will exit either when one long word is not erased
				// or all addresses have been read as erased
				//
				// dummy write
				*uc_v_write = 0xff;
				
				// wait tSEVR
				delay (TWO_USEC);
				
				if (*ul_v_read != BLANK_VALUE)
				{
					// this word is not erased yet
					erase = NOT_BLANK;
				}
				else
				{
					// advance to the next byte write address
					for (ax=0; ax<sizeof(read_datum); ax++)
						uc_v_write++;
						
     				// advance to the next verify read address
					ul_v_read++;
				}
			}
			
			// exit erase verify mode
			FLASH_EV = 0;
			
			// wait tCEV
			delay (FOUR_USEC);
		}	// end of outer while loop
		
		// end either of erase attempts or block has been erased ok
		//
		// disable flash writes
		FLASH_SWE = 0;
		
		// wait tCSWE
		delay (ONE_HUNDRED_USEC);
		
		// check if block has been erased ok
		if (erase == BLANK)
		{
			// successfully erased
			return ERASE_PASS;
		}
		else
		{
			// failed to erase this block
			return ERASE_FAIL;
		}
	}		
}

void init_delay_timer (void)
{
	// initialises compare match timer (CMT) channel 0
	
	// enable in module stop register
	MST.MSTCR2.BIT.MSTP12 = 0;
	
	// stop channel 0
	CMT.CMSTR.BIT.STR = 0;
	
	// channel 0 compare match interrupt disabled
	CMT.CMCSR_0.BIT.CMIE = 0;
	
	// system clock / 8
	CMT.CMCSR_0.BIT.CKS = 0;
	
	// start timer
	CMT.CMSTR.BIT.STR = 1;
}

void delay (unsigned short d)
{
	// load compare match value into the constant register
	CMT.CMCOR_0 = d;

	// clear counter
	CMT.CMCNT_0 = 0;
	
	// clear compare match flag
	CMT.CMCSR_0.BIT.CMF = 0;	

	// loop until we have a compare match
	while (CMT.CMCSR_0.BIT.CMF == 0);
}

void main (void)
{
    init_delay_timer();
    
    while(1)
    {
    }
}