// flash.h

#ifndef _FLASH_H
#define _FLASH_H

#define H83069F
//#define INUSERBOOTMODE

#define FLASH_NO_ERROR					0x0000
#define	FLASH_PROG_ERASE_DOWNLOAD_ERROR	0x0100
#define FLASH_INIT_ERROR				0x0200
#define FLASH_PROGRAMMING_ERROR			0x0400
#define FLASH_ERASING_ERROR				0x0800

union fl_fccs { 							/* FCCS 		*/
	unsigned char BYTE; 			/*	Byte Access */
	struct {						/*	Bit  Access */
		unsigned char FWE :1;		/*	  FWE		*/
		unsigned char	  :2;		/*				*/
		unsigned char FLER:1;		/*	  FLER		*/
		unsigned char	  :3;		/*				*/
		unsigned char SCO :1;		/*	  SCO		*/
	} BIT;
};

union fl_fpcs { 							/* FPCS 		*/
	unsigned char BYTE; 			/*	Byte Access */
	struct {						/*	Bit  Access */
		unsigned char	  :7;		/*				*/
		unsigned char PPVS:1;		/*	  PPVS		*/
	} BIT;
};

union fl_fecs { 							/* FECS 		*/
	unsigned char BYTE; 			/*	Byte Access */
	struct {						/*	Bit  Access */
		unsigned char	  :7;		/*				*/
		unsigned char EPVB:1;		/*	  EPVB		*/
	} BIT;
};

union fl_ramcr {								/* RAMCR		 */
	unsigned char BYTE; 			/*	Byte Access */
	struct {						/*	Bit  Access */
		unsigned char	  :4;		/*				*/
		unsigned char RAMS:1;		/*	  RAMS		*/
		unsigned char RAM2:1;		/*	  RAM2		*/
		unsigned char RAM1:1;		/*	  RAM1		*/
		unsigned char RAM0:1;		/*	  RAM0		*/
	} BIT;
};

#ifdef H83069F
union fl_fvacr {								  /* FVACR		  */
	  unsigned char BYTE;			  /*  Byte Access */
	  struct {						  /*  Bit  Access */
		  unsigned char FVCHGE:1;	  /*	FVCHGE	  */
		  unsigned char 	  :3;	  /*			  */
		  unsigned char FVSEL3 :1;	 /*    FVSEL	 */
		  unsigned char FVSEL2 :1;	  /*	FVSEL	  */
		  unsigned char FVSEL1 :1;	  /*	FVSEL	  */
		  unsigned char FVSEL0 :1;	  /*	FVSEL	  */
	  } BIT;
};
#endif

// SH7058F
#ifndef H83069F
#define FLASH_FCCS		(*(volatile union fl_fccs	*)0xFFFFE800)
#define FLASH_FPCS		(*(volatile union fl_fpcs	*)0xFFFFE801)
#define FLASH_FECS		(*(volatile union fl_fecs	*)0xFFFFE802)
#define FLASH_FKEY		(*(volatile unsigned char	*)0xFFFFE804)
#define FLASH_FMATS 	(*(volatile unsigned char	*)0xFFFFE805)
#define FLASH_FTDAR		(*(volatile unsigned char	*)0xFFFFE806)
#define FLASH_RAMER 	(*(volatile union fl_ramcr	*)0xFFFFEC26)

#define FTDAR_START_ADDRESS_FFFF0000 0x00
#define FTDAR_START_ADDRESS_FFFF0800 0x01
#define FTDAR_START_ADDRESS_FFFF1000 0x02
#define FTDAR_START_ADDRESS_FFFF1800 0x03
#define FTDAR_START_ADDRESS_FFFF2000 0x04
#define FTDAR_START_ADDRESS_FFFF2800 0x05

#define FTDAR_ADDRESS				0xFFFF0800
#define CPU_CLOCK_FREQ				4000	// 40MHz
#define USER_BRANCH_DEST_ADDRESS	0		// no address
#endif

// H8/3069F
#ifdef H83069F
#define FLASH_FCCS		(*(volatile union fl_fccs	*)0xFEE0B0)
#define FLASH_FPCS		(*(volatile union fl_fpcs	*)0xFEE0B1)
#define FLASH_FECS		(*(volatile union fl_fecs	*)0xFEE0B2)
#define FLASH_FKEY		(*(volatile unsigned char	*)0xFEE0B4)
#define FLASH_FMATS 	(*(volatile unsigned char	*)0xFEE0B5)
#define FLASH_FTDAR		(*(volatile unsigned char	*)0xFEE0B6)
#define FLASH_RAMER 	(*(volatile union fl_ramcr	*)0xFEE077)
#define FLASH_FVACR		(*(volatile union fl_fvacr  *)0xFEE0B7)
#define FLASH_FVADRR	(*(volatile unsigned char   *)0xFEE0B8)
#define FLASH_FVADRE	(*(volatile unsigned char   *)0xFEE0B9)
#define FLASH_FVADRH	(*(volatile unsigned char   *)0xFEE0BA)
#define FLASH_FVADRL	(*(volatile unsigned char   *)0xFEE0BB)

#define FTDAR_START_ADDRESS_FFEF20	 0x00
#define FTDAR_START_ADDRESS_FFDF20	 0x01
#define FTDAR_START_ADDRESS_FFCF20	 0x02
#define FTDAR_START_ADDRESS_FFBF20	 0x03

#define FTDAR_ADDRESS				0xFFCF20
#define FTDAR_START_ADDRESS			FTDAR_START_ADDRESS_FFCF20
#define CPU_CLOCK_FREQ				2212	// 22.1184MHz
#define USER_BRANCH_DEST_ADDRESS	0		// no address
#endif

#define INIT_PROGRAM_ADDRESS		(FTDAR_ADDRESS + 32)
#define INIT_ERASE_ADDRESS			INIT_PROGRAM_ADDRESS
#define PROG_ROUTINE_ADDRESS		(FTDAR_ADDRESS + 16)
#define ERASE_ROUTINE_ADDRESS		PROG_ROUTINE_ADDRESS

// function prototypes
unsigned short Erase018FlashBlock( unsigned char );
unsigned short Program018FlashLine( unsigned long, unsigned char * );

#endif