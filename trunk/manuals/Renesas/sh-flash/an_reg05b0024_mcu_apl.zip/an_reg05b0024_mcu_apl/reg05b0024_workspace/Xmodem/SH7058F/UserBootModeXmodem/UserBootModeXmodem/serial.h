// serial.h

#ifndef _SERIAL_H
#define _SERIAL_H

#include "iodefine.h"

#define BAUD_115200			4
#define BAUD_57600			10
#define BAUD_56000			10
#define BAUD_38400			15
#define BAUD_9600			64

#define SCI_CH_NUM			1

#define LINEFEED			10
#define CARRIAGE_RETURN		13

// status info
#define OK					0
#define ERROR				1
#define TIMEOUT				2

// IO defines to get around the problem of differing 'iodefine.h' files
// change the defines here and not all through the code
#if SCI_CH_NUM == 0
#define SCI_CH				P_SCI0
#elif SCI_CH_NUM == 1
#define SCI_CH				P_SCI1
#elif SCI_CH_NUM == 2
#define SCI_CH				P_SCI2
#elif SCI_CH_NUM == 3
#define SCI_CH				P_SCI3
#elif SCI_CH_NUM == 4
#define SCI_CH				P_SCI4
#endif
#define SCI_SMR				SCI_CH.SMR
#define SCI_BRR				SCI_CH.BRR
#define SCI_SCR				SCI_CH.SCR
#define SCI_SSR				SCI_CH.SSR
#define SCI_TDR				SCI_CH.TDR
#define SCI_RDR				SCI_CH.RDR
#define SCI_SCMR			SCI_CH.SCMR

// structure definitions
union union_c2s {
		unsigned char uc[2];
		unsigned short us;
};

// function prototypes
void InitSci (void);
unsigned short GetByte (unsigned long timeout);
void SendByte (unsigned char b);
void SendString (char* str);
unsigned char RxByteWaiting (void);
void PurgeComms (unsigned long timeout);

#endif