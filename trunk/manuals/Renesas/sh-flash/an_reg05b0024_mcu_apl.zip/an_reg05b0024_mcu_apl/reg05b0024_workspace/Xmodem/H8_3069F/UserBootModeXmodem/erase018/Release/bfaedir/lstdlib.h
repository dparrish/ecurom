/*--------------------------------------------------------------------*/
/* H8S,H8/300 SERIES C Compiler Ver. 1.0                              */
/* Copyright (C) 1994 Hitachi, Ltd.                                   */
/* Licensed Material of Hitachi,Ltd.                                  */
/*--------------------------------------------------------------------*/
/*****************************************************************/
/* SPEC ;                                                        */
/*   NAME = stdlib :                                             */
/*   FUNC =                                                      */
/*          ;                                                    */
/*                                                               */
/*                                                               */
/*                                                               */
/*   CLAS = UNIT ;                                               */
/*   END ;                                                       */
/*****************************************************************/

#include "lstddef.h"

typedef struct {int quot; int rem;} div_t ;
typedef struct {long quot; long rem;} ldiv_t ;

#define RAND_MAX  32767
#define ERANGE  1100
#define EDOM    1101
#define EDIV    1102
#define ESTRN   1104
#define ECBASE  1200
#define ETLN    1202
#define EEXP    1204
#define EEXPN   1206
#define EFLOATO 1210
#define EFLOATU 1220
#define EOVER   1230
#define EUNDER  1240

#define HUGE_VAL _HUGE_VAL

