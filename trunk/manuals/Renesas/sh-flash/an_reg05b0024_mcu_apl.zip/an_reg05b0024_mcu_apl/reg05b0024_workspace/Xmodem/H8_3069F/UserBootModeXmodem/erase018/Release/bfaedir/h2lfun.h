/*--------------------------------------------------------------------*/
/* H8S,H8/300 SERIES C Compiler Ver. 1.0                              */
/* Copyright (C) 1994 Hitachi, Ltd.                                   */
/* Licensed Material of Hitachi,Ltd.                                  */
/*--------------------------------------------------------------------*/
/*****************************************************************/
/* SPEC ;                                                        */
/*   NAME = h2lfun.h :                                           */
/*   FUNC = define of type  &  check macro ;                     */
/*                                                               */
/*   END ;                                                       */
/*****************************************************************/

#ifdef __FLT__                                           /* A P3SB068 */
#define double long double                               /* A P3SB068 */
#endif                                                   /* A P3SB068 */
                                                         /*   P3SB068 */
#ifndef  _SIZE_T                                    /* V3.0 C P3V054L */
#define  _SIZE_T                                    /* V3.0 C P3V054L */
#if __CPU__ == 3 || __CPU__ == 5 || __CPU__ == 7    /* V3.0 C P3V001L */
typedef unsigned long   size_t;                     /* V3.0 C P3V054L */
#define ALLOC_MAX 0xFFFFFFFE                            /* A P3S115-1 */
#else
typedef unsigned int    size_t;                     /* V3.0 C P3V054L */
#define ALLOC_MAX 0xFFFE                                /* A P3S115-1 */
#endif
#endif

#define VOID               void
#define LONG               long
#define SSHORT     signed short
#define USHORT   unsigned short
#define SHORT             short
#define CHAR               char
#define UCHAR     unsigned char
#define INT                long
#define REG            register
#define LSTAT            static
#define flgck1(fp,flg) (fp->_ioflag1&flg)    /* _ioflag1 check macro */
#define flgck2(fp,flg) (fp->_ioflag2&flg)    /* _ioflag2 check macro */

#define _toint(x)
#define _tolng(x)
#define _todbl(x)

#ifdef _APPEND
typedef int _ALIGN;
union _header {
              struct {
                      size_t size;          /* V2.0 C */
/***                  size_t arysize;                   *** D S60009P */
/***                  size_t element;                   *** D S60009P */
                      union _header *next;
              } space;
              _ALIGN x;
};
typedef union _header _HEADER;
extern _HEADER *_freeptr;
#endif

/* #ifdef _IOPROT                                         */ 
/* extern int    open(char*, int,int);                    */
/* extern int    read(int, char*, unsigned);              */ 
/* extern int    write(int, char*, unsigned);             */
/* extern int    close(int);                              */
/* extern long   lseek(int, long, int);                   */
/* extern int    _flopen(const char*, const char*, char*);*/ 
/* extern int    _flclose(FILE*);                         */
/* extern int    _fillbuf(FILE*);                         */
/* extern int    _flshbuf(int, FILE*);                    */
/* extern void   _alocbuf(FILE*);                         */
/* extern int    _fmtin(int, int (*)(FILE *),
                        FILE*, const char*, char*);  */
/* extern int    _fmtout(int, int (*)(int, FILE *), 
                         FILE*, const char*, char*); */
/* #endif                                                 */

/* extern VOID   _its(CHAR*, CHAR*, INT);                 */
/* extern int    _dti(double, INT, CHAR*, INT*, CHAR*);   */
/* extern double _std(INT, CHAR*, INT);                   */
/* extern VOID   _mult(UCHAR*, UCHAR*, UCHAR*);           */
/* extern VOID   _mult64(SHORT*, UCHAR*, SHORT, UCHAR*);  */
/* extern VOID   _divi(CHAR*, CHAR*, CHAR*);              */
/* extern int    _sub(INT, UCHAR*, UCHAR*, INT);          */
/* extern VOID   _add(UCHAR*, UCHAR*, INT);               */
/* extern VOID   _power(INT, SHORT*, UCHAR*);             */
/* extern VOID   _pow5(INT, CHAR*);                       */
/* extern VOID   _pow10(INT, SHORT*, UCHAR*);             */
/* extern int    _log10(double);                          */
/* extern INT    _lsft(UCHAR*, INT);                      */
/* extern int    _rsft(UCHAR*, INT);                      */
/* extern INT    _lsfts(UCHAR*, INT, SHORT);              */
/* extern INT    _rsfts(UCHAR*, INT, SHORT);              */
/* extern double _pack(SHORT, UCHAR*);                    */
/* extern VOID   _unpack(double, CHAR*, SHORT*, UCHAR*);  */
/* extern VOID   _calcnpw(SHORT, UCHAR*, INT, UCHAR*);    */
/* extern VOID   _calcint(UCHAR*, INT, INT);              */
/* extern double _calcpow(UCHAR*, INT);                   */
/* extern int    _duchek(double);                         */
/* extern int    _allzero(UCHAR*, INT);                   */
/* extern VOID   _setsbit(UCHAR*, INT, INT);              */
/* extern int    _rnd(UCHAR*, INT);                       */
/* extern INT    _strchek(CHAR*, CHAR*);                  */
/* extern CHAR  *sbrk(int);                               */
