/*--------------------------------------------------------------------*/
/* H8S,H8/300 SERIES C Compiler Ver. 1.0                              */
/* Copyright (C) 1994 Hitachi, Ltd.                                   */
/* Licensed Material of Hitachi,Ltd.                                  */
/*--------------------------------------------------------------------*/
/*****************************************************************/
/* SPEC ;                                                        */
/*   NAME = eh2lfun :                                            */
/*   FUNC = define of type  &  check macro ;                     */
/*                                                               */
/*   END ;                                                       */
/*****************************************************************/

extern _HEADER *_freeptr;

extern int    open(char*, int,int);
extern int    read(int, char*, unsigned);
extern int    write(int, char*, unsigned);
extern int    close(int);
extern long   lseek(int, long, int);
extern int    _flopen(const char*, const char*, char*);
extern int    _flclose(FILE*);
extern int    _fillbuf(FILE*);
extern int    _flshbuf(int, FILE*);
extern void   _alocbuf(FILE*);
extern int    _fmtin(int, int (*)(FILE *),         /* V2.0 C */
                     FILE*, const char*, char*);
extern int    _fmtout(int, int (*)(int, FILE *),         /* V2.0 C */
                      FILE*, const char*, char*);
#endif

extern VOID   _its(CHAR*, CHAR*, INT);
extern int    _dti(double, INT, CHAR*, INT*, CHAR*);
extern double _std(INT, CHAR*, INT);
extern VOID   _mult(UCHAR*, UCHAR*, UCHAR*);
extern VOID   _mult64(SHORT*, UCHAR*, SHORT, UCHAR*);
extern VOID   _divi(CHAR*, CHAR*, CHAR*);
extern int    _sub(INT, UCHAR*, UCHAR*, INT);
extern VOID   _add(UCHAR*, UCHAR*, INT);
extern VOID   _power(INT, SHORT*, UCHAR*);
extern VOID   _pow5(INT, CHAR*);
extern VOID   _pow10(INT, SHORT*, UCHAR*);
extern int    _log10(double);
extern INT    _lsft(UCHAR*, INT);
extern int    _rsft(UCHAR*, INT);
extern INT    _lsfts(UCHAR*, INT, SHORT);
extern INT    _rsfts(UCHAR*, INT, SHORT);
extern double _pack(SHORT, UCHAR*);
extern VOID   _unpack(double, CHAR*, SHORT*, UCHAR*);
extern VOID   _calcnpw(SHORT, UCHAR*, INT, UCHAR*);
extern VOID   _calcint(UCHAR*, INT, INT);
extern double _calcpow(UCHAR*, INT);
extern int    _duchek(double);
extern int    _allzero(UCHAR*, INT);
extern VOID   _setsbit(UCHAR*, INT, INT);
extern int    _rnd(UCHAR*, INT);
extern INT    _strchek(CHAR*, CHAR*);
/***extern CHAR  *sbrk(int);                           *** D P3S115-1 */
extern CHAR  *sbrk(size_t);                             /* A P3S115-1 */
