/* inner format function prototype declalation */
/* inner float  */
extern int             _istypes(IN_SINGLE);
extern int             _in_eqs(IN_SINGLE, IN_SINGLE);
extern int             _in_gts(IN_SINGLE, IN_SINGLE);

extern IN_SINGLE       _stois(float); 
extern float           _istos(IN_SINGLE);
extern IN_SINGLE       _itois(int);

extern IN_SINGLE       _in_adds(IN_SINGLE, IN_SINGLE); 
extern IN_SINGLE       _in_subs(IN_SINGLE, IN_SINGLE);
extern IN_SINGLE       _in_muls(IN_SINGLE, IN_SINGLE);
extern IN_SINGLE       _in_divs(IN_SINGLE, IN_SINGLE);

extern IN_SINGLE       _in_truncs(IN_SINGLE); 
extern IN_SINGLE       _in_floors(IN_SINGLE);
extern IN_SINGLE       _in_ceils(IN_SINGLE);

extern IN_SINGLE       _in_sqrts(IN_SINGLE);

extern IN_SINGLE       _in_sins(IN_SINGLE);
extern IN_SINGLE       _in_coss(IN_SINGLE);
extern IN_SINGLE       _in_tans(IN_SINGLE);
extern IN_SINGLE       _in_asins(IN_SINGLE);
extern IN_SINGLE       _in_acoss(IN_SINGLE);
extern IN_SINGLE       _in_atans(IN_SINGLE);
extern IN_SINGLE       _in_atan2s(IN_SINGLE, IN_SINGLE);

extern IN_SINGLE       _in_sinhs(IN_SINGLE);
extern IN_SINGLE       _in_coshs(IN_SINGLE);
extern IN_SINGLE       _in_tanhs(IN_SINGLE);
extern IN_SINGLE       _in_logs(IN_SINGLE);
extern IN_SINGLE       _in_log10s(IN_SINGLE);
extern IN_SINGLE       _in_exps(IN_SINGLE);
extern IN_SINGLE       _in_pows(IN_SINGLE, IN_SINGLE);
extern IN_SINGLE       _in_modfs(IN_SINGLE, IN_SINGLE*);
extern IN_SINGLE       _in_fmods(IN_SINGLE, IN_SINGLE, unsigned*);
extern IN_SINGLE       _in_ldexps(IN_SINGLE, long);     /* C P_FLT001 */

extern IN_SINGLE       _polinos(IN_SINGLE, IN_SINGLE*, int);
extern IN_SINGLE       _app_sins(IN_SINGLE);
extern IN_SINGLE       _app_coss(IN_SINGLE);
extern IN_SINGLE       _app_atans(IN_SINGLE);

/* constant data */
extern IN_SINGLE _IFNANS;
extern IN_SINGLE _IFZEROS;
extern IN_SINGLE _IFINFS;
extern IN_SINGLE _IFONES;
extern IN_SINGLE _HALFS;
extern IN_SINGLE _QUOTS;
extern IN_SINGLE _TWOS;
extern IN_SINGLE _FOURS;
extern IN_SINGLE _PAIS;
extern IN_SINGLE _2PAIS;
extern IN_SINGLE _HLFPAIS;
extern IN_SINGLE _QUOPAIS;
extern IN_SINGLE _LOGE2S;

extern IN_SINGLE _NIFZEROS;
extern IN_SINGLE _NIFINFS;
extern IN_SINGLE _NIFONES;
extern IN_SINGLE _NHALFS;
extern IN_SINGLE _NQUOTS;
extern IN_SINGLE _NTWOS;
extern IN_SINGLE _NFOURS;
extern IN_SINGLE _NPAIS;
extern IN_SINGLE _N2PAIS;
extern IN_SINGLE _NHLFPAIS;
extern IN_SINGLE _NQUOPAIS;
extern IN_SINGLE _NLOGE2S;

