-------- PROJECT GENERATOR --------
PROJECT NAME :	UserBootModeXmodem
PROJECT DIRECTORY :	C:\Work\H8300h\HEW\h83069\UserBootModeXmodem\UserBootModeXmodem
CPU SERIES :	300H
CPU TYPE :	3067F
TOOLCHAIN NAME :	Hitachi H8S,H8/300 Standard Toolchain
TOOLCHAIN VERSION :	4.0.A
GENERATION FILES :
    C:\Work\H8300h\HEW\h83069\UserBootModeXmodem\UserBootModeXmodem\dbsct.c
        Setting of B,R Section
    C:\Work\H8300h\HEW\h83069\UserBootModeXmodem\UserBootModeXmodem\iodefine.h
        Definition of I/O Register
    C:\Work\H8300h\HEW\h83069\UserBootModeXmodem\UserBootModeXmodem\intprg.c
        Interrupt Program
    C:\Work\H8300h\HEW\h83069\UserBootModeXmodem\UserBootModeXmodem\resetprg.c
        Reset Program
    C:\Work\H8300h\HEW\h83069\UserBootModeXmodem\UserBootModeXmodem\UserBootModeXmodem.c
        Main Program
    C:\Work\H8300h\HEW\h83069\UserBootModeXmodem\UserBootModeXmodem\stacksct.h
        Setting of Stack area
START ADDRESS OF SECTION :
    H'000000400	PResetPRG,PIntPRG
    H'000000800	P,C,C$DSEC,C$BSEC,D
    H'000FFEF20	B,R
    H'000FFFD00	S

* When the user program is executed,
* the interrupt mask has been masked.
* 
* ****H8/3067f Advanced****
