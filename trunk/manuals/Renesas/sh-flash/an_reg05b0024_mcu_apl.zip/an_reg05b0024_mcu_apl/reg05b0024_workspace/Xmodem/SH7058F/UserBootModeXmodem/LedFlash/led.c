// led.c

#include "iodefine.h"

void InitUserLed1( void )
{
    // PA4
    // configure pin as a general i/o pin
    P_PA.CRL.WORD &= ~(0x0100);
    // set pin as an output
    P_PA.IOR.WORD |= 0x0010;
    // turn led off
    P_PA.DR.WORD &= ~(0x0010);
}

void InitUserLed2( void )
{
    // PA5
    P_PA.CRL.WORD &= ~(0x0400);
    // set pin as an output
    P_PA.IOR.WORD |= 0x0020;
    // turn led off
    P_PA.DR.WORD &= ~(0x0020);
}

void ToggledUserLed1( void )
{
    if( P_PA.DR.WORD & 0x0010 )
    {
        P_PA.DR.WORD &= ~(0x0010);
    }
    else
    {
        P_PA.DR.WORD |= 0x0010;
    }
}

void ToggledUserLed2( void )
{
    if( P_PA.DR.WORD & 0x0020 )
    {
        P_PA.DR.WORD &= ~(0x0020);
    }
    else
    {
        P_PA.DR.WORD |= 0x0020;
    }
}