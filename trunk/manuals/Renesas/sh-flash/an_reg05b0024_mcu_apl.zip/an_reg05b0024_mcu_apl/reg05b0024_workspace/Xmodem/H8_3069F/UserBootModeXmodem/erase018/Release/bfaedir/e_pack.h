/*--------------------------------------------------------------------*/
/* H8S,H8/300 SERIES C Compiler Ver. 1.0                              */
/* Copyright (C) 1994 Hitachi, Ltd.                                   */
/* Licensed Material of Hitachi,Ltd.                                  */
/*--------------------------------------------------------------------*/
/*****************************************************************/
/* SPEC ;                                                        */
/*   NAME = e_pack :                                             */
/*   FUNC = define of type  &  check macro ;                     */
/*                                                               */
/*   END ;                                                       */
/*****************************************************************/

extern volatile int  _errno;

extern INT    _lsft(UCHAR*, INT);
extern void *memset(void *, int, size_t);
extern int    _rsft(UCHAR*, INT);
extern int    _rnd(UCHAR*, INT);
extern INT    _rsfts(UCHAR*, INT, SHORT);
extern void *memcpy(void *, const void *, size_t);
extern double _pack(SHORT, UCHAR*);
