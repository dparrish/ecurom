/* inner format function prototype declalation */
/* inner double */
extern int             _istyped(IN_DOUBLE);
extern int             _in_eqd(IN_DOUBLE, IN_DOUBLE);
extern int             _in_gtd(IN_DOUBLE, IN_DOUBLE);

extern IN_DOUBLE       _dtoid(double); 
extern double          _idtod(IN_DOUBLE);
extern IN_DOUBLE       _itoid(int);

extern IN_DOUBLE       _in_addd(IN_DOUBLE, IN_DOUBLE); 
extern IN_DOUBLE       _in_subd(IN_DOUBLE, IN_DOUBLE);
extern IN_DOUBLE       _in_muld(IN_DOUBLE, IN_DOUBLE);
extern IN_DOUBLE       _in_divd(IN_DOUBLE, IN_DOUBLE);

extern IN_DOUBLE       _in_truncd(IN_DOUBLE); 
extern IN_DOUBLE       _in_floord(IN_DOUBLE);
extern IN_DOUBLE       _in_ceild(IN_DOUBLE);

extern IN_DOUBLE       _in_sqrtd(IN_DOUBLE);

extern IN_DOUBLE       _in_sind(IN_DOUBLE);
extern IN_DOUBLE       _in_cosd(IN_DOUBLE);
extern IN_DOUBLE       _in_tand(IN_DOUBLE);
extern IN_DOUBLE       _in_asind(IN_DOUBLE);
extern IN_DOUBLE       _in_acosd(IN_DOUBLE);
extern IN_DOUBLE       _in_atand(IN_DOUBLE);
extern IN_DOUBLE       _in_atan2d(IN_DOUBLE, IN_DOUBLE);

extern IN_DOUBLE       _in_sinhd(IN_DOUBLE);
extern IN_DOUBLE       _in_coshd(IN_DOUBLE);
extern IN_DOUBLE       _in_tanhd(IN_DOUBLE);
extern IN_DOUBLE       _in_logd(IN_DOUBLE);
extern IN_DOUBLE       _in_log10d(IN_DOUBLE);
extern IN_DOUBLE       _in_expd(IN_DOUBLE);
extern IN_DOUBLE       _in_powd(IN_DOUBLE, IN_DOUBLE);
extern IN_DOUBLE       _in_modfd(IN_DOUBLE, IN_DOUBLE*);
extern IN_DOUBLE       _in_fmodd(IN_DOUBLE, IN_DOUBLE, unsigned*);
extern IN_DOUBLE       _in_ldexpd(IN_DOUBLE, long);     /* C P_FLT001 */

extern IN_DOUBLE       _polinod(IN_DOUBLE, IN_DOUBLE*, int);
extern IN_DOUBLE       _app_sind(IN_DOUBLE);
extern IN_DOUBLE       _app_cosd(IN_DOUBLE);
extern IN_DOUBLE       _app_atand(IN_DOUBLE);

/* constant data */
extern IN_DOUBLE _IFNAND;
extern IN_DOUBLE _IFZEROD;
extern IN_DOUBLE _IFINFD;
extern IN_DOUBLE _IFONED;
extern IN_DOUBLE _HALFD;
extern IN_DOUBLE _QUOTD;
extern IN_DOUBLE _TWOD;
extern IN_DOUBLE _FOURD;
extern IN_DOUBLE _PAID;
extern IN_DOUBLE _2PAID;
extern IN_DOUBLE _HLFPAID;
extern IN_DOUBLE _QUOPAID;
extern IN_DOUBLE _LOGE2D;

extern IN_DOUBLE _NIFZEROD;
extern IN_DOUBLE _NIFINFD;
extern IN_DOUBLE _NIFONED;
extern IN_DOUBLE _NHALFD;
extern IN_DOUBLE _NQUOTD;
extern IN_DOUBLE _NTWOD;
extern IN_DOUBLE _NFOURD;
extern IN_DOUBLE _NPAID;
extern IN_DOUBLE _N2PAID;
extern IN_DOUBLE _NHLFPAID;
extern IN_DOUBLE _NQUOPAID;
extern IN_DOUBLE _NLOGE2D;

