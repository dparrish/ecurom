/*--------------------------------------------------------------------*/
/* H8S,H8/300 SERIES C Compiler Ver. 1.0                              */
/* Copyright (C) 1994 Hitachi, Ltd.                                   */
/* Licensed Material of Hitachi,Ltd.                                  */
/*--------------------------------------------------------------------*/
/*****************************************************************/
/* SPEC ;                                                        */
/*   NAME = e_std :                                              */
/*   FUNC =                                                      */
/*          ;                                                    */
/*                                                               */
/*                                                               */
/*                                                               */
/*   CLAS = UNIT ;                                               */
/*   END ;                                                       */
/*****************************************************************/


extern volatile int _errno;

extern void *memset(void *, int, size_t);
/* extern double _std(INT, CHAR*, INT); */
extern VOID   _calcint(UCHAR*, INT, INT);
extern double _calcpow(UCHAR*, INT);
extern double _std(INT, CHAR*, INT);
