/*--------------------------------------------------------------------*/
/* H8S,H8/300 SERIES C Compiler Ver. 1.0                              */
/* Copyright (C) 1994 Hitachi, Ltd.                                   */
/* Licensed Material of Hitachi,Ltd.                                  */
/*--------------------------------------------------------------------*/
/*****************************************************************/
/* SPEC ;                                                        */
/*   NAME = e_divi :                                             */
/*   FUNC = define of type  &  check macro ;                     */
/*                                                               */
/*   END ;                                                       */
/*****************************************************************/

extern void *memcpy(void *, const void *, size_t);
extern void *memset(void *, int, size_t);
extern INT    _lsft(UCHAR*, INT);
extern int    _sub(INT, UCHAR*, UCHAR*, INT);
extern VOID   _divi(CHAR*, CHAR*, CHAR*);
