/*--------------------------------------------------------------------*/
/* H8S,H8/300 SERIES C Compiler Ver. 1.0                              */
/* Copyright (C) 1994 Hitachi, Ltd.                                   */
/* Licensed Material of Hitachi,Ltd.                                  */
/*--------------------------------------------------------------------*/
/*****************************************************************/
/* SPEC ;                                                        */
/*   NAME = emalloc :                                            */
/*   FUNC =                                                      */
/*          ;                                                    */
/*                                                               */
/*                                                               */
/*                                                               */
/*   CLAS = UNIT ;                                               */
/*   END ;                                                       */
/*****************************************************************/

extern _HEADER *_freeptr;
extern const size_t _sbrk_size;                     /* A P3V253L */

/***extern CHAR  *sbrk(int);                           *** D P3S115-1 */
extern CHAR  *sbrk(size_t);                             /* A P3S115-1 */
extern void free(void *) ;
extern void *malloc(size_t);
