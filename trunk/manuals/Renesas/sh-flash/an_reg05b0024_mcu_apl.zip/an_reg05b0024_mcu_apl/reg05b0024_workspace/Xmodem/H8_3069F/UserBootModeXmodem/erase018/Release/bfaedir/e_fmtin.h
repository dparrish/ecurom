/*--------------------------------------------------------------------*/
/* H8S,H8/300 SERIES C Compiler Ver. 1.0                              */
/* Copyright (C) 1994 Hitachi, Ltd.                                   */
/* Licensed Material of Hitachi,Ltd.                                  */
/*--------------------------------------------------------------------*/
/***********************************************************************/
/* SPEC;                                                               */
/*  NAME = e_fmtin : header file for standard I/O function ;           */
/*                                                                     */
/*  FUNC = this header file do the following functions;                */
/*         (1) file entry table define;                                */
/*         (2) I/O macro define;                                       */
/*         (3) symbol define;                                          */
/*  CLAS = UNIT;                                                       */
/*                                                                     */
/* END;                                                                */
/***********************************************************************/


extern unsigned char _ctype[];
extern volatile  int         _errno;

typedef struct datablk3{                     /* P3V257 A */
            char _cc;                        /* P3V257 A */
            char _objsize;                   /* P3V257 A */
            char _objtype;                   /* P3V257 A */
            char _fmtflag;                   /* P3V257 A */
            char *_str;                      /* P3V257 A */
            long _inch;                      /* P3V257 A */
            long _width;                     /* P3V257 A */
            int   (*_sifun)(FILE *);         /* P3V257 A */
}_DATA3;                                     /* P3V257 A */

extern double _std(INT, CHAR*, INT);
extern int     fgetc(FILE *);   /* v--- V2.0 C */
extern int    _fmtin(int, int(*)(FILE *), FILE*, const char*, char*);
