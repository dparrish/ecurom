/*--------------------------------------------------------------------*/
/* H8S,H8/300 SERIES C Compiler Ver. 1.0                              */
/* Copyright (C) 1994 Hitachi, Ltd.                                   */
/* Licensed Material of Hitachi,Ltd.                                  */
/*--------------------------------------------------------------------*/
/*****************************************************************/
/* SPEC ;                                                        */
/*   NAME = e_pow10 :                                            */
/*   FUNC = define of type  &  check macro ;                     */
/*                                                               */
/*   END ;                                                       */
/*****************************************************************/

extern VOID   _pow5(INT, CHAR*);
extern void *memset(void *, int, size_t);
extern INT    _lsfts(UCHAR*, INT, SHORT);
extern void *memcpy(void *, const void *, size_t);
extern VOID   _pow10(INT, SHORT*, UCHAR*);
