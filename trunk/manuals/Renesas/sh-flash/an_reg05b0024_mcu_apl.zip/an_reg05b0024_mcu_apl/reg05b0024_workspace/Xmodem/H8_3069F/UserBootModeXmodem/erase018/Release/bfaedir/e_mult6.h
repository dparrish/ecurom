/*--------------------------------------------------------------------*/
/* H8S,H8/300 SERIES C Compiler Ver. 1.0                              */
/* Copyright (C) 1994 Hitachi, Ltd.                                   */
/* Licensed Material of Hitachi,Ltd.                                  */
/*--------------------------------------------------------------------*/
/*****************************************************************/
/* SPEC ;                                                        */
/*   NAME = eh2lfun :                                            */
/*   FUNC = define of type  &  check macro ;                     */
/*                                                               */
/*   END ;                                                       */
/*****************************************************************/

extern VOID   _mult(UCHAR*, UCHAR*, UCHAR*);
extern INT    _lsft(UCHAR*, INT);
extern VOID   _setsbit(UCHAR*, INT, INT);
extern void *memcpy(void *, const void *, size_t);
extern VOID   _mult64(SHORT*, UCHAR*, SHORT, UCHAR*);
