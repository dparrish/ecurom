/*--------------------------------------------------------------------*/
/* H8S,H8/300 SERIES C Compiler Ver. 1.0                              */
/* Copyright (C) 1994 Hitachi, Ltd.                                   */
/* Licensed Material of Hitachi,Ltd.                                  */
/*--------------------------------------------------------------------*/
/*****************************************************************/
/* SPEC ;                                                        */
/*   NAME = e_dti :                                              */
/*   FUNC = define of type  &  check macro ;                     */
/*                                                               */
/*   END ;                                                       */
/*****************************************************************/


extern int    _allzero(UCHAR*, INT);
extern VOID   _unpack(double, CHAR*, SHORT*, UCHAR*);
extern int    _log10(double);
extern VOID   _pow5(INT, CHAR*);
extern INT    _lsfts(UCHAR*, INT, SHORT);
extern VOID   _calcnpw(SHORT, UCHAR*, INT, UCHAR*);
extern void *memcpy(void *, const void *, size_t);
extern int  memcmp(const void *, const void *,size_t);
extern int    _dti(double, INT, CHAR*, INT*, CHAR*);
