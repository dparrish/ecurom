// delay_timer.c

#include "delay_timer.h"

void InitDelayTimer (void)
{
	DELAY_TIMER_CH.TCR.BIT.CKS = 0;		// Stop the timer
	
	DELAY_TIMER_CH.TCR.BIT.CMIEB = 0;	// compare match B interrupt disabled
	DELAY_TIMER_CH.TCR.BIT.CMIEA = 0;	// compare match A interrupt disabled
	DELAY_TIMER_CH.TCR.BIT.OVIE = 0;	// overflow interrupt disabled
	
	DELAY_TIMER_CH.TCR.BIT.CCLR = 1;	// counter cleared on compare match A	
}

void StartDelayTimer (void)
{
	DELAY_TIMER_CH.TCSR.BIT.CMFA = 0;	// Clear compare match A flag
	DELAY_TIMER_CH.TCORA = ONE_MSEC;	// set compare value
	DELAY_TIMER_CH.TCNT = 0;			// clear CMCNT to 0
	
	DELAY_TIMER_CH.TCR.BIT.CKS = 3;		// Start the timer, internal clock / 8192
}

void StopDelayTimer (void)
{
	DELAY_TIMER_CH.TCR.BIT.CKS = 0;		// Stop the timer
}

unsigned char GetDelayTimerStatus (void)
{
	if ( DELAY_TIMER_CH.TCSR.BIT.CMFA )
	{
		return (1);
	}              
	else
	{
		return (0);
	}
}
