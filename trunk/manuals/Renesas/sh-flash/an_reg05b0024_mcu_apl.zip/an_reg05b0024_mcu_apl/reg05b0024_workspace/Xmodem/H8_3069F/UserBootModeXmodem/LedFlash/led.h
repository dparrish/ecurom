// led.h

#ifndef _LED_H
#define _LED_H

// function prototypes
void InitUserLed1( void );
void InitUserLed2( void );
void ToggledUserLed1( void );
void ToggledUserLed2( void );

#endif