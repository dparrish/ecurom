// command.h

#ifndef _COMMAND_H
#define _COMMAND_H

#define FIRST_USER_FLASH_ADDR	0L
#define LAST_USER_FLASH_ADDR	0x7ffff
#define BLANK_VALUE				0xffff
#define FIRST_USER_FLASH_BLK	0
#define NO_OF_FLASH_BLOCKS		16
#define FLASH_LINE_SIZE			128

void InitCommandHandler (void);
void RunCommandHandler (void);
void ShowMenu (void);
void Command_1 (void);
void Command_2 (void);
void Command_3 (void);
void Command_4 (void);
void Command_5 (void);

#endif