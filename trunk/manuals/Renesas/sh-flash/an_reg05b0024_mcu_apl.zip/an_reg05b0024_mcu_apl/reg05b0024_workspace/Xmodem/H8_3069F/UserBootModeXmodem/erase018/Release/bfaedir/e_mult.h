/*--------------------------------------------------------------------*/
/* H8S,H8/300 SERIES C Compiler Ver. 1.0                              */
/* Copyright (C) 1994 Hitachi, Ltd.                                   */
/* Licensed Material of Hitachi,Ltd.                                  */
/*--------------------------------------------------------------------*/
/*****************************************************************/
/* SPEC ;                                                        */
/*   NAME = e_mult :                                             */
/*   FUNC = define of type  &  check macro ;                     */
/*                                                               */
/*   END ;                                                       */
/*****************************************************************/

extern void *memset(void *, int, size_t);
extern void *memcpy(void *, const void *, size_t);
extern VOID   _add(UCHAR*, UCHAR*, INT);
extern VOID   _mult(UCHAR*, UCHAR*, UCHAR*);
