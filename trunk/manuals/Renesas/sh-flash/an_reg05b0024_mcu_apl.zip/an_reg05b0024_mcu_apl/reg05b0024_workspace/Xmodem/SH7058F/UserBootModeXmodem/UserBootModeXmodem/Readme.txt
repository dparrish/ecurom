-------- PROJECT GENERATOR --------
PROJECT NAME :	UserBootModeXmodem
PROJECT DIRECTORY :	C:\Work\SH2e\HEW\sh7058f\UserBootModeXmodem\UserBootModeXmodem
CPU SERIES :	SH-2E
CPU TYPE :	SH7055F
TOOLCHAIN NAME :	Hitachi SuperH RISC engine Standard Toolchain
TOOLCHAIN VERSION :	6.0.A
GENERATION FILES :
    C:\Work\SH2e\HEW\sh7058f\UserBootModeXmodem\UserBootModeXmodem\initsct.c
        Initialize of RAM Data
    C:\Work\SH2e\HEW\sh7058f\UserBootModeXmodem\UserBootModeXmodem\dbsct.src
        Setting of B,R Section
    C:\Work\SH2e\HEW\sh7058f\UserBootModeXmodem\UserBootModeXmodem\intprg.c
        Interrupt Program
    C:\Work\SH2e\HEW\sh7058f\UserBootModeXmodem\UserBootModeXmodem\vecttbl.c
        Initialize of Vector Table
    C:\Work\SH2e\HEW\sh7058f\UserBootModeXmodem\UserBootModeXmodem\vect.h
        Definition of Vector
    C:\Work\SH2e\HEW\sh7058f\UserBootModeXmodem\UserBootModeXmodem\resetprg.src
        Reset Program
    C:\Work\SH2e\HEW\sh7058f\UserBootModeXmodem\UserBootModeXmodem\UserBootModeXmodem.c
        Main Program
    C:\Work\SH2e\HEW\sh7058f\UserBootModeXmodem\UserBootModeXmodem\stacksct.src
        Setting of Stack area
LIBRARY NAME :	
START ADDRESS OF SECTION :
    H'000000000	DVECTTBL,DINTTBL,PIntPRG
    H'000000800	ResetPRG
    H'000001000	P,C,D
    H'0FFFF6000	B,R
    H'0FFFFDBF0	Stack

* When the user program is executed,
* the interrupt mask has been masked.
* 
* Program start H'1000.
* RAM start H'FFFF6000.
