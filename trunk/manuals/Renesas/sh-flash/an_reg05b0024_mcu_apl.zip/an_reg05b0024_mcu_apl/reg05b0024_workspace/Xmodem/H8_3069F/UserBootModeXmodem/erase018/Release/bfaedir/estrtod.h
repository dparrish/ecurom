/*--------------------------------------------------------------------*/
/* H8S,H8/300 SERIES C Compiler Ver. 1.0                              */
/* Copyright (C) 1994 Hitachi, Ltd.                                   */
/* Licensed Material of Hitachi,Ltd.                                  */
/*--------------------------------------------------------------------*/
/*****************************************************************/
/* SPEC ;                                                        */
/*   NAME = estrtod :                                            */
/*   FUNC =                                                      */
/*          ;                                                    */
/*                                                               */
/*                                                               */
/*                                                               */
/*   CLAS = UNIT ;                                               */
/*   END ;                                                       */
/*****************************************************************/


extern unsigned char _ctype[];
extern volatile  int	_errno;

extern INT    _strchek(CHAR*, CHAR*);
extern double _std(INT, CHAR*, INT);
extern int    _sub(INT, UCHAR*, UCHAR*, INT);
extern double strtod(const char *, char **) ;
