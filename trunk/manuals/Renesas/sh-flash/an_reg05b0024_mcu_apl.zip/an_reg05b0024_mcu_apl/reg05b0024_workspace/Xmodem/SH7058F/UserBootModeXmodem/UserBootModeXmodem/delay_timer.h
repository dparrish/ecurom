// delay_timer.h

#ifndef _DELAY_TIMER_H
#define _DELAY_TIMER_H

#include "iodefine.h"

// definitions
#define XTAL						20000000L
#define ONE_MSEC					((1L * XTAL) / 32000L)
#define DELAY_TIMER_CH				P_CMT0
//
#define MS_PER_TIMER_COMPARE_MATCH	1
//
// function prototypes
void InitDelayTimer (void);
void StartDelayTimer (void);
void StopDelayTimer (void);
unsigned char GetDelayTimerStatus (void);

#endif