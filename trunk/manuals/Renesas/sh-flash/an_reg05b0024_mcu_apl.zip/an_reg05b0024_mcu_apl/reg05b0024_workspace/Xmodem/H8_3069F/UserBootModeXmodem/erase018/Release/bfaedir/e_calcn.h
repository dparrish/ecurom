/*--------------------------------------------------------------------*/
/* H8S,H8/300 SERIES C Compiler Ver. 1.0                              */
/* Copyright (C) 1994 Hitachi, Ltd.                                   */
/* Licensed Material of Hitachi,Ltd.                                  */
/*--------------------------------------------------------------------*/
/*****************************************************************/
/* SPEC ;                                                        */
/*   NAME = e_calcn :                                            */
/*   FUNC = define of type  &  check macro ;                     */
/*                                                               */
/*   END ;                                                       */
/*****************************************************************/

extern VOID   _power(INT, SHORT*, UCHAR*);
extern VOID   _mult64(SHORT*, UCHAR*, SHORT, UCHAR*);
extern VOID   _setsbit(UCHAR*, INT, INT);
extern INT    _rsfts(UCHAR*, INT, SHORT);
extern int    _rnd(UCHAR*, INT);
extern void *memcpy(void *, const void *, size_t);
extern VOID   _calcnpw(SHORT, UCHAR*, INT, UCHAR*);
