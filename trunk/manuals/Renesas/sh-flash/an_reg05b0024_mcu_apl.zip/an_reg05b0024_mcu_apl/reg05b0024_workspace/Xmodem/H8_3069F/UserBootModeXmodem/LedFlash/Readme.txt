-------- PROJECT GENERATOR --------
PROJECT NAME :	LedFlash
PROJECT DIRECTORY :	C:\Work\H8300h\HEW\h83069\UserBootModeXmodem\LedFlash
CPU SERIES :	300H
CPU TYPE :	3067F
TOOLCHAIN NAME :	Hitachi H8S,H8/300 Standard Toolchain
TOOLCHAIN VERSION :	4.0.A
GENERATION FILES :
    C:\Work\H8300h\HEW\h83069\UserBootModeXmodem\LedFlash\dbsct.c
        Setting of B,R Section
    C:\Work\H8300h\HEW\h83069\UserBootModeXmodem\LedFlash\iodefine.h
        Definition of I/O Register
    C:\Work\H8300h\HEW\h83069\UserBootModeXmodem\LedFlash\intprg.c
        Interrupt Program
    C:\Work\H8300h\HEW\h83069\UserBootModeXmodem\LedFlash\resetprg.c
        Reset Program
    C:\Work\H8300h\HEW\h83069\UserBootModeXmodem\LedFlash\LedFlash.c
        Main Program
    C:\Work\H8300h\HEW\h83069\UserBootModeXmodem\LedFlash\stacksct.h
        Setting of Stack area
START ADDRESS OF SECTION :
    H'000000400	PResetPRG,PIntPRG
    H'000000800	P,C,C$DSEC,C$BSEC,D
    H'000FFEF20	B,R
    H'000FFFD00	S

* When the user program is executed,
* the interrupt mask has been masked.
* 
* ****H8/3067f Advanced****
