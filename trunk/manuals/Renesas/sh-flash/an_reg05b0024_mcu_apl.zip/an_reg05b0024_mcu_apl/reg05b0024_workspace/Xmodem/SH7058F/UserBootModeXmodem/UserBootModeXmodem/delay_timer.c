// delay_timer.c

#include "delay_timer.h"

void InitDelayTimer (void)
{
	P_CMT.CMSTR.BIT.STR0 = 0;				// Stop the timer
	
	DELAY_TIMER_CH.CMCSR.BIT.CMIE = 0;		// Compare match interrupt disabled
	DELAY_TIMER_CH.CMCSR.BIT.CKS = 1;		// Pclk / 32
	
	DELAY_TIMER_CH.CMCSR.BIT.CMF = 0;		// Clear compare match flag
	
	DELAY_TIMER_CH.CMCOR = 0;				// Compare match register
}

void StartDelayTimer (void)
{
	DELAY_TIMER_CH.CMCSR.BIT.CMF = 0;		// Clear compare match flag
	DELAY_TIMER_CH.CMCOR = ONE_MSEC;		// set compare value
	DELAY_TIMER_CH.CMCNT = 0;				// clear CMCNT to 0
	P_CMT.CMSTR.BIT.STR0 = 1;				// Start the timer
}

void StopDelayTimer (void)
{
	P_CMT.CMSTR.BIT.STR0 = 0;				// Stop the timer
}

unsigned char GetDelayTimerStatus (void)
{
	if ( DELAY_TIMER_CH.CMCSR.BIT.CMF )
	{
		return (1);
	}              
	else
	{
		return (0);
	}
}
