/*--------------------------------------------------------------------*/
/* H8S,H8/300 SERIES C Compiler Ver. 1.0                              */
/* Copyright (C) 1994 Hitachi, Ltd.                                   */
/* Licensed Material of Hitachi,Ltd.                                  */
/*--------------------------------------------------------------------*/
/***********************************************************************/
/* SPEC;                                                               */
/*  NAME = e_fmtou : header file for standard I/O function ;           */
/*                                                                     */
/*  FUNC = this header file do the following functions;                */
/*         (1) file entry table define;                                */
/*         (2) I/O macro define;                                       */
/*         (3) symbol define;                                          */
/*  CLAS = UNIT;                                                       */
/*                                                                     */
/* END;                                                                */
/***********************************************************************/


extern unsigned char _ctype[];
extern volatile  int         _errno;

typedef struct datablk1{                     /* P3V257 A */
            long _outkind;                   /* P3V257 A */
            char *_str;                      /* P3V257 A */
            long _outch;                     /* P3V257 A */
            int (*_sofun)(int, FILE *);      /* P3V257 A */
}_DATA1;                                     /* P3V257 A */

typedef struct datablk2{                     /* P3V257 A */
            char _fmtflg;                    /* P3V257 A */
            char _padchar;                   /* P3V257 A */
            long _width;                     /* P3V257 A */
            long _prec;                      /* P3V257 A */
            long _parasize;                  /* P3V257 A */
            char *_prec_addr0;               /* P3V257 A */
            char *_prec_addr1;               /* P3V257 A */
            char *_prec_addr2;               /* P3V257 A */
            long _prec_ins0;                 /* P3V257 A */
            long _prec_ins1;                 /* P3V257 A */
            long _prec_ins2;                 /* P3V257 A */
            long _with_ins;                  /* P3V257 A */
}_DATA2;                                     /* P3V257 A */

extern size_t strlen(const char *);
extern int    _dti(double, INT, CHAR*, INT*, CHAR*);
extern VOID   _its(CHAR*, CHAR*, INT);
extern void *memcpy(void *, const void *, size_t);
extern int     fputc(int , FILE *);
extern int    _fmtout(int, int (*)(int, FILE *),  /* V2.0 C */
                      FILE*, const char*, char*);
