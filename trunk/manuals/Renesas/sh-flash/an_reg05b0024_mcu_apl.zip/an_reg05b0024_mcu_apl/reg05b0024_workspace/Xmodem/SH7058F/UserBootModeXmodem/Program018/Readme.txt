-------- PROJECT GENERATOR --------
PROJECT NAME :	Program018
PROJECT DIRECTORY :	C:\Work\SH2e\HEW\sh7058f\UserBootModeXmodem\Program018
CPU SERIES :	SH-2E
TOOLCHAIN NAME :	Hitachi SuperH RISC engine Standard Toolchain
TOOLCHAIN VERSION :	6.0.A
LIBRARY NAME :	

