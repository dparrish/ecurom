// led.c

#include "iodefine.h"

static unsigned char PortAShadowDDR = 0;

void InitUserLed1( void )
{
    // PA2
    // configure pin as a general i/o pin
    // set pin as an output
    PortAShadowDDR |= 0x04;
    PADDR = PortAShadowDDR;
    // turn led off
    PADR.BIT.B2 = 0;
}

void InitUserLed2( void )
{
    // PA3
	// configure pin as a general i/o pin
    // set pin as an output
    PortAShadowDDR |= 0x08;
    PADDR = PortAShadowDDR;
    // turn led off
    PADR.BIT.B3 = 0;
}

void ToggledUserLed1( void )
{
    PADR.BIT.B2 ^= 1;
}

void ToggledUserLed2( void )
{
	PADR.BIT.B3 ^= 1;
}